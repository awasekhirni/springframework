package com.tpri.exspring5mvcxml;

public interface Application {}
