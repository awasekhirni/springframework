/**
 * 
 */
package com.tpri.exseventeencore;

import org.springframework.beans.BeansException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

/**
 * @author Awase Khirni Syed
 *
 */
public class DemoBeanFactoryPostProcessor implements BeanFactoryPostProcessor {

	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
		// TODO Auto-generated method stub
		
		//runtime change the property values from those defined in the XML file
		BeanDefinition beanDefinition= beanFactory.getBeanDefinition("visitorBean");
		MutablePropertyValues propertyValues=beanDefinition.getPropertyValues();
		propertyValues.addPropertyValue("visitorName","Syed Ameese Sadath");

	}

}
