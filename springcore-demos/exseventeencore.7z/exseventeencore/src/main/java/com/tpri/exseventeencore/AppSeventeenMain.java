/**
 * 
 */
package com.tpri.exseventeencore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSeventeenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"appseventeen.xml"});
		Visitor sak=(Visitor)context.getBean("visitorBean");
		sak.visitorInfo();
		context.close();
		
		
	}

}
