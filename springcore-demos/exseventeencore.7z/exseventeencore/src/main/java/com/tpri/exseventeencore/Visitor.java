/**
 * 
 */
package com.tpri.exseventeencore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Visitor {
	
	public String visitorName;
	
	public void setVistorName(String visitorName) {
		this.visitorName=visitorName;
	}
	
	public void visitorInfo() {
		System.out.println("We have a New Vistor::"+visitorName);
	}

}
