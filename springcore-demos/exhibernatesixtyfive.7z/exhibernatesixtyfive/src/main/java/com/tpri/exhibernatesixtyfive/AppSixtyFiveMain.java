/**
 * 
 */
package com.tpri.exhibernatesixtyfive;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtyfive.model.Address;
import com.tpri.exhibernatesixtyfive.model.Employee;
import com.tpri.exhibernatesixtyfive.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtyFiveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("65Main - Hibernate 5.2.x + One-to-One mapping(UNIDIRECTIONAL MAPPING)- MySQL");
		Employee emp=null;
		try(Session session=HibernateUtilities.getSessionFactory().openSession()){
			createEmployee(session);
			
			emp=session.get(Employee.class,1);
			Address address = emp.getAddress();
			System.out.println(address);
			
		}catch(HibernateException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void createEmployee(Session session) {
		session.beginTransaction();
		Integer id=(Integer)session.save(getEmployee());
		System.out.println("Employee is created:"+id);
		session.getTransaction().commit();
	}
	
	private static Employee getEmployee() {
		Employee employee=new Employee();
		employee.setEmployeeName("Awase Khirni Syed");
		employee.setEmail("awasekhirni@gmail.com");
		employee.setJoinDate(new Date());
		employee.setSalary(1268712389.23);
		
		Address address1=new Address();
		address1.setStreetName("5th Main Kalyan Nagar");
		address1.setCityName("Bangalore");
		address1.setStateName("Karnataka");
		address1.setZipcode(null);
		
		employee.setAddress(address1);
		
		
		return employee;
	}

}
