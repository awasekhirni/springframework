/**
 * 
 */
package com.tpri.exhibernatesixtynine;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtynine.model.Employee;
import com.tpri.exhibernatesixtynine.model.Project;
import com.tpri.exhibernatesixtynine.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtyNineMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Session session = HibernateUtilities.getSessionFactory().openSession()) {
	    	session.beginTransaction();
	    	
	        String[] projectData = { "IT Project", "Networking Project" };
	        Set<Project> projects = new HashSet<>();
	 
	        for (String project : projectData) {
	        	Project newproject = new Project();
	        	newproject.setProjectTitle(project);
	            projects.add(newproject);
	        }
	        
	        Employee emp1=new Employee();
	        emp1.setFirstName("Awase Khirni");
	        emp1.setLastName("Syed");
	        Employee emp2= new Employee();
	        emp2.setFirstName("Ameese Sadath");
	        emp2.setLastName("Syed");
	        
	        session.save(projects);
	        
	        emp1.setProjects(projects);
	        emp2.setProjects(projects);
	        session.save(emp1);
	        session.save(emp2);
	         	        
			  	
	    	
	    	session.persist(emp1);
			session.persist(emp2);
			
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	
}
