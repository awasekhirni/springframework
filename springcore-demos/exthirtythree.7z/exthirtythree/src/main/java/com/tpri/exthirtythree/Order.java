/**
 * 
 */
package com.tpri.exthirtythree;

/**
 * @author Awase Khirni Syed
 *
 */
public class Order {

	private String orderId;
	private String orderItem;
	private int orderPrice;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderItem() {
		return orderItem;
	}
	public void setOrderItem(String orderItem) {
		this.orderItem = orderItem;
	}
	public int getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}
	
	
	
}
