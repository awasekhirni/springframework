/**
 * 
 */
package com.tpri.exthirtythree;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exthirtythree.Customer;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyThreeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("AppThirtyThreeMain: Constructor Autowiring!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtythree.xml");
		Customer cust = (Customer) context.getBean("customerBean");

		if (cust != null) {
			System.out.println(cust.toString());
			System.out.println(cust.getCustomerId() + "\t" + cust.getCustomerName() + "\t" + cust.getCustomerEmail()
					+ "\t" + cust.getCustomerAddress());
			System.out.println(cust.getOrder().getOrderId());
			System.out.println(cust.getOrder().getOrderItem());
			System.out.println(cust.getOrder().getOrderPrice());
		}

		context.close();
	}

}
