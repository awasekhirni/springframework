/**
 * 
 */
package com.tpri.exthirtythree;

/**
 * @author Awase Khirni Syed
 *
 */
public class Customer {

		private int customerId;
		private String customerName;
		private String customerEmail;
		private String customerAddress;
		private Order order;
		public Customer(int customerId, String customerName, String customerEmail, String customerAddress,
				Order order) {
			super();
			this.customerId = customerId;
			this.customerName = customerName;
			this.customerEmail = customerEmail;
			this.customerAddress = customerAddress;
			this.order = order;
		}
		
		public int getCustomerId() { 	return customerId; 	}
		
		public String getCustomerName() { 			return customerName; 		}
		
		public String getCustomerEmail() { 			return customerEmail; 		}
		
		public String getCustomerAddress() { 			return customerAddress; 		}
		
		public Order getOrder() {
			return order;
		}
	
}
