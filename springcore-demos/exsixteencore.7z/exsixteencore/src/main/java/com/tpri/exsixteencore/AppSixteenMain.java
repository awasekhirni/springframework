/**
 * 
 */
package com.tpri.exsixteencore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appsixteen.xml");

		Library refli=(Library)context.getBean("libraryBean");
		((AbstractApplicationContext)context).registerShutdownHook();
		refli.displayLibraryInfo();
	}

}
