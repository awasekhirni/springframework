/**
 * 
 */
package com.tpri.exsixteencore;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;

/**
 * @author Awase Khirni Syed
 *
 */
public class TwoBeanPostProcessor implements BeanPostProcessor,Ordered {

	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("TwoBeanPostProcessor: BeforeInitialization :::"+beanName);
		return bean;
	}

	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("TwoBeanPostProcessor: AfterInitialization :::"+beanName);
		return bean;
	}
	
	//Ordered Interface specific implementation method
	// Priority starts from 0 to N.
	// 0 means top priority and 1 next priority.
	public int getOrder() {
		// TODO Auto-generated method stub
		return 1;
	}

}
