/**
 * 
 */
package com.tpri.exsixteencore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Library {
	
	public void displayLibraryInfo() {
		System.out.println("App16:Displaying Library Information!!");
	}

}
