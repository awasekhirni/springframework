package com.tpri.ExtwoCoreSpringPrj;

public class Employee {

	public String fullname;
	
	public void getFullName() {
		//return this.fullname;
		System.out.println("My name is EmmenM!");
	}
	
	
}
