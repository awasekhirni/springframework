package com.tpri.ExtwoCoreSpringPrj;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//old approach without using spring 
		// requires instantiation of the employee object
		//Employee e=new Employee();
		//e.getFullName();
		//APPROACH WITH SPRING 
		//Using spring we would like to instantiate the employee object using bean factory 
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("appspring.xml"));
		// pass on the id from XML file to getBean object from BeanFactory
		Employee emp= (Employee) factory.getBean("employee");
		emp.getFullName();

	}

}
