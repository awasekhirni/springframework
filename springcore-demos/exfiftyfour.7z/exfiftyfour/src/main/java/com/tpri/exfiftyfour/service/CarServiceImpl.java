package com.tpri.exfiftyfour.service;

import java.util.List;
import java.util.Map;

import com.tpri.exfiftyfour.dao.ICarsDAO;

public class CarServiceImpl implements ICarService {
	
	private ICarsDAO iCarsDAO;
	
	
	public void setiCarsDAO(ICarsDAO iCarsDAO) {
		this.iCarsDAO = iCarsDAO;
	}


	public List fetchCars(String make, String model, int year, double maxPrice) {
		// TODO Auto-generated method stub
	
		return iCarsDAO.getCars(make, model, year, maxPrice);
	}
	
	public Map<String, Object> fetchInfo(String make, String model, int year, double maxPrice) {
		return iCarsDAO.getInfo(make, model, year, maxPrice);
	}
}
