package com.tpri.exfiftyfour.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tpri.exfiftyfour.model.Car;

public class CarRowMapper implements RowMapper<Car> {

	public Car mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Car car = new Car();
		car.setMake(rs.getString("make"));
		car.setModel(rs.getString("model"));
		car.setPrice(rs.getDouble("price"));
		car.setYear(rs.getString("year"));
		return null;
	}

}
