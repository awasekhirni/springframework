/**
 * 
 */
package com.tpri.exfiftyfour;

import java.util.Map;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfiftyfour.service.CarServiceImpl;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyFourMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFiftyFour-Spring JDBCTEMPLATE-STORED PROCEDURE");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfiftyfour.xml");
		
		CarServiceImpl csimpl=(CarServiceImpl)context.getBean("carservice");
		
		Map<String, Object> mymap =csimpl.fetchInfo("Nissan", "Altima", 2010, 5000.00);
		System.out.println("Status Code:"+mymap.get("status_code"));
		System.out.println("Status Message:"+mymap.get("status_message"));
		
		context.close();
	}

}
