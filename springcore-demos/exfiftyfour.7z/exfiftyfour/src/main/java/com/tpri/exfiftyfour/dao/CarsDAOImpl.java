package com.tpri.exfiftyfour.dao;

import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import com.tpri.exfiftyfour.model.Car;

public class CarsDAOImpl implements ICarsDAO {
	private SimpleJdbcCall simpleJdbcCall;
	
	public void setSimpleJdbcCall(SimpleJdbcCall simpleJdbcCall) {
		this.simpleJdbcCall = simpleJdbcCall;
	}

	public List getCars(String make, String model, int year, double maxPrice) {
		// TODO Auto-generated method stub
		return null ;
	}
	
	public Map<String, Object> getInfo(String make, String model, int year, double maxPrice){
		simpleJdbcCall.withProcedureName("getCars");
		MapSqlParameterSource input = new MapSqlParameterSource();
		input.addValue("the_make", make);
		input.addValue("the_model", model);
		input.addValue("the_year",year);
		input.addValue("the_max_price",maxPrice);
		Map<String, Object> outMap=simpleJdbcCall.execute(input);
		return outMap;
	}

}
