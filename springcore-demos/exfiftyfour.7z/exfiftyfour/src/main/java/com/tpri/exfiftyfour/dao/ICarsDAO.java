package com.tpri.exfiftyfour.dao;

import java.util.List;
import java.util.Map;

public interface ICarsDAO {

	public List getCars(String make, String model, int year, double maxPrice);
	public Map<String, Object> getInfo(String make, String model, int year, double maxPrice);
}
