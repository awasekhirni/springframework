package com.tpri.exfiftyfour.service;

import java.util.List;
import java.util.Map;

public interface ICarService {

	public List fetchCars(String make, String model, int year, double maxPrice);
	public Map<String, Object> fetchInfo(String make, String model, int year, double maxPrice);
}
