/**
 * 
 */
package com.tpri.exthirtytwo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyTwoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppThirtyTwoMain: Autowiring byType Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtytwo.xml");
		Customer cust = (Customer)context.getBean("customerBean");
		
		if(cust !=null) {
			System.out.println(cust.toString());
			System.out.println(cust.getCustomerId()+"\t"+cust.getCustomerName()+"\t"+cust.getCustomerEmail()+"\t"+cust.getCustomerAddress());
			
		}
			
		context.close();
	
	
	}

}
