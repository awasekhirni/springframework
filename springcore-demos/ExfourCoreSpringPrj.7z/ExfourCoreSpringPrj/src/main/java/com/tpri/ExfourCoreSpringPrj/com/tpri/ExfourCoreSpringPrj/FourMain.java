package com.tpri.ExfourCoreSpringPrj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FourMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("FourSpring.xml");
		Dealership deal=(Dealership)context.getBean("dealer");
		deal.greetCustomer();
	
	}

}
