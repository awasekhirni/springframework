package com.tpri.ExfourCoreSpringPrj;

public class Dealership {
	
	String welcomeMessage;

	public String getWelcomeMessage() {
		return welcomeMessage;
	}

	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}


	public void greetCustomer() {
		System.out.println(getWelcomeMessage());
	}
}
