package com.tpri.exfortyseven;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;


import org.springframework.stereotype.Component;

@Component("parkinglot")
public class ParkingLot {

    private List<Car> cars = new ArrayList<Car>();
    private Map<String, Car> carsByDriver = new HashMap<String,Car>();

    public ParkingLot() {
        Car model1 = new Car();
        model1.setMake("Toyota");
        model1.setModel("Highlander");
        model1.setYearOfProduction(2013);

        Car model2 = new Car();
        model2.setMake("Toyota");
        model2.setModel("Corolla");
        model2.setYearOfProduction(2008);

        cars.add(model1);
        cars.add(model2);

        carsByDriver.put("Driver1", model1);
        carsByDriver.put("Driver2", model2);
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }

    public Map<String, Car> getCarsByDriver() {
        return carsByDriver;
    }

    public void setCarsByDriver(Map<String, Car> carsByDriver) {
        this.carsByDriver = carsByDriver;
    }

}


