/**
 * 
 */
package com.tpri.exfortyseven;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortySevenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppFortySevenMain--Spring Expression Language!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortyseven.xml");
		
		Car mycar=(Car)context.getBean("car");
		
		mycar.toString();
		
		System.out.println("\n"+mycar.getHorsePower()+"\t"+mycar.getMake()+"\t"+mycar.getModel()+"\t"+mycar.getYearOfProduction()+"\t"+mycar.getEngine());
		
		context.close();
	}

}
