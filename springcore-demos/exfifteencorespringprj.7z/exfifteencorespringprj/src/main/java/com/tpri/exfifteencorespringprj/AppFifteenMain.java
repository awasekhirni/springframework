/**
 * 
 */
package com.tpri.exfifteencorespringprj;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/**
 * @author Awase Khirni Syed
 *
 */
public class AppFifteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Application15 Demo: BeanPostProcessor!");
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"appfifteen.xml"});
        School dps = (School)context.getBean("schoolBean");
        dps.displaySchoolInfo();
        context.close();
	}

}
