/**
 * 
 */
package com.tpri.exfifteencorespringprj;

/**
 * @author Awase Khirni Syed
 *
 */
public class School {
	
	
	public void displaySchoolInfo() {
		System.out.println("Displaying School Information!");
	}

}
