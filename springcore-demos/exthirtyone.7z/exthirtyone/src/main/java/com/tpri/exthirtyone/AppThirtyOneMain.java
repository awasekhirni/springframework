/**
 * 
 */
package com.tpri.exthirtyone;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppThirtyOne Main: BeanPostProcessor-Execution Order and Callback methods");
		ApplicationContext context = new ClassPathXmlApplicationContext("appthirtyone.xml");
		
		ChatMessage myalerts =(ChatMessage) context.getBean("chatBean");
		System.out.println(myalerts.getChatId()+"\t"+myalerts.getChatMessage());
	}

}
