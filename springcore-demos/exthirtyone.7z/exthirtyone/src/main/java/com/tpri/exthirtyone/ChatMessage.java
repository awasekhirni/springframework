/**
 * 
 */
package com.tpri.exthirtyone;

/**
 * @author Awase Khirni Syed
 *
 */
public class ChatMessage {

	
		private int chatId;
		private String chatMessage;
		public int getChatId() {
			return chatId;
		}
		public void setChatId(int chatId) {
			System.out.println("ChatMessage:setChatId() function called");
			this.chatId = chatId;
		}
		public String getChatMessage() {
			return chatMessage;
		}
		public void setChatMessage(String chatMessage) {
			System.out.println("ChatMessage:setChatMessage() function called");
			this.chatMessage = chatMessage;
		}
		
		//init and destroy methods 
		public void init() {
			System.out.println("ChatMessage:init() function called");
		}
		
		public void destroy() {
			System.out.println("ChatMessage:destroy() function called");
		}
}
