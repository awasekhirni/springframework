/**
 * 
 */
package com.tpri.exfifty.service;

import java.util.List;
import com.tpri.exfifty.model.Product;
/**
 * @author Awase Khirni Syed
 *
 */
public interface IProductService {

	//abstract methods => CRUD operations
			public abstract void addProduct(Product product);
			public abstract Product fetchProductById(int productId);
			public abstract void removeProductById(int productId);
			public abstract void changeProductById(int productId);
			public abstract List<Product> fetchAllProductDetails();
}
