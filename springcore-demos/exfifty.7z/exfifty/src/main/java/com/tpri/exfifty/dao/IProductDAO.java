/**
 * 
 */
package com.tpri.exfifty.dao;

import java.util.List;

import com.tpri.exfifty.model.Product;

/**
 * @author Awase Khirni Syed
 *
 */
public interface IProductDAO {

	//abstract methods => CRUD operations
		public abstract void createProduct(Product product);
		public abstract Product getProductById(int productId);
		public abstract void deleteProductById(int productId);
		public abstract void updateProductById(int productId);
		public abstract List<Product> getAllProductDetails();
}