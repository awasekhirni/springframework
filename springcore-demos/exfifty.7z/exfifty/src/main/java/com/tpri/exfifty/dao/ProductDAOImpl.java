/**
 * 
 */
package com.tpri.exfifty.dao;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import com.tpri.exfifty.model.Product;
public class ProductDAOImpl implements IProductDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate= new JdbcTemplate(dataSource);
	}
	public void createProduct(Product product) {
		// TODO Auto-generated method stub
		String prepstmt= "INSERT INTO product(productname,productdesc,productprice,productimage) VALUES(?,?,?,?)";
		int checkUpdate=jdbcTemplate.update(prepstmt,new Object[] {product.getProductName(),product.getProductDesc(),product.getProductPrice(),product.getProductImage()});
		if(checkUpdate>0) {
			System.out.println("A New Product has been created!");
		}
	}
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		String query="SELECT * from product WHERE productId=?";
		Product sycliq=jdbcTemplate.queryForObject(query, new ProductRowMapper(),productId);
		return sycliq;
	}
	public void deleteProductById(int productId) {
		// TODO Auto-generated method stub
		String query = "DELETE from product where productid=?";
		int count=jdbcTemplate.update(query,productId );
		if(count>0) {
			System.out.println("A Single Product Record has been deleted!");
		}
	}

	public void updateProductById(int productId) {
		// TODO Auto-generated method stub

		String updateQuery="UPDATE product  where productid=?";
		int changeNo=jdbcTemplate.update(updateQuery, productId);
		if(changeNo>0) {
			System.out.println("ProductId was updated");
		}
	}

	public List<Product> getAllProductDetails() {
		// TODO Auto-generated method stub
		String myquery = "SELECT * FROM product";
		return jdbcTemplate.query(myquery, new ProductRowMapper());
		
	}

}
