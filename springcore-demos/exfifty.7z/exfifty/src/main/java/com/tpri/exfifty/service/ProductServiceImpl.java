package com.tpri.exfifty.service;

import java.util.List;
import com.tpri.exfifty.dao.IProductDAO;
import com.tpri.exfifty.model.Product;

public class ProductServiceImpl implements IProductService {
	private IProductDAO iproductDAO;
	public void setIproductDAO(IProductDAO iproductDAO) {
		this.iproductDAO = iproductDAO;
	}
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		iproductDAO.createProduct(product);
	}
	public Product fetchProductById(int productId) {
		// TODO Auto-generated method stub
		return iproductDAO.getProductById(productId);
	}
	public void removeProductById(int productId) {
		// TODO Auto-generated method stub
		iproductDAO.deleteProductById(productId);
	}
	public void changeProductById(int productId) {
		// TODO Auto-generated method stub
		iproductDAO.updateProductById(productId);
	}
	public List<Product> fetchAllProductDetails() {
		// TODO Auto-generated method stub
		return iproductDAO.getAllProductDetails();
	}
}
