/**
 * 
 */
package com.tpri.exfifty;
import java.util.List;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.tpri.exfifty.model.Product;
import com.tpri.exfifty.service.ProductServiceImpl;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ApplicationFifty: Spring JDBC Demo2 with JDBC Template");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfifty.xml");
		ProductServiceImpl sycliqone = (ProductServiceImpl)context.getBean("productService");
		Product sycliq = new Product();
		sycliq.setProductName("SycliQPrimeOne");
		sycliq.setProductDesc("Hyperlocal Sensing Platform for Crop Life Cycle Intelligence in real-time");
		sycliq.setProductPrice("3400 USD");
		sycliq.setProductImage("http://www.sycliq.com");
		sycliqone.addProduct(sycliq);
		//fetching the records by id
		Product iot=sycliqone.fetchProductById(25);
		System.out.println(iot.getProductId()+"\t"+iot.getProductName()+"\t"+iot.getProductDesc());
		//fetching all records
		System.out.println("printing all records");
		List<Product> prodList = sycliqone.fetchAllProductDetails();
		for(Product product:prodList) {
			
			System.out.println(iot.getProductId()+"\t"+iot.getProductName()+"\t"+iot.getProductDesc());
		}
		context.close();
	}
}
