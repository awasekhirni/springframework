/**
 * 
 */
package com.tpri.extwentyfour;

/**
 * @author Awase Khirni Syed
 *
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class AppTwentyFourMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("BeanDefinition Inheritance: List Merge Demo!");
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("apptwentyfour.xml");
		ShoppingCart snapdeal=(ShoppingCart)appcontext.getBean("snapdealBean");
		System.out.println("Bean Definition Inheritance List Display(Post merging): "+snapdeal);
		
		
	}

}
