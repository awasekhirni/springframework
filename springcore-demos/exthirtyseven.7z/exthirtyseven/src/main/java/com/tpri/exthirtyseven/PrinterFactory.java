/**
 * 
 */
package com.tpri.exthirtyseven;

/**
 * @author Awase Khirni Syed
 *
 */
public class PrinterFactory {
	
	
	public static Printer getPrinter() {
		return new Printer();
	}

}
