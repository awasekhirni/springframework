/**
 * 
 */
package com.tpri.exthirtyseven;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtySevenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppThirtySevenMain:Dependency Injection using Factory Method");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtyseven.xml");
		
		ATM  csfb=(ATM)context.getBean("atm");
		csfb.printAccountBalance("ca17127642987236723");
		context.close();
	}

}
