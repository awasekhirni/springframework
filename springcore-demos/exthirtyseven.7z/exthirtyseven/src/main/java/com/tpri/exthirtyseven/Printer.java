package com.tpri.exthirtyseven;

public class Printer {

	
	public void accountBalance(String accountNumber) {
		System.out.println("Your Savings Account Balance amount is: 1000,0000 for the account:"+accountNumber);;
	}
}
