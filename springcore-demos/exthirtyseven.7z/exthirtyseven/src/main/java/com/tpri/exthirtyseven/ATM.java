/**
 * 
 */
package com.tpri.exthirtyseven;

/**
 * @author Awase Khirni Syed
 *
 */
public class ATM {
	
	private Printer printer;

	public Printer getPrinter() {
		return printer;
	}

	public void setPrinter(Printer printer) {
		this.printer = printer;
	}
	
	
	public void printAccountBalance(String accountNumber) {
		getPrinter().accountBalance(accountNumber);
	}
	

}
