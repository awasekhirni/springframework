/**
 * 
 */
package com.tpri.exeightcorespringprj;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author Awase Khirni Syed
 *
 */
public class GameScore {
	
	private Map scoredata;
	
	public void setGameScore(Map scoredata) {
		this.scoredata = scoredata;
	}
	
	public void displayScore() {
		Set s=scoredata.entrySet();
		Iterator it=s.iterator();
		while(it.hasNext()) {
			   Map.Entry me = (Map.Entry)it.next();

			   System.out.println(me.getKey()+ " - " +me.getValue());
			   
		}
	}
}
