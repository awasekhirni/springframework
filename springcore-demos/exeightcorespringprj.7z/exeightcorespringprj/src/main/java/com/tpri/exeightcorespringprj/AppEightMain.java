/**
 * 
 */
package com.tpri.exeightcorespringprj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exeightcorespringprj.GameScore;
/**
 * @author Awase Khirni Syed
 *
 */
public class AppEightMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppEightMain Demo!");
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appeight.xml");
		GameScore gs = (GameScore)context.getBean("gamescoreBean");
		gs.displayScore();
		

	}

}
