/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortySixMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortysix.xml");
		Company sycliq=(Company)context.getBean("company");
		System.out.println("AppFortySix: Spring Expression Language Demo");
		System.out.println("CompanyInformation_________________________________");
		System.out.println(sycliq.getCompanyId()+"\t"+sycliq.getCompanyName());
		Employee emp =(Employee)context.getBean("employee");
		System.out.println("EmployeeInformation-------------------------------------");
		System.out.println(emp.getEmpId()+"\t"+emp.getEmpFullName());
		Spello ello=(Spello)context.getBean("spello");
		System.out.println("SpelloInformation-------------------------------------");
		System.out.println(ello.isAndCondition()+"\t"+ ello.isAndConditionOpr()+"\t"+ello.isNotCondition()+"\t"+ello.isNotConditionOpr()+"\t"+ello.isOrConditionOpr());
		Konditional con = (Konditional)context.getBean("konditional");
		System.out.println(con.getTernaryConditional()+"\t"+con.getOtherTernary());
		System.out.println(con.isAlphabetCheck()+"\t"+con.isInvalidAlphabet()+"\t"+con.isInvalidNumeric()+"\t"+con.isNumericCheck());
		
		context.close();
	}

}
