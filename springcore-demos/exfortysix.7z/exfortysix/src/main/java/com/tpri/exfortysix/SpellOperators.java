/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("spelloperators")
public class SpellOperators {
	
	@Value("#{2536==21761}")
	private boolean checkEquality;
	@Value("#{2823 eq 2823}")
	private boolean checkEqualOperator;
	@Value("#{12783 != 329234}")
	private boolean checkInequality;
	@Value("#{73638 ne 92982}")
	private boolean checkInequalityOperator;
	@Value("#{27 < 78}")
	private boolean checkLessthan;
	@Value("#{27 lt 78}")
	private boolean checkLessthanOperator;
	
	public boolean isCheckEquality() {
		return checkEquality;
	}
	public void setCheckEquality(boolean checkEquality) {
		this.checkEquality = checkEquality;
	}
	public boolean isCheckEqualOperator() {
		return checkEqualOperator;
	}
	public void setCheckEqualOperator(boolean checkEqualOperator) {
		this.checkEqualOperator = checkEqualOperator;
	}
	public boolean isCheckInequality() {
		return checkInequality;
	}
	public void setCheckInequality(boolean checkInequality) {
		this.checkInequality = checkInequality;
	}
	public boolean isCheckInequalityOperator() {
		return checkInequalityOperator;
	}
	public void setCheckInequalityOperator(boolean checkInequalityOperator) {
		this.checkInequalityOperator = checkInequalityOperator;
	}
	public boolean isCheckLessthan() {
		return checkLessthan;
	}
	public void setCheckLessthan(boolean checkLessthan) {
		this.checkLessthan = checkLessthan;
	}
	public boolean isCheckLessthanOperator() {
		return checkLessthanOperator;
	}
	public void setCheckLessthanOperator(boolean checkLessthanOperator) {
		this.checkLessthanOperator = checkLessthanOperator;
	}
	public boolean isCheckLessthanOrequal() {
		return checkLessthanOrequal;
	}
	public void setCheckLessthanOrequal(boolean checkLessthanOrequal) {
		this.checkLessthanOrequal = checkLessthanOrequal;
	}
	public boolean isCheckLessthanOrEqualOperator() {
		return checkLessthanOrEqualOperator;
	}
	public void setCheckLessthanOrEqualOperator(boolean checkLessthanOrEqualOperator) {
		this.checkLessthanOrEqualOperator = checkLessthanOrEqualOperator;
	}
	public boolean isCheckGreater() {
		return checkGreater;
	}
	public void setCheckGreater(boolean checkGreater) {
		this.checkGreater = checkGreater;
	}
	public boolean isCheckGreaterThanOperator() {
		return checkGreaterThanOperator;
	}
	public void setCheckGreaterThanOperator(boolean checkGreaterThanOperator) {
		this.checkGreaterThanOperator = checkGreaterThanOperator;
	}
	public boolean isCheckGreaterthanOrEqual() {
		return checkGreaterthanOrEqual;
	}
	public void setCheckGreaterthanOrEqual(boolean checkGreaterthanOrEqual) {
		this.checkGreaterthanOrEqual = checkGreaterthanOrEqual;
	}
	public boolean isCheckGreaterThanOrEqualOperator() {
		return checkGreaterThanOrEqualOperator;
	}
	public void setCheckGreaterThanOrEqualOperator(boolean checkGreaterThanOrEqualOperator) {
		this.checkGreaterThanOrEqualOperator = checkGreaterThanOrEqualOperator;
	}
	@Value("#{27 <= 78}")
	private boolean checkLessthanOrequal;
	@Value("#{27 le 78}")
	private boolean checkLessthanOrEqualOperator;
	@Value("#{27 > 78}")
	private boolean checkGreater;
	@Value("#{28 gt 78}")
	private boolean checkGreaterThanOperator;
	@Value("#{28 >= 78}")
	private boolean checkGreaterthanOrEqual;
	@Value("#{28 ge 8}")
	private boolean checkGreaterThanOrEqualOperator;
	
}
