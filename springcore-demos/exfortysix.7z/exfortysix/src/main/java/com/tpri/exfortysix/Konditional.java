/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("konditional")
public class Konditional {
	@Value("#{278 > 118 ? 'true' : 'false'}")
	private String ternaryConditional;
	@Value("#{425<252? 'high':'low' }")
	private String otherTernary;
	
	//regex
	@Value("#{'3671' matches '\\d+'}")
	private boolean numericCheck;
	@Value("#{'3671Jonah' matches '\\d+'}")
	private boolean invalidNumeric;
	@Value("#{'goodword' matches '[a-zA-Z\\s]+'}")
	private boolean alphabetCheck;
	@Value("#{'notgood $1' matches '[a-zA-Z\\\\s]+'}")
	private boolean invalidAlphabet;
	
	public String getTernaryConditional() {
		return ternaryConditional;
	}
	public void setTernaryConditional(String ternaryConditional) {
		this.ternaryConditional = ternaryConditional;
	}
	public String getOtherTernary() {
		return otherTernary;
	}
	public void setOtherTernary(String otherTernary) {
		this.otherTernary = otherTernary;
	}
	public boolean isNumericCheck() {
		return numericCheck;
	}
	public void setNumericCheck(boolean numericCheck) {
		this.numericCheck = numericCheck;
	}
	public boolean isInvalidNumeric() {
		return invalidNumeric;
	}
	public void setInvalidNumeric(boolean invalidNumeric) {
		this.invalidNumeric = invalidNumeric;
	}
	public boolean isAlphabetCheck() {
		return alphabetCheck;
	}
	public void setAlphabetCheck(boolean alphabetCheck) {
		this.alphabetCheck = alphabetCheck;
	}
	public boolean isInvalidAlphabet() {
		return invalidAlphabet;
	}
	public void setInvalidAlphabet(boolean invalidAlphabet) {
		this.invalidAlphabet = invalidAlphabet;
	}
	
}
