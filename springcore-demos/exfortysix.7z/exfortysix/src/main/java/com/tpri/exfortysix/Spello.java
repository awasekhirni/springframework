/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("spello")
public class Spello {
	//logical operations
	@Value("#{2500>2000 && 2000<4000}")
	private boolean andCondition;
	
	@Value("#{2500>2000 and 2000<4000}")
	private boolean andConditionOpr;
	
	@Value("#{500>388 || 150<165}")
	private boolean orCondition;
	
	@Value("#{500>388 or 150<165}")
	private boolean orConditionOpr;
	
	@Value("#{!false}")
	private boolean notCondition;
	@Value("#{not false}")
	private boolean notConditionOpr;

	public boolean isAndCondition() {
		return andCondition;
	}

	public void setAndCondition(boolean andCondition) {
		this.andCondition = andCondition;
	}

	public boolean isAndConditionOpr() {
		return andConditionOpr;
	}

	public void setAndConditionOpr(boolean andConditionOpr) {
		this.andConditionOpr = andConditionOpr;
	}

	public boolean isOrCondition() {
		return orCondition;
	}

	public void setOrCondition(boolean orCondition) {
		this.orCondition = orCondition;
	}

	public boolean isOrConditionOpr() {
		return orConditionOpr;
	}

	public void setOrConditionOpr(boolean orConditionOpr) {
		this.orConditionOpr = orConditionOpr;
	}

	public boolean isNotCondition() {
		return notCondition;
	}

	public void setNotCondition(boolean notCondition) {
		this.notCondition = notCondition;
	}

	public boolean isNotConditionOpr() {
		return notConditionOpr;
	}

	public void setNotConditionOpr(boolean notConditionOpr) {
		this.notConditionOpr = notConditionOpr;
	}

	
	
	

}
