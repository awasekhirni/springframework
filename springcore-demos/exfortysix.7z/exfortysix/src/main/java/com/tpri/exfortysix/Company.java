/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("company")
public class Company {
	@Value("8371287")
	private Integer companyId;
	@Value("SYCLIQ GEOSPATIAL PVT LTD")
	private String companyName;
	
	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
}
