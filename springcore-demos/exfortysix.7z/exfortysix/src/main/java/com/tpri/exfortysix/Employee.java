/**
 * 
 */
package com.tpri.exfortysix;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("employee")
public class Employee {

	@Value("712376")
	private Integer empId;
	@Value("Awase Khirni")
	private String empFirstName;
	@Value("Syed")
	private String empLastName;
	
	@Value("#{employee.empFirstName.concat(' ').concat(employee.empLastName)}")
	private String empFullName;

	public Integer getEmpId() { 		return empId; 	}
	public void setEmpId(Integer empId) { 		this.empId = empId; 	}
	public String getEmpFirstName() { 		return empFirstName; 	}
	public void setEmpFirstName(String empFirstName) { 		this.empFirstName = empFirstName; 	}
	public String getEmpLastName() { 		return empLastName;	}
	public void setEmpLastName(String empLastName) {		this.empLastName = empLastName; 	}
	public String getEmpFullName() { 		return empFullName; 	}
	public void setEmpFullName(String empFullName) { 		this.empFullName = empFullName; 	}
	
}
