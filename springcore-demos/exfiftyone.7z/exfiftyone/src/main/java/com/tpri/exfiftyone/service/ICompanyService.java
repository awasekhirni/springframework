package com.tpri.exfiftyone.service;

import java.util.List;

import com.tpri.exfiftyone.model.Company;
public interface ICompanyService {

	//abstract methods => CRUD operations
	public abstract void addCompany(Company company);
	public abstract Company fetchCompanyById(int companyId);
	public abstract void removeCompanyById(int companyId);
	public abstract void changeCompanyById(int companyId,String name,String businessdomain, String address,String capital);
	public abstract List<Company> fetchAllCompanyDetails();
}
