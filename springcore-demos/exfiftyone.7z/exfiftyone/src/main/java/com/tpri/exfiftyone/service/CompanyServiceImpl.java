package com.tpri.exfiftyone.service;

import java.util.List;
import com.tpri.exfiftyone.dao.ICompanyDAO;
import com.tpri.exfiftyone.model.Company;

public class CompanyServiceImpl implements ICompanyService {
	public ICompanyDAO icompanyDAO;
	public void setIcompanyDAO(ICompanyDAO icompanyDAO) {
		this.icompanyDAO = icompanyDAO;
	}

	public void addCompany(Company company) {
		// TODO Auto-generated method stub
		icompanyDAO.createCompany(company);
	}

	public Company fetchCompanyById(int companyId) {
		// TODO Auto-generated method stub
		return icompanyDAO.getCompanyById(companyId);
	}

	public void removeCompanyById(int companyId) {
		// TODO Auto-generated method stub
		icompanyDAO.deleteCompanyById(companyId);
	}

	public void changeCompanyById(int companyId,String name,String businessdomain, String address,String capital) {
		// TODO Auto-generated method stub
		icompanyDAO.updateCompanyById(companyId,name, businessdomain, address, capital);
	}

	public List<Company> fetchAllCompanyDetails() {
		// TODO Auto-generated method stub
		return icompanyDAO.getAllCompanyDetails();
	}
}




