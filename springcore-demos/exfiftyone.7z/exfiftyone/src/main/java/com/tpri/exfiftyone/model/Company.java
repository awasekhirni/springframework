/**
 * 
 */
package com.tpri.exfiftyone.model;
/** * @author Awase Khirni Syed * */
public class Company {
	private int id;
	private String name;
	private String businessdomain;
	private String address;
	private double capital;
	public int getId() {		return id;	}
	public void setId(int id) {		this.id = id; 	}
	public String getName() {		return name; 	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBusinessdomain() {
		return businessdomain;
	}
	public void setBusinessdomain(String businessdomain) {
		this.businessdomain = businessdomain;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getCapital() {
		return capital;
	}
	public void setCapital(double capital) {
		this.capital = capital;
	}
	
}
