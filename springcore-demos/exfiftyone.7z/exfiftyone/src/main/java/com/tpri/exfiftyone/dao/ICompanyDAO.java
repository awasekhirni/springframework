package com.tpri.exfiftyone.dao;

import java.util.List;
import com.tpri.exfiftyone.model.Company;
public interface ICompanyDAO {

	//abstract methods => CRUD operations
	public abstract void createCompany(Company company);
	public abstract Company getCompanyById(int companyId);
	public abstract void deleteCompanyById(int companyId);
	public abstract void updateCompanyById(int companyId,String name,String businessdomain, String address,String capital);
	public abstract List<Company> getAllCompanyDetails();
}
