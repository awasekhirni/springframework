package com.tpri.exfiftyone.dao;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import com.tpri.exfiftyone.model.Company;

public class CompanyDAOImpl implements ICompanyDAO {

	public DataSource dataSource;
	public JdbcTemplate jdbcTemplate;
	
	private final String SQL_FIND_COMPANY="select * from company where id = ?";
	private final String SQL_DELETE_COMPANY="delete from company where id = ?";
	private final String SQL_UPDATE_COMPANY="update company set name = ?, businessdomain = ?, address  = ?,capital=? where id = ?";
	private final String SQL_GETALL_COMPANIES="select * from company";
	private final String SQL_INSERT_COMPANY="insert into company(id,name,businessdomain,address,capital)  values(?,?,?,?,?)";
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	public void createCompany(Company company) {
		// TODO Auto-generated method stub
		int checkUpdate=jdbcTemplate.update(SQL_INSERT_COMPANY,new Object[] {company.getId(),company.getName(),company.getBusinessdomain(),
				company.getAddress(),company.getCapital()});
		if(checkUpdate>0) {
			System.out.println("A New Product has been created!");
		}
	}

	public Company getCompanyById(int companyId) {
		// TODO Auto-generated method stub
		Company mycompany=jdbcTemplate.queryForObject(SQL_FIND_COMPANY, new CompanyRowMapper(),companyId);
		return mycompany;
	}

	public void deleteCompanyById(int companyId) {
		// TODO Auto-generated method stub
		int count=jdbcTemplate.update(SQL_DELETE_COMPANY,companyId );
		if(count>0) {
			System.out.println("A Single Company Record has been deleted!");
		}
	}

	public void updateCompanyById(int companyId,String name,String businessdomain, String address,String capital) {
		// TODO Auto-generated method stub
		int changeNo=jdbcTemplate.update(SQL_UPDATE_COMPANY, companyId);
		if(changeNo>0) {
			System.out.println("ProductId was updated");
		}
	}

	public List<Company> getAllCompanyDetails() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GETALL_COMPANIES, new CompanyRowMapper());
	}

}
