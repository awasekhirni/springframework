/**
 * 
 */
package com.tpri.exfiftyone;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfiftyone.model.Company;
import com.tpri.exfiftyone.service.CompanyServiceImpl;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFiftyOne-Spring JdbcTemplate with Postgres Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfiftyone.xml");
		
		CompanyServiceImpl csmpl=(CompanyServiceImpl)context.getBean("companyService");
		Company tpri = new Company();
		tpri.setId(126881237);
		tpri.setName("Territorial Prescience Research I Pvt Ltd");
		tpri.setBusinessdomain("IOT,Analytics,GIR,GIS,GeospatialIntelligence");
		tpri.setAddress("Cessna Business Park,Bangalore");
		tpri.setCapital(500000.00);
		csmpl.addCompany(tpri);
		
		
		context.close();
	}

}
