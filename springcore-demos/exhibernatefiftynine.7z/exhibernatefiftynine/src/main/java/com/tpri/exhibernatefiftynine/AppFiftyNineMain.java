/**
 * 
 */
package com.tpri.exhibernatefiftynine;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.tpri.exhibernatefiftynine.model.Book;
import com.tpri.exhibernatefiftynine.model.Publisher;


/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyNineMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration = new Configuration();
		SessionFactory sessionFactory = configuration.configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Publisher publisher = new Publisher();
		publisher.setName("FirstBlood");
		session.save(publisher);
		transaction.commit();
		transaction = session.beginTransaction();
		Book book = new Book();
		book.setTitle("John Rambo");
		book.setPublisher(publisher);
		session.save(book);
		transaction.commit();
		session.close();
	}

}
