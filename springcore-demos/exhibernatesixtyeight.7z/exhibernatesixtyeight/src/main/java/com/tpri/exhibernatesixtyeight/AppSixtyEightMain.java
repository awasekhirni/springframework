/**
 * 
 */
package com.tpri.exhibernatesixtyeight;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtyeight.model.Employee;
import com.tpri.exhibernatesixtyeight.model.Project;
import com.tpri.exhibernatesixtyeight.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtyEightMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Session session = HibernateUtilities.getSessionFactory().openSession()) {
	    	session.beginTransaction();
	    	Employee employee= new Employee();
	    	employee.setFirstName("Awase Khirni");
	    	employee.setLastName("Syed");
	    	
	    	Project project1= new Project();
	    	project1.setProjectTitle("SycliQ");
	    	
	    	
	    	Project project2= new Project();
	    	project2.setProjectTitle("TruEstate");
	    	
	    	project1.setEmployee(employee);
	    	project2.setEmployee(employee);
	    	session.save(project1);
	    	session.save(project2);
	    	session.persist(employee);
	    	session.getTransaction().commit();
		}catch (HibernateException e) {
			e.printStackTrace();
		}
	}

}
