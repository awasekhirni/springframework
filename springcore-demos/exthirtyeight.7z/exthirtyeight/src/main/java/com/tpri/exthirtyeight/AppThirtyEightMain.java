/**
 * 
 */
package com.tpri.exthirtyeight;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyEightMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppThirtyEight:@Required Annotation Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtyeight.xml");
	    Employee emp =(Employee)context.getBean("empBean");
	    System.out.println("id:"+ emp.getEmpId());
	    System.out.println("Name:"+ emp.getEmpName());
	    System.out.println("SSID:"+ emp.getEmpSSID());
	    
	    System.out.println("Email:"+ emp.getEmpEmail());
	    
	    context.close();
	
	}

}
