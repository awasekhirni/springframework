/**
 * 
 */
package com.tpri.exthirtyeight;

import org.springframework.beans.factory.annotation.Required;

/**
 * @author Awase Khirni Syed
 *
 */
public class Employee {
	private int empId;
	private String empName;
	private String empEmail;
	private String empSSID;
	public int getEmpId() { 		return empId; 	}
	@Required
	public void setEmpId(int empId) { 		this.empId = empId; 	}
	public String getEmpName() { 		return empName;	}
	@Required
	public void setEmpName(String empName) {		this.empName = empName; 	}
	public String getEmpEmail() { 		return empEmail; 	}
	@Required
	public void setEmpEmail(String empEmail) {		this.empEmail = empEmail; 	}
	
	public String getEmpSSID() { 		return empSSID; 	}
	@Required
	public void setEmpSSID(String empSSID) { 		this.empSSID = empSSID; 	}
	
}
