/**
 * 
 */
package com.tpri.exfourteencorepsringprj;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFourteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"appfourteen.xml"});
        Hospital specialistKalyanNagar = (Hospital)context.getBean("hospitalBean");
        specialistKalyanNagar.displayHospitalInfo();
        context.close();
	
	}

}
