/**
 * 
 */
package com.tpri.exfourteencorepsringprj;

//importing the interfaces 
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;


/**
 * @author Awase Khirni Syed
 *
 */
public class Hospital implements InitializingBean,DisposableBean {
	
	
	public void displayHospitalInfo() {
		System.out.println("App14:Display Hospital Information!");
	}
	
	
	public void afterPropertiesSet() throws Exception{
		System.out.println("Init method after properties are set : " );
	}
	
	
	public void destroy() throws Exception{
		System.out.println("Spring Container Destroy method is called in! " );
	}
	
}
