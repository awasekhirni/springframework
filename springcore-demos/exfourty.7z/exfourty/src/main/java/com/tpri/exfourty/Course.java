/**
 * 
 */
package com.tpri.exfourty;

/**
 * @author Awase Khirni Syed
 *
 */
public class Course {

	private int courseId;
	private String courseTitle;
	private String courseCoordinator;
	private int courseCredits; 
	public int getCourseId() { 		return courseId; 	}
	public void setCourseId(int courseId) { 		this.courseId = courseId; 	}
	public String getCourseTitle() { 		return courseTitle; 	}
	public void setCourseTitle(String courseTitle) { 		this.courseTitle = courseTitle; 	}
	public String getCourseCoordinator() { 		return courseCoordinator; 	}
	public void setCourseCoordinator(String courseCoordinator) { 		this.courseCoordinator = courseCoordinator; 	}
	public int getCourseCredits() { 		return courseCredits; 	}
	public void setCourseCredits(int courseCredits) { 		this.courseCredits = courseCredits; }
	
	
}
