package com.tpri.exfourty;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Program {
	private int programId;
	private String programTitle;
	private String programCoordinator;
	private Course course;
	
	public String getProgramCoordinator() {		return programCoordinator;	}
	public int getProgramId() {		return programId;	}
	public String getProgramTitle() {		return programTitle;	}
	public Course getCourse() {		return course;	}
	
	@Autowired
	public Program(int programId, String programTitle, String programCoordinator, Course course) {
		super();
		this.programId = programId;
		this.programTitle = programTitle;
		this.programCoordinator = programCoordinator;
		this.course = course;
	}
	
}
