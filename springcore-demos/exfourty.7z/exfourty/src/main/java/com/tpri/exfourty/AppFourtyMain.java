/**
 * 
 */
package com.tpri.exfourty;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFourtyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFortyMain:@Autowired before Constructor!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfourty.xml");
		Program gis=(Program)context.getBean("programBean");
		System.out.println("Program Information!");
		System.out.println(gis.getProgramTitle());
		System.out.println(gis.getCourse().getCourseId()+"\t"+gis.getCourse().getCourseTitle()+"\t"+gis.getCourse().getCourseCoordinator());
		context.close();
	}

}
