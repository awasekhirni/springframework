/**
 * 
 */
package com.tpri.extwentytwocore;

/**
 * @author Awase Khirni Syed
 *
 */
public class CartItem {

	public String cartItemId;
	public String cartItemName;
	public String cartItemPrice;
	public String cartItemQty;

	public String getCartItemId() { 		return cartItemId; 	}

	public void setCartItemId(String cartItemId) { 		this.cartItemId = cartItemId; 	}

	public String getCartItemName() { 		return cartItemName; 	}

	public void setCartItemName(String cartItemName) { 		this.cartItemName = cartItemName;	}

	public String getCartItemPrice() { 		return cartItemPrice; 	}

	public void setCartItemPrice(String cartItemPrice) { 		this.cartItemPrice = cartItemPrice; 	}

	public String getCartItemQty() { 		return cartItemQty; 	}

	public void setCartItemQty(String cartItemQty) {		this.cartItemQty = cartItemQty; 	}

	

}
