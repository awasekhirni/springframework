/**
 * 
 */
package com.tpri.extwentytwocore;

/**
 * @author Awase Khirni Syed
 *
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTwentyTwoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppTwentyTwoMain: ApplicationContextAware Demo!");
		ApplicationContext appContext = new ClassPathXmlApplicationContext("apptwentytwo.xml");
		ShoppingCart amazoncart=(ShoppingCart)appContext.getBean("amazonBean");
		amazoncart.displayShoppingCartData();
	}

}
