/**
 * 
 */
package com.tpri.extwentytwocore;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
/**
 * @author Awase Khirni Syed *
 */
public class ShoppingCart implements ApplicationContextAware,BeanNameAware{
	private CartItem itemA;
	private CartItem itemB;
	private CartItem itemC;
	private ApplicationContext appContext=null;
	
	public CartItem getItemA() { 		return itemA; 	}
	public void setItemA(CartItem itemA) { 		this.itemA = itemA; 	}
	public CartItem getItemB() { 		return itemB; 	}
	public void setItemB(CartItem itemB) { 		this.itemB = itemB; 	}
	public CartItem getItemC() { 		return itemC; 	}
	public void setItemC(CartItem itemC) { 		this.itemC = itemC; 	}
	public void displayShoppingCartData() {
		System.out.println("itemA:{"+ itemA.getCartItemId()+ ","+ itemA.getCartItemName()+ ","+itemA.getCartItemPrice()+","+ itemA.getCartItemQty()+"}");
		System.out.println("itemB:{"+ itemB.getCartItemId()+ ","+ itemB.getCartItemName()+ ","+itemB.getCartItemPrice()+","+ itemB.getCartItemQty()+"}");
		System.out.println("itemC:{"+ itemC.getCartItemId()+ ","+ itemC.getCartItemName()+ ","+itemC.getCartItemPrice()+","+ itemC.getCartItemQty()+"}");
			}
	
	public void setApplicationContext(ApplicationContext appContext) throws BeansException { 		// TODO Auto-generated method stub
		this.appContext = appContext;
	}
	
	public void setBeanName(String beanName) {
		// TODO Auto-generated method stub
		//to fetch the name of the bean 
		System.out.println("Printing the bean Name, before execution of the application:"+beanName);	
	}
}
