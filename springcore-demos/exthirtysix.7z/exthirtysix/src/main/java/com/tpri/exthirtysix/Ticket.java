/**
 * 
 */
package com.tpri.exthirtysix;

/**
 * @author Awase Khirni Syed
 *
 */
public class Ticket {

	public int ticketId;
	public String ticketStart;
	public String ticketDestination;
	public int ticketPrice;
	public int getTicketId() { 		return ticketId; 	}

	public void setTicketId(int ticketId) { 		this.ticketId = ticketId; 	}

	public String getTicketStart() { 		return ticketStart; 	}

	public void setTicketStart(String ticketStart) { 		this.ticketStart = ticketStart; 	}

	public String getTicketDestination() { 		return ticketDestination; 	}

	public void setTicketDestination(String ticketDestination) { 		this.ticketDestination = ticketDestination; 	}

	public int getTicketPrice() { 		return ticketPrice; 	}

	public void setTicketPrice(int ticketPrice) { 		this.ticketPrice = ticketPrice; 	}

	public String printTicket() { 		return "Ticket has been printed!"; 	}
	
}
