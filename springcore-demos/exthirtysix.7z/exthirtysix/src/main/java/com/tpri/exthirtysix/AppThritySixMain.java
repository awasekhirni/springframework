/**
 * 
 */
package com.tpri.exthirtysix;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThritySixMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppThirtySixMain: Spring Method Injection!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtysix.xml");
	
		VendingMachine vm=(VendingMachine)context.getBean("vendingmachineBean");
		
		//method call
		Ticket alleskarte=vm.generateTicket();
		System.out.println(alleskarte.printTicket());
		context.close();
	}

}
