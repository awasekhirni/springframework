/**
 * 
 */
package com.tpri.exthirtysix;

/**
 * @author Awase Khirni Syed
 *
 */
public  abstract class VendingMachine {

	
	
	public abstract Ticket generateTicket();
	
}
