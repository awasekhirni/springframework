/**
 * 
 */
package com.tpri.exthirteen;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appthirteen.xml");
		
		Hotel leelaPalace=(Hotel)context.getBean("hotelBean");
		leelaPalace.displayHotelInfo();
		
		//closing the application context 
		((AbstractApplicationContext)context).registerShutdownHook();

	}

}
