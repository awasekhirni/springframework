/**
 * 
 */
package com.tpri.exthirteen;

//annotation import 
import javax.annotation.PreDestroy;
import javax.annotation.PostConstruct;

/**
 * @author Awase Khirni Syed
 *
 */
public class Hotel {
	
	public void displayHotelInfo() {
		System.out.println("App-Thirteen: Displaying hotel information");
	}

	
	//Spring lifecyle bean methods 
	//with annotations
	@PostConstruct
	public void init() {
		System.out.println("App-Thirteen:Annotations for Init Called");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("App-Thirteen:Annotations for Destroy Called");
	}
}
