package com.tpri.ExoneCoreSpringPrj.HelloWorld;
//spring dependencies
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//end of spring dependencies
//helloworldservice importing here
import com.tpri.ExoneCoreSpringPrj.services.HelloWorldService; 
 
public class HelloWorld {
 
	@SuppressWarnings("resource")
	public static void main(String[] args) {
 
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
 
		HelloWorldService service = (HelloWorldService) context
				.getBean("helloWorldService");
		String message = service.sayHello();
		System.out.println(message);
 
		//set a new name
		service.setName("SYCLIQ/TPRI");
		message = service.sayHello();
		System.out.println(message);
	}
}