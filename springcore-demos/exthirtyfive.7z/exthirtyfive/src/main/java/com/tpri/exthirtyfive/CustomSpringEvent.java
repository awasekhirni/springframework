/**
 * 
 */
package com.tpri.exthirtyfive;

import org.springframework.context.ApplicationEvent;

/**
 * @author Awase Khirni Syed
 *
 */
public class CustomSpringEvent extends ApplicationEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CustomSpringEvent(Object source) {
	      super(source);
	   }
	   public String toString(){
	      return "My Custom Spring Event";
	   }
}
