/**
 * 
 */
package com.tpri.exthirtyfive;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

/**
 * @author Awase Khirni Syed
 *
 */
public class CustomSpringEventPublisher implements ApplicationEventPublisherAware {
	   private ApplicationEventPublisher publisher;
	   
	   public void setApplicationEventPublisher (ApplicationEventPublisher publisher) {
	      this.publisher = publisher;
	   }
	   public void publish() {
	      CustomSpringEvent ce = new CustomSpringEvent(this);
	      publisher.publishEvent(ce);
	   }
	}