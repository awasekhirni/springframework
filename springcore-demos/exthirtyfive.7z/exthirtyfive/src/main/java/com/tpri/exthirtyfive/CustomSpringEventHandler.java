/**
 * 
 */
package com.tpri.exthirtyfive;

import org.springframework.context.ApplicationListener;

/**
 * @author Awase Khirni Syed
 *
 */
public class CustomSpringEventHandler implements ApplicationListener<CustomSpringEvent> {
	public void onApplicationEvent(CustomSpringEvent event) {
		System.out.println(event.toString());
	}
}