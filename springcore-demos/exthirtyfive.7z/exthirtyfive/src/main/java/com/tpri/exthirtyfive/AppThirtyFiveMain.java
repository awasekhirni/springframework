/**
 * 
 */
package com.tpri.exthirtyfive;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyFiveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationEvent ae = null;
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtyfive.xml");
		
		CustomSpringEventPublisher csep=(CustomSpringEventPublisher)context.getBean("publisherBean");
		
		csep.publish();
		
		context.close();
	}

}
