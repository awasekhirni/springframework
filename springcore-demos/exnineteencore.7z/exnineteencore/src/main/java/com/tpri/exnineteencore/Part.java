/**
 * 
 */
package com.tpri.exnineteencore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Part {
	
	public String itemId;
	public String itemName;
	public String itemDescription;
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

}
