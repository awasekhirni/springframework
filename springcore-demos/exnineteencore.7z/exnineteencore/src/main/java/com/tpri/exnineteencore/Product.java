/**
 * 
 */
package com.tpri.exnineteencore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Product {
	public Part body;
	public Part gear;
	public Part brakes;
	public Part seats;
	public Part wheels;

	public Part getBody() { 	return body; 	}
	public void setBody(Part body) { this.body = body; 	}
	public Part getGear() { 		return gear; 	}
	public void setGear(Part gear) { 		this.gear = gear; 	}
	public Part getBrakes() { 		return brakes; 	}
	public void setBrakes(Part brakes) { 		this.brakes = brakes; 	}
	public Part getSeats() { 		return seats; 	}
	public void setSeats(Part seats) { 		this.seats = seats; 	}
	public Part getWheels() { 		return wheels; 	}
	public void setWheels(Part wheels) { 		this.wheels = wheels; 	}
	public void displayProductInfo() {
		System.out.println("ProductInfo:");
		System.out.println("bodyInfo:"+getBody().getItemId()+","+getBody().getItemName()+","+getBody().getItemDescription()+"}");
		System.out.println("gearInfo:"+getGear().getItemId()+","+getGear().getItemName()+","+getGear().getItemDescription()+"}");
		System.out.println("brakesInfo:"+getBrakes().getItemId()+","+getBrakes().getItemName()+","+getBrakes().getItemDescription()+"}");
		System.out.println("seatsInfo:"+getSeats().getItemId()+","+getSeats().getItemName()+","+getSeats().getItemDescription()+"}");
		System.out.println("wheelsInfo:"+getWheels().getItemId()+","+getWheels().getItemName()+","+getWheels().getItemDescription()+"}");	
	}
}
