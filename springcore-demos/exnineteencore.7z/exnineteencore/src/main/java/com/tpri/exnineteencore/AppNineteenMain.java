/**
 * 
 */
package com.tpri.exnineteencore;

/**
 * @author Awase Khirni Syed
 *
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppNineteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppNineteenMain: InnerBean, Alias and IdRef Demo!");
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("appnineteen.xml");
		Product fortuner=(Product)appcontext.getBean("productBean");
		fortuner.displayProductInfo();

	}

}
