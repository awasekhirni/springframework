/**
 * 
 */
package com.tpri.exthirtynine;

/**
 * @author Awase Khirni Syed
 *
 */
public class Order {
	private int orderId;
	private String orderItem;
	private int orderPrice;
	public int getOrderId() { 		return orderId;	}
	public void setOrderId(int orderId) { 		this.orderId = orderId; 	}
	public String getOrderItem() { 		return orderItem; 	}
	public void setOrderItem(String orderItem) { 		this.orderItem = orderItem; 	}
	public int getOrderPrice() { 		return orderPrice; 	}
	public void setOrderPrice(int orderPrice) { 		this.orderPrice = orderPrice; 	}
	
}
