/**
 * 
 */
package com.tpri.exthirtynine;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyNineMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppThirtyNineMain: Autowired Annotation Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirtynine.xml"); 
		
		Customer aicy = (Customer)context.getBean("customerBean");
		
		System.out.println("Customer Information!");
		System.out.println(aicy.getCustomerName());
		System.out.println("Printing Order  Information!");
		System.out.println(aicy.getOrder().getOrderId()+"\t"+aicy.getOrder().getOrderItem()+ "\t"+aicy.getOrder().getOrderPrice());
		context.close();
	
	}

}
