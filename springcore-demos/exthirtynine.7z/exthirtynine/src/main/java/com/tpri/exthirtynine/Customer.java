/**
 * 
 */
package com.tpri.exthirtynine;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Awase Khirni Syed
 *
 */
public class Customer {
	private int customerId;
	private String customerName;
	private String customerEmail;
	
	@Autowired
	private Order Order;
	
	public int getCustomerId() {	return customerId;	}
	public void setCustomerId(int customerId) {		this.customerId = customerId;	}
	public String getCustomerName() {		return customerName;	}
	public void setCustomerName(String customerName) {		this.customerName = customerName;	}
	public String getCustomerEmail() {		return customerEmail;	}
	public void setCustomerEmail(String customerEmail) {		this.customerEmail = customerEmail;	}
	public Order getOrder() {		return Order;	}
	public void setOrder(Order order) {		Order = order;	}
}
