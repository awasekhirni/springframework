/**
 * 
 */
package com.tpri.exthirty;

import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appthirty.xml");
		Customer syedawase=(Customer)context.getBean("customerBean");
	
		Properties myprops = syedawase.getCustomerInfo();
		
		Set<Entry<Object,Object>> myset=myprops.entrySet();
		
		for(Entry<Object,Object> entry:myset) {
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}
		context.close();
	
	}

}
