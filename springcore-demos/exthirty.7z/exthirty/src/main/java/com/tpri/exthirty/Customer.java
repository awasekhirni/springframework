/**
 * 
 */
package com.tpri.exthirty;

import java.util.Properties;

/**
 * @author Awase Khirni Syed
 *
 */
public class Customer {

	private Properties customerInfo;

	public Properties getCustomerInfo() {
		return customerInfo;
	}

	public void setCustomerInfo(Properties customerInfo) {
		this.customerInfo = customerInfo;
	}
}
