/**
 * 
 */
package com.tpri.extwelve;

/**
 * @author Awase Khirni Syed
 *
 */
public class Task {

	public void displayTask() {
		System.out.println("You are now executing assigned tasks to give demo "
				+ "of Spring Bean Life Cycle");
	}
	
	//SpringBean Life Cycle methods 
	// initializing method 
	public void init() {
		System.out.println("Init Spring Bean LifeCyle Method:Task bean has been initialized!");
	}
	
	//called just before bean is destroyed
	public void destroy() {
		System.out.println("Destroy Spring Bean LifeCycle Method: Task bean has been destroyed!");
	}

}
