/**
 * 
 */
package com.tpri.extwelve;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppTwelveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("apptwelve.xml");
		
		Task todo=(Task)context.getBean("taskBean");
		todo.displayTask();
		
		//Closing Application Context Explicitly
		((AbstractApplicationContext)context).registerShutdownHook();

	}

}
