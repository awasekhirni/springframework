package com.tpri.exsevencorespringprj;

import java.util.List;

public class StudentBean {
  private List studentsData;
  
  public void setStudentsData(List studentsData) {
	  this.studentsData=studentsData;
  }
  
  public void displayStudentInfo() {
	  System.out.println("Display Student Information!:"+studentsData);
  }
}
