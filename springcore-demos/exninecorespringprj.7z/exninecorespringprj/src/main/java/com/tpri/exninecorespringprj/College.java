/**
 * 
 */
package com.tpri.exninecorespringprj;

import java.util.Set;

/**
 * @author Awase Khirni Syed
 *
 */
public class College {

	private Set studentsData;
	
	public void setStudentsData(Set studentsData) {
		this.studentsData=studentsData;
	}
	
	public void show() {
		System.out.println("Displaying Student Data:"+studentsData);
	}
	
}
