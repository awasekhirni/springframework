/**
 * 
 */
package com.tpri.exninecorespringprj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppNineMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppNine Demo!");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appnine.xml");
		
		College c=(College)context.getBean("collegeBean");
		c.show();
	}

}
