/**
 * 
 */
package com.tpri.exsixcorespring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppSixMain Demo!");
		
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("appsix.xml");
		
		Company sycliq=(Company)appcontext.getBean("company");
		sycliq.joinWorkforce();
		sycliq.attendTraining();
		sycliq.followSafety();
		sycliq.executeTasks();
	}

}
