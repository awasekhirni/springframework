/**
 * 
 */
package com.tpri.exsixcorespring;

/**
 * @author Awase Khirni Syed
 *
 */
public class FTEmployee implements IEmployee {

	public void joinWorkforce() {
		// TODO Auto-generated method stub
		System.out.println("Company: A New Employee has joined the workforce!");

	}

	public void attendTraining() {
		// TODO Auto-generated method stub
		System.out.println("Company:New Employee Training Commenced!");
	}

	public void followSafety() {
		// TODO Auto-generated method stub
		System.out.println("Company: New Employee Safety Training Commenced!");
	}

	public void executeTasks() {
		// TODO Auto-generated method stub
		System.out.println("Company:New Employee is ready to take up tasks to execute!");
	}

}
