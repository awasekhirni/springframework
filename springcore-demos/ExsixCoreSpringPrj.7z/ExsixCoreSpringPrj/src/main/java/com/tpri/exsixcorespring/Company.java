/**
 * 
 */
package com.tpri.exsixcorespring;

/**
 * @author Awase Khirni Syed
 *
 */
public class Company {
	IEmployee employee;
	//setter injection 
	public void setEmployee(IEmployee iemp) {
		this.employee=iemp;
	}
	
	public IEmployee getEmployee(IEmployee iemp) {
		return this.employee;
	}
	
	public void joinWorkforce() {
		employee.joinWorkforce();
	}

	public void attendTraining() {
		employee.attendTraining();
	}

	public void followSafety() {
		employee.followSafety();
	}

	public void executeTasks() {
		employee.executeTasks();
	}
}
