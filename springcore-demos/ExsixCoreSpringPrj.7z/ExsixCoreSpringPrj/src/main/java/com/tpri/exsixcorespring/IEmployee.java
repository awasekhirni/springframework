/**
 * 
 */
package com.tpri.exsixcorespring;

/**
 * @author Awase Khirni Syed
 *
 */
public interface IEmployee {
	
	public void joinWorkforce();
	public void attendTraining();
	public void followSafety();
	public void executeTasks();

}
