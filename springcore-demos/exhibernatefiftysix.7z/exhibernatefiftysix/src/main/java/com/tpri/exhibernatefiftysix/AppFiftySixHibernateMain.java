/**
 * 
 */
package com.tpri.exhibernatefiftysix;

import java.util.Date;

import org.hibernate.Session;

import com.tpri.exhibernatefiftysix.model.User;
import com.tpri.exhibernatefiftysix.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftySixHibernateMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		User user = new User();
		user.setUserId(123712387);
		user.setUsername("Awase Khirni Syed");
		user.setCreatedBy("SycliQ Geospatial Pvt Ltd");
		user.setCreatedDate(new Date());
		
		session.save(user);
		session.getTransaction().commit();
	}

}
