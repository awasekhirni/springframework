/**
 * 
 */
package com.tpri.exhibernatefiftyseven;

import org.hibernate.Session;

import com.tpri.exhibernatefiftyseven.model.Product;
import com.tpri.exhibernatefiftyseven.utilities.HibernateUtilities;


/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftySevenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product samsung = new Product();
		samsung.setProductName("Samsung S5 Mobile");
		samsung.setProductDesc("Samsung Mobile with 845 octa core processor");
		samsung.setProductPrice("35000.00");
		
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		
		
		session.save(samsung);
		session.getTransaction().commit();
		
		
	}

}
