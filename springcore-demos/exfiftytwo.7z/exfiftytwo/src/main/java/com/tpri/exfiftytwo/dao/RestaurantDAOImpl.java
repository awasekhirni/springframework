package com.tpri.exfiftytwo.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.tpri.exfiftytwo.model.Restaurant;

@Repository
public class RestaurantDAOImpl implements IRestaurantDAO {
	private final String SQL_FIND = "select * from restaurant where restaurantid = ?";
	private final String SQL_DELETE = "delete from restaurant where restaurantid = ?";
	private final String SQL_UPDATE = "update restaurant set restaurantname = ?, restaurantaddress = ?, restaurantrating = ? where restaurantid = ?";
	private final String SQL_GETALL = "select * from restaurant";
	private final String SQL_INSERT = "insert into restaurant(restaurantid,restaurantname,restaurantaddress,restaurantrating)  values(?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void createRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		int checkInsert = jdbcTemplate.update(SQL_INSERT,new Object[] {restaurant.getRestaurantId(),
				restaurant.getRestaurantName(),restaurant.getRestuarantAddress(),restaurant.getRestuarantRating()});
		if(checkInsert>0) {
			System.out.println("A new restaurant has been created!");
		}
	}

	public Restaurant getRestaurantById(int restaurantId) {
		// TODO Auto-generated method stub
		Restaurant myrestaurant= jdbcTemplate.queryForObject(SQL_FIND, new RestaurantRowMapper(),restaurantId);
		return myrestaurant;
	}

	public void deleteRestaurantById(int restaurantId) {
		// TODO Auto-generated method stub
		int count = jdbcTemplate.update(SQL_DELETE,restaurantId);
		if(count>0) {
			System.out.println("A Single restaurant record has been deleted!");
		}
	}

	public void updateRestaurantById(int restaurantId, String restaurantName, String restaurantAddress,
			String restuarantRating) {
		// TODO Auto-generated method stub
		int changeNo=jdbcTemplate.update(SQL_UPDATE,restaurantId);
		if(changeNo>0) {
			System.out.println("RestuarantId was updated!");
		}

	}

	public List<Restaurant> getAllRestaurantDetails() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GETALL, new RestaurantRowMapper());
	}

}
