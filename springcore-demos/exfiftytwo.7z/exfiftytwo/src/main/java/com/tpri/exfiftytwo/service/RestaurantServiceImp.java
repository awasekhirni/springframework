package com.tpri.exfiftytwo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.tpri.exfiftytwo.dao.IRestaurantDAO;
import com.tpri.exfiftytwo.model.Restaurant;

@Service("restaurantservice")
public class RestaurantServiceImp implements IRestaurantService {
	@Autowired
	private IRestaurantDAO irestaurantDAO;

	public void addRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		this.irestaurantDAO.createRestaurant(restaurant);
	}

	public Restaurant fetchRestaurantById(int restaurantId) {
		// TODO Auto-generated method stub
		return irestaurantDAO.getRestaurantById(restaurantId);
	}

	public void removeRestaurantById(int restaurantId) {
		// TODO Auto-generated method stub
		irestaurantDAO.deleteRestaurantById(restaurantId);
	}

	public void changeRestaurantById(int restaurantId, String restaurantName, String restaurantAddress,
			String restuarantRating) {
		// TODO Auto-generated method stub
		irestaurantDAO.updateRestaurantById(restaurantId, restaurantName, restaurantAddress,restuarantRating);
	}

	public List<Restaurant> fetchAllRestaurantDetails() {
		// TODO Auto-generated method stub
		return irestaurantDAO.getAllRestaurantDetails();
	}

}
