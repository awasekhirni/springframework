package com.tpri.exfiftytwo.service;

import java.util.List;

import com.tpri.exfiftytwo.model.Restaurant;

public interface IRestaurantService {
	//abstract methods => CRUD operations
			public abstract void addRestaurant(Restaurant restaurant);
			public abstract Restaurant fetchRestaurantById(int restaurantId);
			public abstract void removeRestaurantById(int restaurantId);
			public abstract void changeRestaurantById(int restaurantId,String restaurantName, 
					String restaurantAddress,String restuarantRating);
			public abstract List<Restaurant> fetchAllRestaurantDetails();
}
