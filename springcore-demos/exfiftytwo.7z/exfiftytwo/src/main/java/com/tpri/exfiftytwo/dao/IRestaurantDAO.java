package com.tpri.exfiftytwo.dao;

import java.util.List;

import com.tpri.exfiftytwo.model.Restaurant;


public interface IRestaurantDAO {

	//abstract methods => CRUD operations
		public abstract void createRestaurant(Restaurant restaurant);
		public abstract Restaurant getRestaurantById(int restaurantId);
		public abstract void deleteRestaurantById(int restaurantId);
		public abstract void updateRestaurantById(int restaurantId,String restaurantName, 
				String restaurantAddress,String restuarantRating);
		public abstract List<Restaurant> getAllRestaurantDetails();
}
