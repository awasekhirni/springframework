package com.tpri.exfiftytwo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.tpri.exfiftytwo.model.Restaurant;



public class RestaurantRowMapper implements RowMapper<Restaurant> {

	public Restaurant mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Restaurant restaurant=new Restaurant();
		restaurant.setRestaurantId(rs.getInt("restaurantId"));
		restaurant.setRestaurantName(rs.getString("restaurantName"));
		restaurant.setRestuarantAddress(rs.getString("restuarantAddress"));
		restaurant.setRestuarantRating(rs.getString("restuarantRating"));
		return restaurant;
	}

}
