/**
 * 
 */
package com.tpri.exfiftytwo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfiftytwo.model.Restaurant;
import com.tpri.exfiftytwo.service.RestaurantServiceImp;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyTwoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFiftyTwoMain=SpringJDBCTemplate with Annotations+Postgresql");
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfiftytwo.xml");
		RestaurantServiceImp rsimpl=(RestaurantServiceImp) context.getBean("restaurantservice");
		Restaurant zaika= new Restaurant();
		zaika.setRestaurantId(129898132);
		zaika.setRestaurantName("Zaika Tasty Treats Pvt Ltd");
		zaika.setRestuarantAddress("Kalyan Nagar, Bangalore");
		zaika.setRestuarantRating("5 star rating");
				
		rsimpl.addRestaurant(zaika);
		
		context.close();
	}

}
