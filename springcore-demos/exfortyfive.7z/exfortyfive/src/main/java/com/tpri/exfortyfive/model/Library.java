package com.tpri.exfortyfive.model;

import java.util.List;

public class Library {

	private List<Book> allBooks;

	public List<Book> getAllBooks() {
		return allBooks;
	}

	public void setAllBooks(List<Book> allBooks) {
		this.allBooks = allBooks;
	}
	
}
