/**
 * 
 */
package com.tpri.exfortyfive;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfortyfive.model.Book;
import com.tpri.exfortyfive.model.Library;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyFiveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFortyFiveMain: Spring ExpressionLanguage!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortyfive.xml");
		
		Library refli=(Library)context.getBean("library");
		List<Book> mybooks= refli.getAllBooks();
		for(Book book:mybooks) {
			System.out.println(book.getBookId()+"\t"+book.getBookName());
		}
		
		context.close();
	}

}
