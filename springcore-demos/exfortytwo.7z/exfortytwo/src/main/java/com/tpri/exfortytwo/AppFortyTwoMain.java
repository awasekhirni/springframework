/**
 * 
 */
package com.tpri.exfortytwo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyTwoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppFortyTwoMain: Component Annotation!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortytwo.xml");
		Movie lagaan= (Movie)context.getBean("movie");
		System.out.println("Movie Information!");
		System.out.println(lagaan.getMovieId()+"\t"+lagaan.getMovieName()+"\t"+lagaan.getMovieRating());
		System.out.println("Actor Information!");
		System.out.println(lagaan.getActor().getActorId()+"\t"+lagaan.getActor().getActorName()+"\t"+lagaan.getActor().getActorRanking());
				
		context.close();
		

	}

}
