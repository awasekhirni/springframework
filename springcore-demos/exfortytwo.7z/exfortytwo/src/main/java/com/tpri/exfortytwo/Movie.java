/**
 * 
 */
package com.tpri.exfortytwo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/**
 * @author Awase Khirni Syed
 *
 */
@Component
public class Movie {
	@Value("1112")
	private int movieId;
	@Value("Lagaan")
	private String movieName;
	@Value("5")
	private String movieRating;
	@Autowired
	private Actor actor;
	public int getMovieId() { 		return movieId; 	}
	public void setMovieId(int movieId) { 		this.movieId = movieId; 	}
	public String getMovieName() { 		return movieName; 	}
	public void setMovieName(String movieName) { 		this.movieName = movieName; 	}
	public String getMovieRating() { 		return movieRating; 	}
	public void setMovieRating(String movieRating) { 		this.movieRating = movieRating; 	}
	public Actor getActor() { 		return actor; 	}
	public void setActor(Actor actor) { 		this.actor = actor; 	}

}
