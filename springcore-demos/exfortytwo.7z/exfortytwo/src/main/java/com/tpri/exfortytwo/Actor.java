package com.tpri.exfortytwo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Actor {
	
	@Value("712367")
	private int actorId;
	@Value("Aamir Khan")
	private String actorName;
	@Value("5")
	private String actorRanking;
	public int getActorId() {
		return actorId;
	}
	public void setActorId(int actorId) {
		this.actorId = actorId;
	}
	public String getActorName() {
		return actorName;
	}
	public void setActorName(String actorName) {
		this.actorName = actorName;
	}
	public String getActorRanking() {
		return actorRanking;
	}
	public void setActorRanking(String actorRanking) {
		this.actorRanking = actorRanking;
	}

}
