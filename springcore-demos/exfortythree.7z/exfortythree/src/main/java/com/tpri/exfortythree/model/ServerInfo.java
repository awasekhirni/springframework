/**
 * 
 */
package com.tpri.exfortythree.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//import this in the beans file
//import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

/**
 * @author Awase Khirni Syed
 *
 */
@Component("serverBean")
public class ServerInfo {
	@Value("${ServerInfo.serverName}")
	private String serverName;
	@Value("${ServerInfo.serverIp}")
	private String serverIp;
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getServerIp() {
		return serverIp;
	}
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
}
