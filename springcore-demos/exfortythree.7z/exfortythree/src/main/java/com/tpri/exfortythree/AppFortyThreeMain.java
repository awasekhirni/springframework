/**
 * 
 */
package com.tpri.exfortythree;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfortythree.model.ServerInfo;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyThreeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("appfortythree.xml");
		
		ServerInfo serverDetail=(ServerInfo)context.getBean("serverBean");
		
		System.out.println(serverDetail.getServerIp()+"\t"+serverDetail.getServerName());
		
		
		context.close();
		

	}

}
