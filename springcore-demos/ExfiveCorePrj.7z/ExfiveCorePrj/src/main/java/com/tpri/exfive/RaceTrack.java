/**
 * 
 */
package com.tpri.exfive;

import com.tpri.exfive.IVehicle;
/**
 * @author Awase Khirni Syed
 *
 */
public class RaceTrack {
	
	IVehicle vehicle;
	
	//constructor
	RaceTrack(IVehicle vehicle){
		this.vehicle=vehicle;
	}
	
	public void changeGear() {
		vehicle.changeGear();
	}
	
	
	public void speedUp() {
		vehicle.speedUp();
	}

	public void applyBrakes() {
		vehicle.applyBrakes();
	}
}
