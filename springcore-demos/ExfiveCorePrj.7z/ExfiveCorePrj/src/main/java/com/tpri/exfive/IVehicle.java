/**
 * 
 */
package com.tpri.exfive;

/**
 * @author Awase Khirni Syed
 *
 */
public interface IVehicle {
	
	//abstract methods 
	public void changeGear();
	public void speedUp();
	public void applyBrakes();

}
