/**
 * 
 */
package com.tpri.exfive;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Demo-ExfiveCore project");
		ApplicationContext context =new ClassPathXmlApplicationContext("fivespring.xml");
		RaceTrack rc =(RaceTrack) context.getBean("racetrack");
		rc.changeGear();
		rc.speedUp();
		rc.applyBrakes();

	}

}
