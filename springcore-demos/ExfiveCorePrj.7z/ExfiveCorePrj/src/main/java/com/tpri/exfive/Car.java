package com.tpri.exfive;



public class Car implements IVehicle{

	public void changeGear() {
		// TODO Auto-generated method stub
		System.out.println("Car:Initiating gear change");
		
	}

	
	public void speedUp() {
		// TODO Auto-generated method stub
		System.out.println("Car:Accelerating");
		
	}

	
	public void applyBrakes() {
		// TODO Auto-generated method stub
		System.out.println("Car:Decelerating and Stop");
		
	}

}
