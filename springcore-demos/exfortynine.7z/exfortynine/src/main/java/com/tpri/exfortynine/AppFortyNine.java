/**
 * 
 */
package com.tpri.exfortynine;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfortynine.model.Customer;
import com.tpri.exfortynine.service.CustomerServiceImpl;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyNine {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppFortyNine--Spring JDBC traditional Approach Demo 1");
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortynine.xml");
		
		CustomerServiceImpl  cs= (CustomerServiceImpl) context.getBean("customerService");
		
		Customer amazonCustomer = new Customer();
		amazonCustomer.setCustomerId("1246125");
		amazonCustomer.setCustomerName("Awase Khirni Syed");
		amazonCustomer.setEmail("awasekhirni@gmail.com");
		amazonCustomer.setCity("Bangalore");
		
		cs.addCustomer(amazonCustomer);
		
		context.close();

	}

}
