/**
 * 
 */
package com.tpri.exfortynine.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import com.tpri.exfortynine.model.Customer;
public class CustomerDAOImpl implements ICustomerDAO {
	//traditional approach of JDBC implementation 
	private DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Connection conn=null;
		PreparedStatement ps=null;
		try {
			conn=dataSource.getConnection();
			String cstmt="INSERT INTO customer(customerid,customername,city,email) VALUES(?,?,?,?)";
			ps=conn.prepareStatement(cstmt);
			ps.setString(1, customer.getCustomerId());
			ps.setString(2, customer.getCustomerName());
			ps.setString(3, customer.getCity());
			ps.setString(4, customer.getEmail());
			int rowsAffected=ps.executeUpdate();
			if(rowsAffected>0) {
				System.out.println("Customer has been created now!");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteCustomerById(int customerId) {
		// TODO Auto-generated method stub

	}

	public void updateCustomerEmailById(String newEmail, int customerId) {
		// TODO Auto-generated method stub

	}

	public List<Customer> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
