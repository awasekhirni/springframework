/**
 * 
 */
package com.tpri.exfortynine.model;

/**
 * @author Awase Khirni Syed
 *
 */
public class Customer {
	private String customerId;
	private String customerName;
	private String email;
	private String city;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
