/**
 * 
 */
package com.tpri.exfortynine.dao;

import java.util.List;

import com.tpri.exfortynine.model.Customer;

/**
 * @author Awase Khirni Syed
 *
 */
public interface ICustomerDAO {

	//abstract methods => CRUD operations
	public abstract void createCustomer(Customer customer);
	public abstract Customer getCustomerById(int customerId);
	public abstract void deleteCustomerById(int customerId);
	public abstract void updateCustomerEmailById(String newEmail, int customerId);
	public abstract List<Customer> getAllCustomerDetails();
}
