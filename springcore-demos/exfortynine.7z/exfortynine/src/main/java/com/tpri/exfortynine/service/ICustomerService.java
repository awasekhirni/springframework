/**
 * 
 */
package com.tpri.exfortynine.service;

import java.util.List;

import com.tpri.exfortynine.model.Customer;

/**
 * @author Awase Khirni Syed
 *
 */
public interface ICustomerService {

	//abstract methods => CRUD operations
		public abstract void addCustomer(Customer customer);
		public abstract Customer fetchCustomerById(int customerId);
		public abstract void removeCustomerById(int customerId);
		public abstract void changeCustomerEmailById(String newEmail, int customerId);
		public abstract List<Customer> fetchAllCustomerDetails();
	}
