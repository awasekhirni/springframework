/**
 * 
 */
package com.tpri.exfortynine.service;
import java.util.List;
import com.tpri.exfortynine.dao.ICustomerDAO;
import com.tpri.exfortynine.model.Customer;
/**  * @author Awase Khirni Syed  *  */
public class CustomerServiceImpl implements ICustomerService {
	private ICustomerDAO icustomerDAO;
	//setter method for customerDAOAccess
	public void setIcustomerDAO(ICustomerDAO icustomerDAO) {
		this.icustomerDAO = icustomerDAO;
	}
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		 icustomerDAO.createCustomer(customer);
	}
	public Customer fetchCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return icustomerDAO.getCustomerById(customerId);
	}
	public void removeCustomerById(int customerId) {
		// TODO Auto-generated method stub
		icustomerDAO.deleteCustomerById(customerId);
	}
	public void changeCustomerEmailById(String newEmail, int customerId) {
		// TODO Auto-generated method stub
		icustomerDAO.updateCustomerEmailById(newEmail, customerId);
	}
	public List<Customer> fetchAllCustomerDetails() {
		// TODO Auto-generated method stub
		return icustomerDAO.getAllCustomerDetails();
	}
}
