/**
 * 
 */
package com.tpri.exeighteencore;

/**
 * @author Awase Khirni Syed
 *
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppEighteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppEighteenMain Demo!");
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("appeighteen.xml");
		Polygon polyfill= (Polygon)appcontext.getBean("polygonBean");
		polyfill.draw();
	}

}
