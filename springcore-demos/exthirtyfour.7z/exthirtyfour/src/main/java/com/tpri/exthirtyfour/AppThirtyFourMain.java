/**
 * 
 */
package com.tpri.exthirtyfour;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppThirtyFourMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		
		ConfigurableApplicationContext cac=new ClassPathXmlApplicationContext("appthirtyfour.xml");
		cac.start();
		System.out.println("##################################################");
		Teleprompter tp=(Teleprompter)cac.getBean("teleBean");
		System.out.println("__________________________________________________");
		System.out.println(tp.getTeleprompterId()+"\t"+ tp.getTeleprompterMessage());
		cac.stop();
		cac.close();
	}

}
