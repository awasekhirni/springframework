/**
 * 
 */
package com.tpri.exthirtyfour;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;

/**
 * @author Awase Khirni Syed
 *
 */
public class CSEHandler implements ApplicationListener<ContextStoppedEvent>{

	public void onApplicationEvent(ContextStoppedEvent cee) {
		// TODO Auto-generated method stub
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		System.out.println("Context End/Stopped Event has been received!");
		System.out.println(cee.getSource());
		System.out.println("%%%%%%%%%%%%-------------%%%%%%%%%%%%");
	}

}
