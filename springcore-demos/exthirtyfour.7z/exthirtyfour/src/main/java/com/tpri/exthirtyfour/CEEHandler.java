/**
 * 
 */
package com.tpri.exthirtyfour;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStartedEvent;

/**
 * @author Awase Khirni Syed
 *
 */
public class CEEHandler implements ApplicationListener<ContextStartedEvent> {

	public void onApplicationEvent(ContextStartedEvent cse) {
		// TODO Auto-generated method stub
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		System.out.println("ContextStartedEvent has been received!");
		// ApplicationContext appcontext= cse.getApplicationContext();
		System.out.println("fetch the source:" + cse.getSource());
	}

}
