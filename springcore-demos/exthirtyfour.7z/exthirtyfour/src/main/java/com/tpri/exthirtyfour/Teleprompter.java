/**
 * 
 */
package com.tpri.exthirtyfour;

/**
 * @author Awase Khirni Syed
 *
 */
public class Teleprompter {

	private int teleprompterId;
	private String teleprompterMessage;
	public int getTeleprompterId() {
		return teleprompterId;
	}
	public void setTeleprompterId(int teleprompterId) {
		this.teleprompterId = teleprompterId;
	}
	public String getTeleprompterMessage() {
		return teleprompterMessage;
	}
	public void setTeleprompterMessage(String teleprompterMessage) {
		this.teleprompterMessage = teleprompterMessage;
	}
}
