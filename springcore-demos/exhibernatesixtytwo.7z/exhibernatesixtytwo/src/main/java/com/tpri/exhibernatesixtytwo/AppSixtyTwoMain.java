package com.tpri.exhibernatesixtytwo;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

import com.tpri.exhibernatesixtytwo.model.Category;
import com.tpri.exhibernatesixtytwo.model.Stock;
import com.tpri.exhibernatesixtytwo.util.HibernateUtil;

public class AppSixtyTwoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hibernate -Many to Many with Annotations Demo");
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Stock sycliqStock= new Stock();
		sycliqStock.setStockCode("712387");
		sycliqStock.setStockName("SYCLIQ");
		Category category1 = new Category("Consumer", "SADATH SECURITIES");
        Category category2 = new Category("Investicore", "AMAN INVESTORS");
        Set<Category> categories = new HashSet<Category>();
        categories.add(category1);
        categories.add(category2);
        sycliqStock.setCategories(categories);
        session.save(sycliqStock);
        session.getTransaction().commit();
        
	}

}
