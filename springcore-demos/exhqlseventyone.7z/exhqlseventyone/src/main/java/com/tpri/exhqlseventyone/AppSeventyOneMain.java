/**
 * 
 */
package com.tpri.exhqlseventyone;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.tpri.exhqlseventyone.model.Product;
import com.tpri.exhqlseventyone.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSeventyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("App70+Hibernate Query language 5.2.x+ MySQL");
		
		try(Session session=HibernateUtilities.getSessionFactory().openSession()){
			session.beginTransaction();
			Product samsung = new Product();
			samsung.setProductId(1);
			samsung.setProductName("Samsung S5 Mobile");
			samsung.setProductDesc("Quad core samsung 835 processor");
			samsung.setProductPrice(36000);
			samsung.setDiscount(4000.00);
			samsung.setExpiryDate(new Date());
			Product sony = new Product();
			sony.setProductId(1);
			sony.setProductName("Sony XPeria Z1");
			sony.setProductDesc("Quad core qualcom 855 processor");
			sony.setProductPrice(48000);
			sony.setDiscount(4000.00);
			sony.setExpiryDate(new Date());
			
			session.save(samsung);
			session.save(sony);
			session.getTransaction().commit();
			
			
			
		}catch(Exception e ) {
			e.printStackTrace();
		}
		//HQL to PRINT ALL THE RECORDS
		SessionFactory sf = HibernateUtilities.getSessionFactory();
		getAllProducts(sf);//calling the static methods
		//insertProduct(sf);//insert a new record
		updateProductById(sf);
	}
	
	//HIBERNATE QUERY LANGUAGE TO FETCH RECORDS
	private static void getAllProducts(SessionFactory sf) {
		try(Session session=sf.openSession()){
			String HQL_getALLproducts="FROM product";
			Query<Product> allproducts_query=session.createQuery(HQL_getALLproducts,Product.class);
			List<Product> plist = allproducts_query.list();
			plist.forEach(System.out::println);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void getAllProductsByIdandName(SessionFactory sf) {
		try(Session session=sf.openSession()){
			String HQL_getALLproductsbyIdName="SELECT productId,productName from Product";
			Query allproducts_queryIdName=session.createQuery(HQL_getALLproductsbyIdName);
			List<Object[]> alist = allproducts_queryIdName.list();
			for(Object[] objects:alist) {
				Integer productId=(Integer)objects[0];
				String productName=(String)objects[1];
				System.out.println("productId: "+productId+"\t"+"productName: "+productName);
				
			}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void findProductByIdandName(SessionFactory sf) {
		try(Session session=sf.openSession()){
			int productId=1;
			String productName="Samsung S5 Mobile";
			String HQL_wherec="FROM Product WHERE productId=:productId AND productName=:productName";
			Query<Product> query_wherec=session.createQuery(HQL_wherec,Product.class);
			query_wherec.setParameter("productId",productId);
			query_wherec.setParameter("productName",productName);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private static void findProductById(SessionFactory sf) {
		int productId=2;
		try(Session session=sf.openSession()){
			String HQL_byId="FROM Product WHERE productId=?";
			Query<Product> query_byid=session.createQuery(HQL_byId,Product.class);
			query_byid.setParameter(0, productId);
			Product product = query_byid.uniqueResult();
			System.out.println(product);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private static void insertProduct(SessionFactory sf) {
		Integer pId=1;
		String pName="Apple iphone5";
		String pDesc="Dual core apple mobile processor";
		int pPrice=86000;
		Double pdiscount=10000.00;
		Date pDate=new Date();
		try(Session session=sf.openSession()){
			//Query query = s.createQuery("insert into Paymentinfo(appointid, appointfees, status, pid) values=(?,?,?,?)");
			//int productId, String productName, String productDesc, int productPrice, Double discount,		Date expiryDate
			String HQL_insert="INSERT INTO Product(productName, productDesc, productPrice, discount, expiryDate) values=(:pName,:pDesc,:pPrice,:pdiscount,pDate)";			
			Query query_insert=session.createQuery(HQL_insert);
			query_insert.setParameter("productName",pName);
			query_insert.setParameter("productDesc",pDesc);
			query_insert.setParameter("productPrice",pPrice);
			query_insert.setParameter("discount",pdiscount);
			query_insert.setParameter("expiryDate",pDate);
			session.beginTransaction();
			int executeUpdate = query_insert.executeUpdate();
			if(executeUpdate>0)
				System.out.println(executeUpdate+" one record has been inserted successfully in PRODUCT table");
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void removeProductById(SessionFactory sf) {
		int productId=2;
		try(Session session=sf.openSession()){
			String HQL_delete="FROM Product WHERE productId=:productId";
			Query query_delete = session.createQuery(HQL_delete);
			query_delete.setParameter("productId",productId);
			session.beginTransaction();
			int executeUpdate = query_delete.executeUpdate();
			session.getTransaction().commit();
			if(executeUpdate>0) {
				System.out.println("The ProductId Record is deleted!");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private static void updateProductById(SessionFactory sf) {
		int productId=2;
		String productName="One Plus 7 Pro";
		try(Session session=sf.openSession()){
			
			String HQL_update ="UPDATE product set productname=:productName WHERE productId=:productId";
			Query query_update = session.createQuery(HQL_update);
			query_update.setParameter("productId",productId);
			query_update.setParameter("productName", productName);
			session.beginTransaction();
			int executeUpdate = query_update.executeUpdate();
			session.getTransaction().commit();
			if(executeUpdate>0) {
				System.out.println("The ProductId Record has been Updated Successfully");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	
}
