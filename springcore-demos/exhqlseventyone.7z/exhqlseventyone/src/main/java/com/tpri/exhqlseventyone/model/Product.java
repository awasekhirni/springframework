package com.tpri.exhqlseventyone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@javax.persistence.Entity(name = "product")
@Table(name="product")
public class Product implements Serializable {

	@Id
	@Column(name="productId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer productId;
	
	@Column(name="productName",length=200,nullable=false)
	private String productName;
	
	@Column(name="productDesc",length=250, nullable=false)
	private String productDesc;
	
	@Column(name="productPrice")
	private int productPrice;
	
	@Column(name="discount")
	private Double discount;
	
	@Column(name="expiryDate")
	private Date expiryDate;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDesc=" + productDesc
				+ ", productPrice=" + productPrice + ", discount=" + discount + ", expiryDate=" + expiryDate + "]";
	}

	//constructor
	
	public Product() {}
	
	public Product(String productName, String productDesc, int productPrice, Double discount, Date expiryDate) {
		super();
		this.productName = productName;
		this.productDesc = productDesc;
		this.productPrice = productPrice;
		this.discount = discount;
		this.expiryDate = expiryDate;
	}
	
	
	
	
	
	
	
	
}
