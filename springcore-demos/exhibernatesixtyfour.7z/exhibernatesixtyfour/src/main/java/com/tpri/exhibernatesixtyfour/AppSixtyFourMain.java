/**
 * 
 */
package com.tpri.exhibernatesixtyfour;

import java.util.Date;

import com.tpri.exhibernatesixtyfour.model.Product;
import com.tpri.exhibernatesixtyfour.service.IProductService;
import com.tpri.exhibernatesixtyfour.service.ProductServiceImpl;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtyFourMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("64Hibernate 5.2.x --CRUD with Service layer and DAO + MYSQL");

		ProductServiceImpl productService = new ProductServiceImpl();
		createProduct(productService);
	}
	
	private static void createProduct(ProductServiceImpl productService) {
		productService.createProduct(getProduct());
	}
	
	private static Product getProduct() {
		Product product = new Product();
		product.setProductName("Samsung S5 Mobile");
		product.setProductDesc("Quad core QualComm Processor");
		product.setProductPrice(56000.00);
		product.setExpiryDate(new Date());
		return product;
	}
	
	private static void deleteProductById(ProductServiceImpl productService) {
		productService.deleteProductById(1);
	}
	
	private static void updateEmployeeById(ProductServiceImpl productService) {
			productService.updatedProductById(1, 60000.00);
	}
	
	private static void getProductbyId(ProductServiceImpl productService) {
		Product product = productService.getProductById(1);
		System.out.println(product);
	}

}
