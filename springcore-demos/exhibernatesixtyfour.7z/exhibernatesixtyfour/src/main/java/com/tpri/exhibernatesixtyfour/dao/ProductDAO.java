package com.tpri.exhibernatesixtyfour.dao;

import com.tpri.exhibernatesixtyfour.model.Product;

public interface ProductDAO {
	public abstract void addProduct(Product product);
	public abstract Product fetchProduct(int productId);
	public abstract void updateProductById(int productId,Double productPrice);
	public abstract void deleteProductById(Integer productId);
}
