package com.tpri.exhibernatesixtyfour.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtyfour.model.Product;
import com.tpri.exhibernatesixtyfour.util.HibernateUtilities;

public class ProductDAOImpl implements ProductDAO {

	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		try (Session session = HibernateUtilities.getSessionFactory().openSession()) {
			session.beginTransaction();
			Integer id =(Integer)session.save(product);
			System.out.println("Product is created with id:"+id);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	public Product fetchProduct(int productId) {
		// TODO Auto-generated method stub
		Product product = null;
		try (Session session = HibernateUtilities.getSessionFactory().openSession()) {
			product=session.get(Product.class, productId);
			if(product!=null) {
				return product;
			}else {
				System.out.println("Product does not exist");
			}
		}catch(HibernateException e) {
			e.printStackTrace();
		}
				
		return null;
	}

	public void updateProductById(int productId, Double productPrice) {
		// TODO Auto-generated method stub
		try (Session session = HibernateUtilities.getSessionFactory().openSession()) {
			
			Product product = session.get(Product.class,productId);
			if(product !=null) {
				product.setProductPrice(productPrice);
				session.beginTransaction();
				session.update(product);
				session.getTransaction().commit();
			}
			else {
				System.out.println("Product does not exist");
			}
			
		}catch(HibernateException e) {
			e.printStackTrace();
		}

	}

	public void deleteProductById(Integer productId) {
		// TODO Auto-generated method stub

		try (Session session = HibernateUtilities.getSessionFactory().openSession()) {
			Product product = session.get(Product.class, productId);
			if(product !=null) {
				session.beginTransaction();
				session.delete(product);
				session.getTransaction().commit();
			}else {
				System.out.println("Product does not exist");
			}
			
			
			
		}catch(HibernateException e) {
			e.printStackTrace();
		}
	}

}
