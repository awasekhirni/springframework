package com.tpri.exhibernatesixtyfour.service;

import com.tpri.exhibernatesixtyfour.model.Product;

public interface IProductService {
  public abstract void createProduct(Product product);
  public abstract Product getProductById(int productId);
  public abstract void updatedProductById(int productId, Double productPrice);
  public abstract void deleteProductById(Integer productId);
}
