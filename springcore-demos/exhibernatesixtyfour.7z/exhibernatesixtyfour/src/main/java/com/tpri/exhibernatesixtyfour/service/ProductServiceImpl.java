package com.tpri.exhibernatesixtyfour.service;

import com.tpri.exhibernatesixtyfour.dao.ProductDAOImpl;
import com.tpri.exhibernatesixtyfour.model.Product;

public class ProductServiceImpl implements IProductService{

	@Override
	public void createProduct(Product product) {
		// TODO Auto-generated method stub
		new ProductDAOImpl().addProduct(product);
		
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return new ProductDAOImpl().fetchProduct(productId);
	}

	@Override
	public void updatedProductById(int productId, Double productPrice) {
		// TODO Auto-generated method stub
		new ProductDAOImpl().updateProductById(productId, productPrice);
		
	}

	@Override
	public void deleteProductById(Integer productId) {
		// TODO Auto-generated method stub
		new ProductDAOImpl().deleteProductById(productId);
	}

}
