/**
 * 
 */
package com.tpri.exelevencorespringprj;

/**
 * @author Awase Khirni Syed
 *
 */
public class Customer {

	
	private String customerName;
	
	public void setCustomerName(String customerName) {
		this.customerName=customerName;
	}
	
	public void displayCustomerName() {
		System.out.println("Eleven Core Spring :"+customerName);
	}
}
