/**
 * 
 */
package com.tpri.exelevencorespringprj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppElevenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("appeleven.xml");
		Customer sak =(Customer) context.getBean("customerBean");
		sak.setCustomerName("Syed Awase Khirni");
		sak.displayCustomerName();
		
		Customer aicy =(Customer)context.getBean("customerBean");
		sak.setCustomerName("Syed Ameese Sadath");
		sak.displayCustomerName();
		
		
	}
	

}
