/**
 * 
 */
package com.tpri.extencorespringprj;

/**
 * @author Awase Khirni Syed
 *
 */
public class Product {
	
	private String productName;
	
	public void setProductName(String productName) {
		this.productName=productName;
	}

	public void displayProductName() {
		System.out.println("Product Name is:"+productName);
	}
}
