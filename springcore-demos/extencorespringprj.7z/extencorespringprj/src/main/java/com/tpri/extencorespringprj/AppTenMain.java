/**
 * 
 */
package com.tpri.extencorespringprj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppTenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appten.xml");
		Product product = (Product)context.getBean("productBean");
		product.setProductName("ProductName:SYCLIQPrime IOT Platform");
		product.displayProductName();
		
		//creating another instance
		Product product2=(Product)context.getBean("productBean");
		product2.displayProductName();
		
		

	}

}
