/**
 * 
 */
package com.tpri.exhibernatesixtyone;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.tpri.exhibernatesixtyone.model.Article;
import com.tpri.exhibernatesixtyone.model.Category;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		
		//building a session factory from the service registry 
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		
		//obtains the session 
		Session session = sessionFactory.openSession();
		
		Category category = new Category("Geographic Information Systems");
		
		Article a1=new Article(0, "GIR", "Geographic Information Retrieval", "geographic information retrieval, geospatial intelligence, map mashup", "geographic information retrieval ");
		
		Article a2=new Article(1, "Volunteered GIR", "Geographic Information Retrieval", "geographic information retrieval, geospatial intelligence, map mashup", "geographic information retrieval ");
		
		Article a3=new Article(2, "Augumented GIR", "Geographic Information Retrieval", "geographic information retrieval, geospatial intelligence, map mashup", "geographic information retrieval ");
		
		Set<Article> articles = new HashSet<Article>();
		articles.add(a1);
		articles.add(a2);
		articles.add(a3);
		
		category.setArticles(articles);
		session.save(category);
		
		session.getTransaction().commit();
		session.close();
		
	
	}

}
