package com.tpri.ExthreeCoreSpringPrj;

//ApplicationContext specific imports
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//end of ApplicationContext specific imports
import com.tpri.ExthreeCoreSpringPrj.Product;

public class AppThreeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ApplicationContext is a superset of BeanFactory
		ApplicationContext context = new ClassPathXmlApplicationContext("appthree.xml");
		Product prod=(Product) context.getBean("product");
		prod.getProductName();
		
	}

}
