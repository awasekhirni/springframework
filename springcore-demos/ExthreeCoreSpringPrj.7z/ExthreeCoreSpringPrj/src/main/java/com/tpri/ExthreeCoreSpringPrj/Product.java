package com.tpri.ExthreeCoreSpringPrj;

public class Product {
	
	public String productType;
	public String productName;
	
	public String getProductType() {
		return productType;
	}
	
	public void setProductType(String productType) {
		this.productType=productType;
	}
	
	
	
	public void getProductName(){
		System.out.println("SYCLIQ-HyperLocal Sensing Platform:::");
	}

}
