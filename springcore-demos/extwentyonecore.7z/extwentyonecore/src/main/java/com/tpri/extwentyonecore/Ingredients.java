/**
 * 
 */
package com.tpri.extwentyonecore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Ingredients {

	private String ingredientName;
	private String ingredientQty;

	public String getIngredientName() {
		return ingredientName;
	}

	public void setIngredientName(String ingredientName) {
		this.ingredientName = ingredientName;
	}

	public String getIngredientQty() {
		return ingredientQty;
	}

	public void setIngredientQty(String ingredientQty) {
		this.ingredientQty = ingredientQty;
	}

}
