/**
 * 
 */
package com.tpri.extwentyonecore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Receipe {

	private Ingredients flour;
	private Ingredients eggs;
	private Ingredients milk;
	private Ingredients sugar;

	public Ingredients getFlour() { 		return flour; 	}
	public void setFlour(Ingredients flour) { 		this.flour = flour; 	}
	public Ingredients getEggs() { 		return eggs; 	}
	public void setEggs(Ingredients eggs) { 		this.eggs = eggs; 	}
	public Ingredients getMilk() { 		return milk; 	}
	public void setMilk(Ingredients milk) { 		this.milk = milk; 	}
	public Ingredients getSugar() { 		return sugar; 	}
	public void setSugar(Ingredients sugar) { 		this.sugar = sugar; 	}
	public void displayReceipe() {
		System.out.println("Ingredient is:=>{" + flour.getIngredientName() + "," + flour.getIngredientQty() + "}");
		System.out.println("Ingredient is:=>{" + eggs.getIngredientName() + "," + eggs.getIngredientQty() + "}");
		System.out.println("Ingredient is:=>{" + milk.getIngredientName() + "," + milk.getIngredientQty() + "}");
		System.out.println("Ingredient is:=>{" + sugar.getIngredientName() + "," + sugar.getIngredientQty() + "}");
	}
}
