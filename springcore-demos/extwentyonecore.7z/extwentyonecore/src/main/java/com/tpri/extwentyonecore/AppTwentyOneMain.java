/**
 * 
 */
package com.tpri.extwentyonecore;

/**
 * @author Awase Khirni Syed
 *
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTwentyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppTwentyOneMain:Autowire Spring Demo!");
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("apptwentyone.xml");
		Receipe cake= (Receipe)appcontext.getBean("recipeBean");
		cake.displayReceipe();
	}

}
