package com.tpri.exhibernatesixtysix.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "address")
public class Address {

	@Id
	@Column(name = "addressId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer addressId;

	@Column(name="streetName",length=150)
	private String streetName;
	
	@Column(name="cityName",length=150)
	private String cityName;
	
	@Column(name="stateName",length=150)
	private String stateName;
	
	@Column(name="zipcode",length=50)
	private String zipcode;
	
	@OneToOne(mappedBy="address")
	private Customer customer;

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", streetName=" + streetName + ", cityName=" + cityName
				+ ", stateName=" + stateName + ", zipcode=" + zipcode + ", customer=" + customer + "]";
	}
	
	public Address() {
		
	}

	public Address(Integer addressId, String streetName, String cityName, String stateName, String zipcode,
			Customer customer) {
		super();
		this.addressId = addressId;
		this.streetName = streetName;
		this.cityName = cityName;
		this.stateName = stateName;
		this.zipcode = zipcode;
		this.customer = customer;
	}
	
	
	
	
}
