/**
 * 
 */
package com.tpri.exhibernatesixtysix;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtysix.model.Address;
import com.tpri.exhibernatesixtysix.model.Customer;
import com.tpri.exhibernatesixtysix.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtySixMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("App66-One to One -Bidirectional Mapping in hibernate 5.2.x + MySQL");
		
		try(Session session = HibernateUtilities.getSessionFactory().openSession()){
			session.beginTransaction();
			
			Customer customer = new Customer();
			customer.setCustomerName("Awase Khirni Syed");
			customer.setCustomerEmail("awasekhirni@gmail.com");
			customer.setJoinDate(new Date());
			
			Address address1= new Address();
			address1.setCityName("Bangalore");
			address1.setStreetName("5 A Main HRBR 2 Block,Kalyannagar");
			address1.setStateName("Karnataka");
			address1.setZipcode("560043");
			customer.setAddress(address1);
			
			session.persist(customer);
			session.getTransaction().commit();
		}catch(HibernateException e) {
			e.printStackTrace();
		}

	}

}
