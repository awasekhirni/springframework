package com.tpri.exhibernatesixtythree;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtythree.model.Employee;
import com.tpri.exhibernatesixtythree.util.HibernateUtil;

public class AppSixtyThreeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hibernate5.2.x Demo 1-Crud operations");
		try(Session session=HibernateUtil.getSessionFactory().openSession()){
			createEmployee(session);
			//getEmployeebyId(session);
			//updateEmployeeById(session);
			//deleteEmployeeById(session);
			
		}catch(HibernateException e) {
			e.printStackTrace();
		}
	
	}
	
	private static void deleteEmployeeById(Session session) {
		Employee employee = session.get(com.tpri.exhibernatesixtythree.model.Employee.class, 2);
		if(employee != null){
			session.beginTransaction();
			
			session.delete(employee);
			session.getTransaction().commit();
		}else{
			System.out.println("Employee doesn't exist with provideded Id..");
		}
	}

	private static void updateEmployeeById(Session session) {
		Employee employee = session.get(com.tpri.exhibernatesixtythree.model.Employee.class, 2);
		if(employee != null){
			employee.setSalary(40000.00);
			session.beginTransaction();
			
			session.update(employee);
			session.getTransaction().commit();
		}else{
			System.out.println("Employee doesn't exist with provideded Id..");
		}
		
	
	}
	
	private static void getEmployeebyId(Session session) {
		Employee employee = session.get(com.tpri.exhibernatesixtythree.model.Employee.class, 20);
		if(employee != null) {
			System.out.println(employee);
		}else {
			System.out.println("Employee does not exist");
		}
	}
	
	
	public static void createEmployee(Session session) {
		session.beginTransaction();
		Integer id=(Integer)session.save(getEmployee());
		System.out.println("Employee is created with uniqueId::"+id);
		session.getTransaction().commit();
	}
	
	public static Employee getEmployee() {
		
		Employee employee = new Employee();
		employee.setEmployeeName("Awase Khirni Syed");
		employee.setEmail("awasekhirni@gmail.com");
		employee.setSalary(1327912.212);
		employee.setJoinDate(new Date());
		return employee;
	}

}
