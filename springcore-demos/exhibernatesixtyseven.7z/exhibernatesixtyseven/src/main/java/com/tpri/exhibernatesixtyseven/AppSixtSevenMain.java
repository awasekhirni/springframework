/**
 * 
 */
package com.tpri.exhibernatesixtyseven;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.tpri.exhibernatesixtyseven.model.Course;
import com.tpri.exhibernatesixtyseven.model.Professor;
import com.tpri.exhibernatesixtyseven.util.HibernateUtilities;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSixtSevenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("App67-Hibernate - One to Many - MySQL Demo!");
		
		try(Session session = HibernateUtilities.getSessionFactory().openSession()){
			session.beginTransaction();
			Professor professor = new Professor();
			professor.setProfessorName("Syed Awase Khirni");
			professor.setProfessorEmail("awasekhirni@gmail.com");
			
			
			Course course1=new Course();
			course1.setCourseName("Geographic Information System");
			course1.setCourseCredits(5);
			course1.setCourseRoom("L2321");
			
			Course course2= new Course();
			course2.setCourseName("DataScience with R Programming");
			course2.setCourseCredits(5);
			course2.setCourseRoom("H2632");
			professor.getCourseList().add(course1);
			professor.getCourseList().add(course2);
			session.save(course1);
			session.save(course2);
		
			session.persist(professor);
			session.getTransaction().commit();
		
		}catch(HibernateException e) {
			e.printStackTrace();
		}

	}

}
