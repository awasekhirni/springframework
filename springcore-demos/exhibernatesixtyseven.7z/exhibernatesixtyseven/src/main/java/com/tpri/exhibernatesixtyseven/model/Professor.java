package com.tpri.exhibernatesixtyseven.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name="professor")
@DynamicUpdate
public class Professor {
	@Id
	@Column(name="professorId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int professorId;
	
	@Column(name="professorName",length=200,nullable=false)
	private String professorName;
	
	@Column(name="professorEmail")
	private String professorEmail;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="course",joinColumns=@JoinColumn(name="professorId"),inverseJoinColumns=@JoinColumn(name="courseId"))
	private List<Course> courseList = new ArrayList<>();

	@Override
	public String toString() {
		return "Professor [professorId=" + professorId + ", professorName=" + professorName + ", professorEmail="
				+ professorEmail + ", courseList=" + courseList + "]";
	}

	public int getProfessorId() {
		return professorId;
	}

	public void setProfessorId(int professorId) {
		this.professorId = professorId;
	}

	public String getProfessorName() {
		return professorName;
	}

	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}

	public String getProfessorEmail() {
		return professorEmail;
	}

	public void setProfessorEmail(String professorEmail) {
		this.professorEmail = professorEmail;
	}

	public List<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(List<Course> courseList) {
		this.courseList = courseList;
	}
	
	

}
