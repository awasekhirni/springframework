package com.tpri.exfiftythree.service;

import java.util.List;

import com.tpri.exfiftythree.model.Hotel;

public interface IHotelService {
	public abstract void addHotel(Hotel hotel);
	public abstract Hotel findHotelById(int hotelId);
	public abstract void removeHotelById(int hotelId);
	public abstract void changeHotelById(int hotelId,String hotelName, 
			String hotelAddress,String hotelRating);
	public abstract List<Hotel> findAllHotelDetails();
}
