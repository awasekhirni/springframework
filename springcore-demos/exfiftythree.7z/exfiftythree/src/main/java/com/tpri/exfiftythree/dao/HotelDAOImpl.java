package com.tpri.exfiftythree.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import com.tpri.exfiftythree.model.Hotel;

public class HotelDAOImpl implements IHotelDAO {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	private final String SQL_FIND = "select * from hotel where hotelId = :hotelId";
	private final String SQL_DELETE = "delete from hotel where hotelid = :hotelId";
	private final String SQL_UPDATE = "update hotel set hotelName = :hotelName, hotelAddress = :hotelAddress, hotelRating = :hotelRating where hotelId = :hotelId";
	private final String SQL_GETALL = "select * from hotel";
	private final String SQL_INSERT = "insert into hotel(hotelId,hotelName,hotelAddress,hotelRating) values(:hotelId,:hotelName,:hotelAddress,:hotelRating)";

	//setter injection
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	public void createHotel(Hotel hotel) {
		// TODO Auto-generated method stub
		
		MapSqlParameterSource inputMap = new MapSqlParameterSource();
		inputMap.addValue("hotelId", hotel.getHotelId());
		inputMap.addValue("hotelName", hotel.getHotelName());
		inputMap.addValue("hotelAddress", hotel.getHotelAddress());
		inputMap.addValue("hotelRanking",hotel.getHotelRating());
		System.out.println("inside DAO-createHotel:::"+hotel.toString());
		System.out.println(inputMap.getValues());
		int count=namedParameterJdbcTemplate.update(SQL_INSERT, inputMap);
		if(count>0) {
			System.out.println("A new hotel record has been created!");
		}
		
	}

	public Hotel getHotelById(int hotelId) {
		// TODO Auto-generated method stub
		
		
		MapSqlParameterSource inputMap = new MapSqlParameterSource();
		inputMap.addValue("hotelId", hotelId);
		
		 Hotel hotel = namedParameterJdbcTemplate.queryForObject(SQL_FIND, inputMap, new HotelRowMapper());
		return hotel;
	}

	public void deleteHotelById(int hotelId) {
		// TODO Auto-generated method stub
		MapSqlParameterSource inputMap = new MapSqlParameterSource();
		inputMap.addValue("hotelId", hotelId);
		
		int update = namedParameterJdbcTemplate.update(SQL_DELETE, inputMap);
		if(update>0)
			System.out.println("Employee is deleted..");

	}

	public void updateHotelById(int hotelId, String hotelName, String hotelAddress, String hotelRating) {
		// TODO Auto-generated method stub
		MapSqlParameterSource inputMap = new MapSqlParameterSource();
		inputMap.addValue("hotelId", hotelId);
		inputMap.addValue("hotelName", hotelName);
		inputMap.addValue("hotelAddress", hotelAddress);
		inputMap.addValue("hotelRating", hotelRating);
		int update = namedParameterJdbcTemplate.update(SQL_UPDATE, inputMap);
		if(update>0)
			System.out.println("Email is updated..");
	}

	public List<Hotel> getAllHotelDetails() {
		// TODO Auto-generated method stub
		List<Hotel> hotelList = namedParameterJdbcTemplate.query(SQL_GETALL, new HotelRowMapper());
		return hotelList;
	}

}
