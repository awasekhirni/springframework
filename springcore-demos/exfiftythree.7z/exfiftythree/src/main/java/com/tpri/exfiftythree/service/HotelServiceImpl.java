package com.tpri.exfiftythree.service;

import java.util.List;

import com.tpri.exfiftythree.dao.IHotelDAO;
import com.tpri.exfiftythree.model.Hotel;

public class HotelServiceImpl implements IHotelService {

	private IHotelDAO ihotelDAO;
	
	
	public void setIhotelDAO(IHotelDAO ihotelDAO) {
		this.ihotelDAO = ihotelDAO;
	}

	public void addHotel(Hotel hotel) {
		// TODO Auto-generated method stub
		System.out.println("Inside Hotel Service Add Hotel");
		this.ihotelDAO.createHotel(hotel);
	}

	public Hotel findHotelById(int hotelId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void removeHotelById(int hotelId) {
		// TODO Auto-generated method stub

	}

	public void changeHotelById(int hotelId, String hotelName, String hotelAddress, String hotelRating) {
		// TODO Auto-generated method stub

	}

	public List<Hotel> findAllHotelDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
