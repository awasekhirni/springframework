/**
 * 
 */
package com.tpri.exfiftythree;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tpri.exfiftythree.model.Hotel;
import com.tpri.exfiftythree.service.HotelServiceImpl;
/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyThreeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFiftyThreeMain-NamedParameterJDBCTemplate Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfiftythree.xml");
		
		HotelServiceImpl hiltonservice = (HotelServiceImpl)context.getBean("hotelservice");
		
//		Hotel hilton = new Hotel();
//		hilton.setHotelId(98239823);
//		hilton.setHotelName("Hilton International");
//		hilton.setHotelAddress("245 Vittal Malaya Road, Bangalore");
//		hilton.setHotelRating("4");
//		hiltonservice.addHotel(hilton);
		
		Hotel royal=hiltonservice.findHotelById(123787123);
		System.out.println(royal);
		//123787123
		
		context.close();

	}

}
