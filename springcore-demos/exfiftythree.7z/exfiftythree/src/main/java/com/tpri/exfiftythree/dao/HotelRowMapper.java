package com.tpri.exfiftythree.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.tpri.exfiftythree.model.Hotel;

public class HotelRowMapper implements RowMapper<Hotel> {

	
	public Hotel mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Hotel hotel = new Hotel();
		hotel.setHotelId(rs.getInt("hotelId"));
		hotel.setHotelName(rs.getString("hotelName"));
		hotel.setHotelAddress(rs.getString("hotelAddress"));
		hotel.setHotelRating(rs.getString("hotelRating"));
		return hotel;
	}

}

	

