package com.tpri.exfiftythree.dao;

import java.util.List;
import com.tpri.exfiftythree.model.Hotel;

public interface IHotelDAO {
	//abstract methods => CRUD operations
			public abstract void createHotel(Hotel hotel);
			public abstract Hotel getHotelById(int hotelId);
			public abstract void deleteHotelById(int hotelId);
			public abstract void updateHotelById(int hotelId,String hotelName, 
					String hotelAddress,String hotelRating);
			public abstract List<Hotel> getAllHotelDetails();
}
