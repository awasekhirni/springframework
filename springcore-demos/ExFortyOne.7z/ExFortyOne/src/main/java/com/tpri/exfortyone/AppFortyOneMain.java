/**
 * 
 */
package com.tpri.exfortyone;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyOneMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFortyOneMain: @Resource Annotation!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortyone.xml");
		Product samsung=(Product)context.getBean("productBean");
		
		System.out.println("Product Information");
		System.out.println(samsung.getProductId()+"\t"+samsung.getProductName()+"\t"+samsung.getProductPrice());
		System.out.println("Part Information");
		System.out.println(samsung.getPart().getPartId()+"\t"+samsung.getPart().getPartName()+"\t"+samsung.getPart().getPartDescription()+samsung.getPart().getPartPrice());
		context.close();
	}

}
