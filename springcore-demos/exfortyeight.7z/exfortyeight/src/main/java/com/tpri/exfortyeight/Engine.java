/**
 * 
 */
package com.tpri.exfortyeight;

/**
 * @author Awase Khirni Syed
 *
 */
public class Engine {

	
	private int engineCapacity;
	private String engineName;
	private int engineCylinder;
	public int getEngineCapacity() {
		return engineCapacity;
	}
	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
	public String getEngineName() {
		return engineName;
	}
	public void setEngineName(String engineName) {
		this.engineName = engineName;
	}
	public int getEngineCylinder() {
		return engineCylinder;
	}
	public void setEngineCylinder(int engineCylinder) {
		this.engineCylinder = engineCylinder;
	}
	
}
