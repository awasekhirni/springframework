/**
 * 
 */
package com.tpri.exfortyeight;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyEight {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("AppFortyEightMain: Spring P NameSpace Demo!");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortyeight.xml");
		Vehicle elantra = (Vehicle) context.getBean("vehicle");

		System.out.println("vehicle info--------------");
		System.out.println(
				elantra.getVehicleId() + "\t" + elantra.getVehicleName() + "\t" + elantra.getManufacturerName());

		System.out.println("engine info--------------");

		System.out.println(elantra.getEngine().getEngineName() + "\t" + elantra.getEngine().getEngineCylinder() + "\t"
				+ elantra.getEngine().getEngineCapacity());
		context.close();

	}

}
