/**
 * 
 */
package com.tpri.extwentythree;

/**
 * @author Awase Khirni Syed
 *
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class AppTwentyThreeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppTwentyThreeMain: Bean Definition Inheritance Demo 1");
		ApplicationContext context = new ClassPathXmlApplicationContext("apptwentythree.xml");
		Book gir=(Book)context.getBean("bookBean");
		System.out.println("Book Details: " + gir);
	}

}
