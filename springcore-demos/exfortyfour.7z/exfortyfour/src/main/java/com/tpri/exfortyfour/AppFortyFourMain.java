/**
 * 
 */
package com.tpri.exfortyfour;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFortyFourMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("AppFortyFourMain:Reading Properties Files for Application Configuration! ");
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appfortyfour.xml");
		System.out.println(context.getMessage("alert", null,"default message",null));
		
		context.close();

	}

}
