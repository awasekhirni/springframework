/**
 * 
 */
package com.tpri.exhiberanteseventy;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

import com.tpri.exhiberanteseventy.model.Category;
import com.tpri.exhiberanteseventy.model.HibernateUtilities;
import com.tpri.exhiberanteseventy.model.Stock;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppSeventyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("App70+ Hibernate many to many (Annotation)+MySQL");
		Session session = HibernateUtilities.getSessionFactory().openSession();

		session.beginTransaction();

		Stock stock = new Stock();
        stock.setStockCode("21378");
        stock.setStockName("SYCLIQ");
 
        Category category1 = new Category("syedawase", "SYCLIQ");
        Category category2 = new Category("VCInvestor", "SADATH SECURITIES");
    
        Set<Category> categories = new HashSet<Category>();
        categories.add(category1);
        categories.add(category2);
        
        stock.setCategories(categories);
        
        session.save(stock);
    
		session.getTransaction().commit();
		System.out.println("Done");
	}

}
