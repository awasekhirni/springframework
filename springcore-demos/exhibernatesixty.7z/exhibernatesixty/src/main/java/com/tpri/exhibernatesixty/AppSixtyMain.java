/**
 * 
 */
package com.tpri.exhibernatesixty;
import java.util.List;
import org.hibernate.Session;
import com.tpri.exhibernatesixty.model.Address;
import com.tpri.exhibernatesixty.model.Student;
import com.tpri.exhibernatesixty.util.HibernateUtil;
/** * @author Awase Khirni Syed  *  */
public class AppSixtyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student("Awase Khirni","Syed","Geographic Information Systems");
        Address address = new Address("227 Kalyan nagar","bangalore","karnataka");
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.persist(address);
        student.setAddress(address);
        session.persist(student);
        List<Student> students = (List<Student>)session.createQuery("from Student ").list();
        for(Student s: students){
            System.out.println("Details : "+s);
        }
        session.getTransaction().commit();
        session.close();  
	}

}
