/**
 * 
 */
package com.tpri.extwentycore;

/**
 * @author Awase Khirni Syed
 *
 */
public class Player {
	public int playerId;
	public String playerName;

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

}
