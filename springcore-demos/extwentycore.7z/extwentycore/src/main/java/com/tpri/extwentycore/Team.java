/**
 * 
 */
package com.tpri.extwentycore;

import java.util.List;

/**
 * @author Awase Khirni Syed
 *
 */
public class Team {
	
	private List<Player> players;

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	
	public void displayPlayers() {
		for(Player player:players) {
			System.out.println("player Info:=>{"+player.getPlayerId()+","+player.getPlayerName()+"}");
		}
		
	}
	
}
