/**
 * 
 */
package com.tpri.exfiftyeight;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.tpri.exfiftyeight.model.Address;
import com.tpri.exfiftyeight.model.Person;
import com.tpri.exfiftyeight.util.HibernateUtil;

/**
 * @author Awase Khirni Syed
 *
 */
public class AppFiftyEightMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("AppFiftyEight-- Hibernate + MYSQL + ONE_ONE MAPPING+ SHARED PRIMARY KEY OPTION");
		Configuration configuration = new Configuration();
		SessionFactory sessionFactory = configuration.configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		Address address1 = new Address("Kalyan Nagar", "Bangalore", "Karnataka", "56043");
		Address address2 = new Address("Banjara Hills", "hyderabad", "Karnataka", "520043");
		session.save(address1);
		session.save(address2);
		transaction.commit();
		transaction=session.beginTransaction();
		Person person1 = new Person("Awase", address1);
		Person person2 = new Person("Sadath", address2);
		session.save(person1);
		session.save(person2);
		transaction.commit();		
		AppFiftyEightMain app= new AppFiftyEightMain();
		app.listPersonInfo();

	}

	public Long savePersonInfo(String personName, Address address) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Long personId = null;
		Transaction transaction = null;
		try {
			System.out.println("Inside tryblock-savePersonInfo()");
			transaction = session.beginTransaction();
			Person person = new Person(personName, address);

			address.setPerson(person);
			session.save(person);

			transaction.commit();
			System.out.println("Inside after committryblock-savePersonInfo()");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return personId;
	}

	/*
	 * Lists the person's from database table
	 */
	public void listPersonInfo() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			@SuppressWarnings("unchecked")
			List<Person> personList = session.createQuery("from Person").list();
			for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {
				Person person = (Person) iterator.next();
				System.out.println(person.getName());
				System.out.println(person.getAddress().getStreet() + " " + person.getAddress().getCity() + " "
						+ person.getAddress().getState() + " " + person.getAddress().getZipcode());
			}
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}
