/**
 * 
 */
package com.tpri.exspringmvcapp.web.interceptor;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
/**
 * @author Awase Khirni Syed
 *
 */
public class MidWeekInterceptor extends HandlerInterceptorAdapter {

	
	public boolean preHandler(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
		
		Calendar cal = Calendar.getInstance();
		
		int dayofWeek =cal.get(Calendar.DAY_OF_WEEK);
		if(dayofWeek==4) { //starts from 1-sunday
		response.getWriter().write("WEDNESDAY- KFC CHICKEN BUCKET FOR 499");
			return false;
	}
		return true;
	}
}
