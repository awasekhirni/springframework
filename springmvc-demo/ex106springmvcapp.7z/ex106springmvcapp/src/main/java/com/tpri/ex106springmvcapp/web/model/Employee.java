package com.tpri.ex106springmvcapp.web.model;

import java.util.ArrayList;
import java.util.Date;

public class Employee {
	private String empName;
	private Long empMobile;
	private Date empDOB;
	private ArrayList<String> empSkills;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Long getEmpMobile() {
		return empMobile;
	}
	public void setEmpMobile(Long empMobile) {
		this.empMobile = empMobile;
	}
	public Date getEmpDOB() {
		return empDOB;
	}
	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}
	public ArrayList<String> getEmpSkills() {
		return empSkills;
	}
	public void setEmpSkills(ArrayList<String> empSkills) {
		this.empSkills = empSkills;
	}
}
