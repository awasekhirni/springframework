package com.tpri.ex106springmvcapp.web.model;

import java.util.Date;

public class Order {
	private int orderId;
	private Date orderDate;
	private String deliveryAddress;
	private String deliveryCity;
	private String deliverZipcode;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getDeliveryAddress() {
		return deliveryAddress;
	}
	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}
	public String getDeliveryCity() {
		return deliveryCity;
	}
	public void setDeliveryCity(String deliveryCity) {
		this.deliveryCity = deliveryCity;
	}
	public String getDeliverZipcode() {
		return deliverZipcode;
	}
	public void setDeliverZipcode(String deliverZipcode) {
		this.deliverZipcode = deliverZipcode;
	}
	
}
