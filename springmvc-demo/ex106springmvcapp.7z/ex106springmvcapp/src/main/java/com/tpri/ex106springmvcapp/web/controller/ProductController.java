package com.tpri.ex106springmvcapp.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.tpri.ex106springmvcapp.web.model.Product;
@Controller
public class ProductController {
	@RequestMapping(value="/addproduct",method=RequestMethod.GET)
	public ModelAndView addProduct() {
		ModelAndView model = new ModelAndView("addproduct");
		model.addObject("titleInfo","Flipkart Company");
		return model;
	}
	@RequestMapping(value="/displayproduct",method=RequestMethod.POST)
	public ModelAndView displayProduct(@RequestParam("productId") int productId, 
			@RequestParam("productName") String productName, 
			@RequestParam("productDesc") String productDesc, 
			@RequestParam("productPrice") int productPrice,
			@RequestParam("productDiscount") int productDiscount) {
		//product instantiation
		Product samsung = new Product();
		samsung.setProductId(productId);
		samsung.setProductName(productName);
		samsung.setProductDesc(productDesc);
		samsung.setProductPrice(productPrice);
		samsung.setProductDiscount(productDiscount);
		//modelbinding
		ModelAndView model = new ModelAndView("displayproduct");
		model.addObject("titleInfo","Flipkart Company");
		model.addObject("samsung",samsung);
		return model;
	}
}
