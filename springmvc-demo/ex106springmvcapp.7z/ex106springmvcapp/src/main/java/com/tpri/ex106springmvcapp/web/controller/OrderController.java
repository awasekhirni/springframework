package com.tpri.ex106springmvcapp.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tpri.ex106springmvcapp.web.model.Order;

@Controller
public class OrderController {
	@RequestMapping(value="addorder",method=RequestMethod.GET)
	public ModelAndView addOrder() {
		ModelAndView model = new ModelAndView("addorder");
		
		return model;
	}
	//global message binding with view 
	@ModelAttribute
	public void addingCommonObjects(Model model) {
		model.addAttribute("titleInfo","Flipkart Company");
	}
	//Using Model Attribute Annotation 
	//Minimal code 
	@RequestMapping(value="displayorder",method=RequestMethod.POST)
	public ModelAndView displayOrder(@ModelAttribute("myorder") Order myorder) {
		ModelAndView model = new ModelAndView("displayorder");
		
		return model;
	}
}
