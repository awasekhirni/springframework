package com.tpri.exspringmvcapp.web.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tpri.exspringmvcapp.web.model.User;
import com.tpri.exspringmvcapp.web.service.UserServiceImpl;

@Controller
@RequestMapping("/user") 
public class UserController {
	
	
	UserServiceImpl userService;
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String register(Map<String,Object> map) {
		map.put("user", new User());
		return "user/register";
	}
	//public String save(@ModelAttribute("company")Company company,BindingResult result, ModelMap map)
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public String create(@ModelAttribute("user") User user, Map<String,Object> map) {
		
		userService.addUser(user);
		System.out.println(user.toString());
		return "redirect:/user/details/"+user.getUserId();
	}
	
	@RequestMapping(value="/details/{userId}",method=RequestMethod.GET)
	public String details(@PathVariable("userId") Long userId,Map<String, Object> map) {
		User user = userService.fetchUser(userId);
		map.put("firstName",user.getFirstName());
		System.out.println(user.getFirstName());
		map.put("lastName",user.getLastName());
		map.put("email",user.getEmail());
		map.put("mobile",user.getMobile());
		return "user/details";
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public String list(Map<String,Object> map) {
		map.put("userlist",userService.fetchAllUsers());
		return "user/list";
	}
	
	@RequestMapping(value="/edit/{userId}",method=RequestMethod.GET)
	public String edit(@PathVariable("userId")Long userId, Map<String,Object> map) {
		
		User user = userService.fetchUser(userId);
		map.put("user",user);
		return "user/edit";
	}
	
	@RequestMapping(value="",method=RequestMethod.GET)
	public String update(@ModelAttribute("user") User user, Map<String,Object> map) {
		userService.changeUser(user);
		return "redirect:/user/details"+user.getUserId();
	}
	
	
	@RequestMapping(value="/delete/{userId}",method=RequestMethod.GET)
	public String delete(@PathVariable("userId")Long userId, Map<String,Object> map) {
		userService.removeUser(userId);	
		return "redirect:user/list";
	}
}
