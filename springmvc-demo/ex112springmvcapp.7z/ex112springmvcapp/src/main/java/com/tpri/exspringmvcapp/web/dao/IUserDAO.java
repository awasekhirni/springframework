package com.tpri.exspringmvcapp.web.dao;

import java.util.List;

import com.tpri.exspringmvcapp.web.model.User;

public interface IUserDAO {
	public void createUser(User user);
	public void updateUser(User user);
	public User editUser(Long userId);
	public void deleteUser(Long userId);
	public User findUser(Long userId);
	public List<User> findAllUsers();

}
