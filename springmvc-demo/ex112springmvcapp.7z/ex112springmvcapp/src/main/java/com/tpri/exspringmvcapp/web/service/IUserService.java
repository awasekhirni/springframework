package com.tpri.exspringmvcapp.web.service;

import java.util.List;

import com.tpri.exspringmvcapp.web.model.User;

public interface IUserService {
	public void addUser(User user);
	public void changeUser(User user);
	public User saveEditUser(Long userId);
	public void removeUser(Long userId);
	public User fetchUser(Long userId);
	public List<User> fetchAllUsers();
}
