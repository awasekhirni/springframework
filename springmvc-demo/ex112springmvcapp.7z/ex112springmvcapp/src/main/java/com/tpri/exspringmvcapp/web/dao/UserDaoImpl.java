package com.tpri.exspringmvcapp.web.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tpri.exspringmvcapp.web.model.User;

@Repository("userDao")
public class UserDaoImpl implements IUserDAO {

	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void createUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("Inside UserDAOImplementation");
		sessionFactory.getCurrentSession().save(user);
	}

	public void updateUser(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(user);
	}

	public User editUser(Long userId) {
		// TODO Auto-generated method stub
		return findUser(userId);
	}

	public void deleteUser(Long userId) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(userId);
		
	}

	public User findUser(Long userId) {
		// TODO Auto-generated method stub
		return (User) sessionFactory.getCurrentSession().get(User.class, userId);
		
	}

	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().createCriteria(User.class).list();
		return null;
	}

}
