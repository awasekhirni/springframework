package com.tpri.exspringmvcapp.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tpri.exspringmvcapp.web.dao.IUserDAO;
import com.tpri.exspringmvcapp.web.model.User;

@Service("userService")
@Transactional(propagation=Propagation.SUPPORTS,rollbackFor=Exception.class)
public class UserServiceImpl implements IUserService {
	@Autowired
	IUserDAO userDao;
	
	@Transactional
	public void addUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("Inside UserServiceImplementation");
		userDao.createUser(user);
	}

	@Transactional
	public void changeUser(User user) {
		// TODO Auto-generated method stub
		userDao.updateUser(user);
	}

	public User saveEditUser(Long userId) {
		// TODO Auto-generated method stub
		return userDao.editUser(userId);
	}

	public void removeUser(Long userId) {
		// TODO Auto-generated method stub
			userDao.deleteUser(userId);
	}

	public User fetchUser(Long userId) {
		// TODO Auto-generated method stub
		return userDao.findUser(userId);
	}

	public List<User> fetchAllUsers() {
		// TODO Auto-generated method stub
		return userDao.findAllUsers();
	}

}
