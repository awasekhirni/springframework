package com.tpri.ex103springmvcapp.controller;
// Author-Awase Khirni Syed 2014-15
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//multiaction controller class demo

@Controller
public class HomeController {
	@RequestMapping(value="/")
	public ModelAndView index(HttpServletResponse response) throws IOException{
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="/home")
	public ModelAndView home(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}

	@RequestMapping(value="/about")
	public ModelAndView about(HttpServletResponse response) throws IOException{
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="/contact")
	public ModelAndView contact(HttpServletResponse response) throws IOException{
		return new ModelAndView("contact");
	}
	
	@RequestMapping(value="/pricing")
	public ModelAndView pricing(HttpServletResponse response) throws IOException{
		return new ModelAndView("pricing");
	}
}
