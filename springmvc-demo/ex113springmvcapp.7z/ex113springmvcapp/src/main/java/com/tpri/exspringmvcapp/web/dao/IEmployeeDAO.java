package com.tpri.exspringmvcapp.web.dao;

import java.util.List;

import com.tpri.exspringmvcapp.web.model.Employee;

public interface IEmployeeDAO {
	
	public List<Employee> listEmployees();
	public Employee getEmployee(int empid);
	public void deleteEmployee(Employee employee);
	public void addEmployee(Employee employee);
	
}
