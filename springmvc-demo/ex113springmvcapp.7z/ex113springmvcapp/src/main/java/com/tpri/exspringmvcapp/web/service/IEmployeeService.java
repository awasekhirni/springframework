package com.tpri.exspringmvcapp.web.service;

import java.util.List;

import com.tpri.exspringmvcapp.web.model.Employee;

public interface IEmployeeService {
	public void addEmployee(Employee employee);

	public List<Employee> listEmployees();

	public Employee getEmployee(int empid);

	public void deleteEmployee(Employee employee);
}
