package com.tpri.exspringmvcapp.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tpri.exspringmvcapp.web.model.Customer;

@Controller
public class CustomerController {
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	private Map<String, Customer> customers = null;

	private CustomerController() {
		customers = new HashMap<String, Customer>();
	}

	@RequestMapping(value = "/cust/save", method = RequestMethod.GET)
	public String saveCustomerPage(Model model) {
		logger.info("Returning custSave.jsp page");
		model.addAttribute("customer", new Customer());
		return "custSave";
	}

	@RequestMapping(value = "/cust/save.do", method = RequestMethod.POST)
	public ModelAndView saveCustomerAction(@Valid Customer customer, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning custSave.jsp page");
			System.out.println("Validation Error on the page");
			ModelAndView mymodel = new ModelAndView("custSave");
			return mymodel;

		}
//		logger.info("Returning custSaveSuccess.jsp page");
//		model.addAttribute("customer", customer);
//		customers.put(customer.getEmail(), customer);
//		return "custSaveSuccess";
		ModelAndView model1= new ModelAndView("custSaveSuccess");
		return model1;
		
	}
}
