package com.tpri.ex108springmvcapp.web.util;

import java.beans.PropertyEditorSupport;

public class SalutationEditor extends PropertyEditorSupport {

	@Override
	public void setAsText(String holderName) throws IllegalArgumentException{
		
		if(holderName.contains("Mr.")|| holderName.contains("Ms.")) {
			setValue(holderName);
		}else {
			holderName="Ms."+holderName;
			setValue(holderName);
		}
	}
}
