package com.tpri.ex108springmvcapp.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tpri.ex108springmvcapp.web.model.CreditCard;
import com.tpri.ex108springmvcapp.web.util.CreditCardEditor;
import com.tpri.ex108springmvcapp.web.util.SalutationEditor;

@Controller
public class CardController {
	@InitBinder 
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(String.class, "holderName",new SalutationEditor());
		binder.registerCustomEditor(String.class, "rawCardNumber", new CreditCardEditor());
	}
	
	@RequestMapping(value="/addcreditcard", method=RequestMethod.GET)
	public ModelAndView addCreditCard() {
		ModelAndView model = new ModelAndView("addcreditcard");
		return model;
	}
	
	@ModelAttribute
	public void addingCommonObjects(Model model) {
		model.addAttribute("TitleInfo","CITIBANK Credit Card Processing Unit");
		
	}
	
	@RequestMapping(value="/displaycreditcard",method=RequestMethod.POST)
	public ModelAndView displayInfo(@ModelAttribute("creditcard") CreditCard creditcard ) {
		
		ModelAndView model = new ModelAndView("displaycreditcard");
		return model;
	}
	

}
