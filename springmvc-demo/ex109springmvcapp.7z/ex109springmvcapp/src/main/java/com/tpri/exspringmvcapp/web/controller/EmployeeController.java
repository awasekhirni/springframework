package com.tpri.exspringmvcapp.web.controller;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tpri.exspringmvcapp.web.model.Employee;

@Controller
public class EmployeeController {
	// specific requirements //custom validation or custom binding 
	//webdatabinder and initbinder 
	// it skips data binding for fathername and dateofbirth
	@InitBinder
	public void skipBinding(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {"empFatherName","empDOB" });
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy**MM**dd");
		binder.registerCustomEditor(Date.class,"empDOB",new CustomDateEditor(dateFormat,false));
	}
	@RequestMapping(value="/addemployee",method=RequestMethod.GET)
	public ModelAndView addEmployee() {
		ModelAndView model = new ModelAndView("addemployee");
		return model;
	}	
	@ModelAttribute
	public void addingCommonObjects(Model model) {
		model.addAttribute("TitleInfo","Human Resource Employee Records");
	}
	@RequestMapping(value="/displayemployee",method=RequestMethod.POST)
	public ModelAndView displayEmployee(@ModelAttribute("employee") Employee employee, BindingResult result) {
		if(result.hasErrors()) {
			ModelAndView model = new ModelAndView("addemployee");
			return model;
		}
		ModelAndView model = new ModelAndView("displayemployee");
		return model;
	}
}
