package com.tpri.exspringmvcapp.web.model;

import java.util.ArrayList;
import java.util.Date;

public class Employee {
	private int empId;
	private String empName;
	private String empFatherName;
	private Long empSalary;
	private Date empDOB;
	private ArrayList<String> empSkills;
	private Address empAddress;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpFatherName() {
		return empFatherName;
	}
	public void setEmpFatherName(String empFatherName) {
		this.empFatherName = empFatherName;
	}
	public Long getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(Long empSalary) {
		this.empSalary = empSalary;
	}
	public Date getEmpDOB() {
		return empDOB;
	}
	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}
	public ArrayList<String> getEmpSkills() {
		return empSkills;
	}
	public void setEmpSkills(ArrayList<String> empSkills) {
		this.empSkills = empSkills;
	}
	public Address getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}
	
	
	
}
