package com.tpri.ex107springmvcapp.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.tpri.ex107springmvcapp.web.model.Employee;

@Controller
public class EmployeeController {
	@RequestMapping(value="/addemployee", method=RequestMethod.GET)
	public ModelAndView addEmployee() {
		ModelAndView model = new ModelAndView("addemployee");
		return model;
	}
	@ModelAttribute 
	public void addingCommonObjects(Model model) {
		model.addAttribute("pageTitle","Human Resources Department:Employee Information");	
	}
	@RequestMapping(value="/displayemployee", method=RequestMethod.POST)
	public ModelAndView displayEmployee(@ModelAttribute("employee") Employee employee, BindingResult result) {
		if(result.hasErrors()) {
			ModelAndView model = new ModelAndView("addemployee");
			return model;
		}
		ModelAndView model = new ModelAndView("displayemployee");
		return model;
	}
	
}
