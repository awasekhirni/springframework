package com.tpri.ex107springmvcapp.web.model;

import java.util.ArrayList;
import java.util.Date;

public class Employee {

	private int empId;
	private String empName;
	private Date empDOB;
	private Long empMobile;
	private ArrayList<String> empSkills;
	private Address empAddress;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Date getEmpDOB() {
		return empDOB;
	}
	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}
	public Long getEmpMobile() {
		return empMobile;
	}
	public void setEmpMobile(Long empMobile) {
		this.empMobile = empMobile;
	}
	public ArrayList<String> getEmpSkills() {
		return empSkills;
	}
	public void setEmpSkills(ArrayList<String> empSkills) {
		this.empSkills = empSkills;
	}
	public Address getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}
	
}
