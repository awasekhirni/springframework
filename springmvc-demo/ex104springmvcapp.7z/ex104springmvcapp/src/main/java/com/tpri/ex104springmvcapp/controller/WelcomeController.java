package com.tpri.ex104springmvcapp.controller;

import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {

	
	@RequestMapping("/welcome/{countryName}/{userName}")
	public ModelAndView greetMe(@PathVariable("userName") String uName, @PathVariable("countryName") String cName) {
		ModelAndView model = new ModelAndView("greet");
		model.addObject("msg","hello "+uName +"\t"+ "You are calling me from "+cName);
		return model;
	}
	
	
	// need to place <mvc:annotation-driven/> tag in spring dispatch servlet
	@RequestMapping("/broadcast/{countryName}/{userName}")
	public ModelAndView broadCastGreet(@PathVariable Map<String,String> pathVars)  {
		String uName=pathVars.get("userName");
		String cName = pathVars.get("countryName");
		
		ModelAndView model = new ModelAndView("broadcastgreet");
		model.addObject("msg","hello "+uName +"\t"+ "You are calling me from "+cName);
		return model;
	}
	
	
}
