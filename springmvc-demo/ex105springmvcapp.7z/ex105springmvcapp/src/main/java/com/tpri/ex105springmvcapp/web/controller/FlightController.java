package com.tpri.ex105springmvcapp.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FlightController {

	@RequestMapping(value="/flightbooking", method=RequestMethod.GET)
	public ModelAndView flightBookingForm() {
		
		ModelAndView model = new ModelAndView("flightbooking");
		
		return model;
	}
	
	
	@RequestMapping(value="/success",method=RequestMethod.POST)
	public ModelAndView bookingStatus(@RequestParam("startCity") String startCity, @RequestParam("destinationCity") String destinationCity){
		
		ModelAndView model = new ModelAndView("success");
		model.addObject("flightInfo","Your flight booking is confirmed for start city:"+ startCity+"\t"+"to destination city:"+destinationCity);
		return model;
	}
}

