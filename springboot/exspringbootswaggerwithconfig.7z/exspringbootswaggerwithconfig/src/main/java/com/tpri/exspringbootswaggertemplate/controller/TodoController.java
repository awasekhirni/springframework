package com.tpri.exspringbootswaggertemplate.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.exspringbootswaggertemplate.model.Todo;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api")
public class TodoController {

	ConcurrentMap<String,Todo> todos=new ConcurrentHashMap<>();
	
	@GetMapping("/{todoId}")
	@ApiOperation(value="Finds Todos by Id", notes="Provide an id to look up specific todo task from the todos list", response=Todo.class)
	public Todo getTodo(@PathVariable String todoId) {
		return todos.get(todoId);
	}
	
	@GetMapping("/")
	@ApiOperation(value="Finds All Todos ", notes="provides a list of todo tasks and lists", response=Todo.class)
	public List<Todo> getAllTodo() {
		return new ArrayList<Todo>(todos.values());
	}
	
	@PostMapping("/add")
	@ApiOperation(value="Add a new todotask", notes="Add a new todo task", response=Todo.class)
	public Todo addTodo(@RequestBody Todo todo) {
		todos.put(todo.getTodoId(), todo);
		return todo;
	}
	
}
