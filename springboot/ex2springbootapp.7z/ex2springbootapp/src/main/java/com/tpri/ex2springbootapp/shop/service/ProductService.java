package com.tpri.ex2springbootapp.shop.service;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tpri.ex2springbootapp.shop.model.Product;

@Service
public class ProductService {

	private List<Product> products =  new ArrayList<>(Arrays.asList(

			new Product("1", "ATH M50X Headphone", "http://i.ebayimg.com/00/s/MTAwMFgxMDAw/z/YFYAAOSwPhdVOjdQ/$_12.JPG",
					"ATH-M50xDG Limited Edition Professional Studio Monitor Headphones - Dark Green; Pure. Professional. Performance. As the most critically acclaimed model in the M-Series line, the ATH-M50 is praised by top audio engineers and pro audio reviewers year after year.",
					"Electronics", "8631", "3", "0", "Mumbai", "#6B5419",
					"http://www.ebay.in/sch/i.html?_nkw=m50x&_sop=16"),
			new Product("2", "Sony PS4 500GB", "http://i.ebayimg.com/00/s/NDcyWDYxOA==/z/wM4AAOSwZjJVAEUf/$_12.JPG",
					"The PlayStation4 system opens the door to an incredible journey through immersive new gaming worlds and a deeply connected gaming community. PS4 puts gamers first with an astounding launch lineup and over 180 games in development. Play amazing top-tier blockbusters and innovative indie hits on PS4.",
					"Electronics", "34463", "7", "0", "Delhi", "#302E29",
					"http://www.ebay.in/sch/i.html?_nkw=ps4&_sop=16"),
			new Product("3", "Handy Chopper (Slicer)",
					"http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/bPAAAOSwBahU7V4G/$_12.JPG",
					"Nicer Dicer With Plus you have a kitchen helper, who will shorten the cooking time from start of preparation to the serving of the meal tremendously.",
					"Household", "549", "10", "0", "Chennai", "#B6E314",
					"http://www.ebay.in/sch/i.html?_nkw=NICER+DICER+PLUS+CHOPPER&_sop=16")));

	public List<Product> getAllProducts() {
		return products;
	}

	public Product getProduct(String id) {
			return products.stream().filter(p->p.getId().equals(id)).findFirst().get();
	}

	public void addProduct(Product product) {
		products.add(product);
	}

	public void updateProduct(String id, Product product) {
		// TODO Auto-generated method stub
		for(int i=0;i<products.size(); i++) {
			Product p = products.get(i);
			if(p.getId().equals(id)){
				products.set(i, product);
				return;
			}
		}
		
	}

	public void deleteProduct(String id) {
		// TODO Auto-generated method stub
		products.removeIf(p->p.getId().equals(id));
	}
}
