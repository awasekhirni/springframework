package com.tpri.ex2springbootapp.shop.model;
//https://github.com/awasekhirni/jsondata/blob/master/ebayproducts.json
public class Product {
	private String id;
	private String name;
	private String image;
	private String description;
	private String category;
	private String price;
	private String quantity;
	private String shipping;
	private String location;
	private String color;
	private String link;
	
	public Product() {}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Product(String id, String name, String image, String description, String category, String price,
			String quantity, String shipping, String location, String color, String link) {
		super();
		this.id = id;
		this.name = name;
		this.image = image;
		this.description = description;
		this.category = category;
		this.price = price;
		this.quantity = quantity;
		this.shipping = shipping;
		this.location = location;
		this.color = color;
		this.link = link;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getShipping() {
		return shipping;
	}
	public void setShipping(String shipping) {
		this.shipping = shipping;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	
}
