package com.tpri.ex12springsecuritydemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="App_User",uniqueConstraints= {
		 @UniqueConstraint(name = "APP_USER_UK", columnNames = "User_Name"),
         @UniqueConstraint(name = "APP_USER_UK2", columnNames = "Email")
})
public class AppUser {

	@Id
	@GeneratedValue
	@Column(name="User_id",nullable=false)
	private Long userId;
	
	@Column(name="User_Name",length=35, nullable=false)
	private String userName;
	
	@Column(name="Email",length=128, nullable=false)
	private String email;
	
	@Column(name="First_Name",length=36, nullable=true)
	private String firstName;
	
	@Column(name="Last_Name",length=36, nullable=true)
	private String lastName;
	
	
	@Column(name="Encrypted_Password",length=128, nullable=false)
	private String encryptedPassword;
	
	@Column(name="Enabled",length=1,nullable=false)
	private boolean enabled;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public AppUser() {}
	public AppUser(Long userId, String userName, String email, String firstName, String lastName,
			String encryptedPassword, boolean enabled) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.encryptedPassword = encryptedPassword;
		this.enabled = enabled;
	}
	
	
	
	
}
