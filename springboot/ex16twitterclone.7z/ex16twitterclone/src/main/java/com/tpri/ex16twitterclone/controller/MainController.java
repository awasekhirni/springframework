package com.tpri.ex16twitterclone.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.tpri.ex16twitterclone.repository.ErrorDTO;

@ControllerAdvice
public class MainController {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorDTO> handleException(Exception e){
		ErrorDTO errorDTO=new ErrorDTO();
		errorDTO.seteMessage(e.getMessage());
		((ErrorDTO) errorDTO).setStatusCode(500);
		return new ResponseEntity<ErrorDTO>(errorDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
