package com.tpri.ex16twitterclone.model;

public enum Role{
	ADMIN,USER
}