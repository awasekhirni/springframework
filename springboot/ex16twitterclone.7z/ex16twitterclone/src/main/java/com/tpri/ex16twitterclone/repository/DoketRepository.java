package com.tpri.ex16twitterclone.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tpri.ex16twitterclone.model.Doket;

public interface DoketRepository extends JpaRepository<Doket,Integer> {

	List<Doket> findByDoketUser_ScreenNameOrContentContains(String screenName, String mention);
	
}
