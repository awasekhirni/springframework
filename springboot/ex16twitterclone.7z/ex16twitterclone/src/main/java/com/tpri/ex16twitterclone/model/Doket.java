package com.tpri.ex16twitterclone.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Getter
@Setter
public class Doket implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3405513728761080171L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer doketId;
	
	@CreationTimestamp
	private Timestamp postTime;
	
	@ManyToOne
	private User doketUser;
	
	@NotNull
	private String content;

	public Integer getDoketId() {
		return doketId;
	}

	public void setDoketId(Integer doketId) {
		this.doketId = doketId;
	}

	public Timestamp getPostTime() {
		return postTime;
	}

	public void setPostTime(Timestamp postTime) {
		this.postTime = postTime;
	}

	public User getDoketUser() {
		return doketUser;
	}

	public void setDoketUser(User doketUser) {
		this.doketUser = doketUser;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Doket(Integer doketId, Timestamp postTime, User doketUser, String content) {
		super();
		this.doketId = doketId;
		this.postTime = postTime;
		this.doketUser = doketUser;
		this.content = content;
	}

	public Doket() {}
	

}
