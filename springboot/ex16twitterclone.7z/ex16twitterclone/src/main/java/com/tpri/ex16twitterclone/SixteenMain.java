/**
 * 
 */
package com.tpri.ex16twitterclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Awase Khirni Syed
 *
 */
@SpringBootApplication
public class SixteenMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SixteenMain.class,args);
	}

}
