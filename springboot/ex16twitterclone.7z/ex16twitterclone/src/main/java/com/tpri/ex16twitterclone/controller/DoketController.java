package com.tpri.ex16twitterclone.controller;

import java.security.Principal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex16twitterclone.model.Doket;
import com.tpri.ex16twitterclone.model.User;
import com.tpri.ex16twitterclone.service.DoketService;
import com.tpri.ex16twitterclone.service.UserService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/dockets")
public class DoketController {

	public DoketService doketService;
	public UserService userService;
	
	public DoketController(DoketService doketService, UserService userService) {
		
		this.doketService = doketService;
		this.userService = userService;
	}
	
	
	@PostMapping
    public Flux<Object> save(Principal principal, @RequestBody Doket doket) {
        Mono<User> user = userService.getUserByScreenName(principal.getName());
        return user.flatMap(u -> {
                                   doket.setDoketUser(u);
                                   return doketService.save(doket);
                                 });
    }

    @GetMapping
    public Flux<Doket> getAll(Principal principal) {
        return doketService.getRelevantDokets(principal.getName());
    }
	
	
}
