package com.tpri.ex16twitterclone.controller;

import java.security.Principal;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex16twitterclone.model.User;
import com.tpri.ex16twitterclone.service.UserService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/users")
public class UserController {

	private UserService userService;
	
	public UserController(UserService userService) {
		this.userService=userService;
	}
	
	@GetMapping("/{screenName}")
    public Mono<User> getUserByScreenName(@PathVariable String screenName) {
        return userService.getUserByScreenName(screenName);
    }

    @PutMapping("/{userId}/follow")
    @ResponseStatus(code = HttpStatus.OK)
    public void followUser(Principal principal, @PathVariable String userId) {
        Mono<User> user = userService.getUserByScreenName(principal.getName());
        user.subscribe(u -> {
            if (!u.getId().equalsIgnoreCase(userId)) {
                u.getFollowing().add(userId);
                userService.save(u);
            }
        });
    }
}
