package com.tpri.ex16twitterclone.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tpri.ex16twitterclone.model.User;

public interface UserRepository extends JpaRepository<User,Integer> {
	User findByScreenName(String screenName);

	
}
