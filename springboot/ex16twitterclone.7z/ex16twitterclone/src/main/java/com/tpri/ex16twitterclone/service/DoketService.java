package com.tpri.ex16twitterclone.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import reactor.core.scheduler.*;
import com.tpri.ex16twitterclone.model.Doket;
import com.tpri.ex16twitterclone.repository.DoketRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Transactional(readOnly=true)
public class DoketService {

	private DoketRepository doketRepository ;
	private Scheduler dbScheduler;
	
	public DoketService(DoketRepository doketRepository, Scheduler dbScheduler) {
		this.dbScheduler=dbScheduler;
		this.doketRepository=doketRepository;
	}
	
	@Transactional(rollbackFor = Exception.class)
    public Mono<Doket> save(Doket doket) {
        return Mono.fromCallable(() -> doketRepository.save(doket)).publishOn((reactor.core.scheduler.Scheduler) dbScheduler);
    }

    public Flux<Doket> getTweets() {
        return Flux.fromIterable(doketRepository.findAll()).publishOn((reactor.core.scheduler.Scheduler) dbScheduler);
    }

    public Flux<Doket> getRelevantDokets(String screenName) {
        return Flux.fromIterable(doketRepository.findByDoketUser_ScreenNameOrContentContains(screenName, "@"+screenName)).publishOn((reactor.core.scheduler.Scheduler) dbScheduler);
    }
	
}
