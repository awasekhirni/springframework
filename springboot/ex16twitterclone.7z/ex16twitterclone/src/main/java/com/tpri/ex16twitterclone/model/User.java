package com.tpri.ex16twitterclone.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Getter
@Setter
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4606099521168917335L;

	@Id
	@NotNull
	private String Id;
	
	@JsonIgnore
	@NotNull
	private String password;
	
	@NotNull
	@Column(unique=true)
	private String screenName;
	
	
	@NotNull
	private Role role;
	
	@NotNull
	private String bio;
	
	@NotNull
	private String profileImage;
	
	@ElementCollection
	private Set<String> following;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public Set<String> getFollowing() {
		return following;
	}

	public void setFollowing(Set<String> following) {
		this.following = following;
	}

	public User(String id, String password, String screenName, Role role, String bio, String profileImage,
			Set<String> following) {
		super();
		Id = id;
		this.password = password;
		this.screenName = screenName;
		this.role = role;
		this.bio = bio;
		this.profileImage = profileImage;
		this.following = following;
	}
	
	public User() {}

	
	
	
	
}
