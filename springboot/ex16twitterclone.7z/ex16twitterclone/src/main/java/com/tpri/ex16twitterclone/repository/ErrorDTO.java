package com.tpri.ex16twitterclone.repository;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Entity
public class ErrorDTO {
	@Id
	private Integer errorId;
	private Integer statusCode;
	private String eMessage;
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public String geteMessage() {
		return eMessage;
	}
	public void seteMessage(String eMessage) {
		this.eMessage = eMessage;
	}
	public ErrorDTO(Integer statusCode, String eMessage) {
		super();
		this.statusCode = statusCode;
		this.eMessage = eMessage;
	}
	public ErrorDTO() {
		// TODO Auto-generated constructor stub
	}
	
	
}
