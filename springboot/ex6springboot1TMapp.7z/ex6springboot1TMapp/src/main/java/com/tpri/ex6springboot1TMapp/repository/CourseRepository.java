package com.tpri.ex6springboot1TMapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex6springboot1TMapp.model.Course;

@Repository
public interface CourseRepository extends CrudRepository<Course,Long> {

}
