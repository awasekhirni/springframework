package com.tpri.ex6springboot1TMapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.tpri.ex6springboot1TMapp.model.Course;
import com.tpri.ex6springboot1TMapp.repository.CourseRepository;

@Service
public class CourseServiceImpl implements ICourseService {

	@Autowired
	private CourseRepository courserepo;
	
	public Iterable<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return courserepo.findAll();
	}

	public Course getCourse(Long id) {
		// TODO Auto-generated method stub
		return courserepo.findOne(id);
	}

	public Course addCourse(Course course) {
		// TODO Auto-generated method stub
		return courserepo.save(course);
	}

	public Course updateCourse(Long id, Course course) {
		// TODO Auto-generated method stub
		Course mycourse = courserepo.findOne(id);
		courserepo.save(mycourse);
		return mycourse;
	}

	public void deleteCourse(Long id) {
		// TODO Auto-generated method stub
		courserepo.delete(id);
	}

}
