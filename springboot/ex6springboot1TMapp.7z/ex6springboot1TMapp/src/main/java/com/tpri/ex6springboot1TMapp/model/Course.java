package com.tpri.ex6springboot1TMapp.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="course")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description="Course POJO information")
@ToString
public class Course implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="Course Code")
	private Long id;
	@Column
	@ApiModelProperty(notes="Course Name")
	private String courseName;
	@Column
	@ApiModelProperty(notes="Course Instructor Name")
	private String courseInstructor;
	
	@OneToMany(mappedBy="course",cascade=CascadeType.ALL)
	private Set<Student> students;
	

}
