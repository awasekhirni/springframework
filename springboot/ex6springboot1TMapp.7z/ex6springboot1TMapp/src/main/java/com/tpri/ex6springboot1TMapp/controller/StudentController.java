package com.tpri.ex6springboot1TMapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex6springboot1TMapp.model.Student;
import com.tpri.ex6springboot1TMapp.service.StudentServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/students")
public class StudentController {
	
	@Autowired
	StudentServiceImpl studentservice;
	
	@PostMapping(value="/create")
	@ApiOperation(value="Add new Student", notes="Add new Student", response=Student.class)
	public Student createStudent(@RequestBody Student Student) {
		return studentservice.addStudent(Student);
	}
	
	
	
	@GetMapping(value="/Student/{id}")
	@ApiOperation(value="get Student by Id", notes="Get Student by Id, takes Long", response=Student.class)
	public Student getStudentById(@PathVariable("id") Long id) {
		return studentservice.getStudent(id);
	}
	
	@GetMapping(value="/all")
	@ApiOperation(value="get all Students ", notes="Get all Student  takes Long", response=Student.class)
	public Iterable<Student> getAllStudents(){
		return studentservice.getAllStudents();
	}
	
	
	@DeleteMapping(value="/Student/{id}")
	@ApiOperation(value="delete Student by Id", notes="delete Student by Id, takes Long", response=Student.class)
	public void deleteStudent(@PathVariable("id") Long id) {
		studentservice.deleteStudent(id);
	}

	
	
	@PutMapping(value="/Student/{id}")
	@ApiOperation(value="update Student by Id", notes="update Student by Id, takes Long", response=Student.class)
	public Student updateUser(@PathVariable("id") Long id,@RequestBody Student Student) {
		Student myStudent = studentservice.getStudent(id);
		studentservice.updateStudent(id, myStudent);
		return myStudent;
		
		
	}

}
