package com.tpri.ex6springboot1TMapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@ApiModel(description="Student Model Object")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Student implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="Student Identification")
	private Long id;
	@Column
	@ApiModelProperty(notes="Student Full Name")
	private String name;
	@Column
	@ApiModelProperty(notes="Student Email address")
	private String email;
	
	@ManyToOne
	@JoinColumn(name="course_id")
	private Course course;
	
}
