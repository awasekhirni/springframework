package com.tpri.ex6springboot1TMapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.tpri.ex6springboot1TMapp.model.Course;
import com.tpri.ex6springboot1TMapp.service.CourseServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

	@Autowired
	CourseServiceImpl courseservice;
	
	@PostMapping(value="/create")
	@ApiOperation(value="Add new course", notes="Add new course", response=Course.class)
	public Course createCourse(@RequestBody Course course) {
		return courseservice.addCourse(course);
	}
	
	
	
	@GetMapping(value="/course/{id}")
	@ApiOperation(value="get Course by Id", notes="Get course by Id, takes Long", response=Course.class)
	public Course getCourseById(@PathVariable("id") Long id) {
		return courseservice.getCourse(id);
	}
	
	@GetMapping(value="/all")
	@ApiOperation(value="get all Courses ", notes="Get all course  takes Long", response=Course.class)
	public Iterable<Course> getAllCourses(){
		return courseservice.getAllCourses();
	}
	
	
	@DeleteMapping(value="/course/{id}")
	@ApiOperation(value="delete Course by Id", notes="delete course by Id, takes Long", response=Course.class)
	public void deleteCourse(@PathVariable("id") Long id) {
		courseservice.deleteCourse(id);
	}

	
	
	@PutMapping(value="/course/{id}")
	@ApiOperation(value="update Course by Id", notes="update course by Id, takes Long", response=Course.class)
	public Course updateUser(@PathVariable("id") Long id,@RequestBody Course course) {
		Course mycourse = courseservice.getCourse(id);
		courseservice.updateCourse(id, mycourse);
		return mycourse;
		
		
	}
	
	
}
