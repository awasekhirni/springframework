package com.tpri.ex6springboot1TMapp.service;

import com.tpri.ex6springboot1TMapp.model.Course;

public interface ICourseService {

	public Iterable<Course> getAllCourses();
	public Course getCourse(Long id);
	public Course addCourse(Course course);
	public Course updateCourse(Long id, Course course);
	public void deleteCourse(Long id);
	
	
}
