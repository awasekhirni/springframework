package com.tpri.ex6springboot1TMapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex6springboot1TMapp.model.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student,Long>{

}
