package com.tpri.ex6springboot1TMapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tpri.ex6springboot1TMapp.model.Student;
import com.tpri.ex6springboot1TMapp.repository.StudentRepository;

@Service
public class StudentServiceImpl implements IStudentService{
	
	@Autowired
	private StudentRepository studentrepo;

	public Iterable<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentrepo.findAll();
	}

	public Student getStudent(Long id) {
		// TODO Auto-generated method stub
		return studentrepo.findOne(id);
	}

	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentrepo.save(student);
	}

	public Student updateStudent(Long id, Student student) {
		// TODO Auto-generated method stub
		Student mystudent = studentrepo.findOne(id);
		studentrepo.save(mystudent);
		return mystudent;
		
	}

	public void deleteStudent(Long id) {
		// TODO Auto-generated method stub
		studentrepo.delete(id);
	}

}
