package com.tpri.ex3springbootapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.tpri.ex3springbootapp.dao.ProductRepository;
import com.tpri.ex3springbootapp.model.Product;

@Service
public class ProductService {
	@Autowired
	private ProductRepository pr;
	@Bean
	InitializingBean sendDatabase() {
		return () -> {
			pr.save(new Product("1", "ATH M50X Headphone", "http://i.ebayimg.com/00/s/MTAwMFgxMDAw/z/YFYAAOSwPhdVOjdQ/$_12.JPG",
					"ATH-M50xDG Limited Edition Professional Studio Monitor Headphones - .",
					"Electronics", "8631", "3", "0", "Mumbai", "#6B5419",
					"http://www.ebay.in/sch/i.html?_nkw=m50x&_sop=16"));
			
			pr.save(new Product("2", "Sony PS4 500GB", "http://i.ebayimg.com/00/s/NDcyWDYxOA==/z/wM4AAOSwZjJVAEUf/$_12.JPG",
					"The PlayStation4 system opens the door to an incredible journey through immersive new gaming worlds ",
					"Electronics", "34463", "7", "0", "Delhi", "#302E29",
					"http://www.ebay.in/sch/i.html?_nkw=ps4&_sop=16"));
			pr.save(new Product("3", "Handy Chopper (Slicer)",
					"http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/bPAAAOSwBahU7V4G/$_12.JPG",
					"Nicer Dicer With Plus you have a kitchen helper",
					"Household", "549", "10", "0", "Chennai", "#B6E314",
					"http://www.ebay.in/sch/i.html?_nkw=NICER+DICER+PLUS+CHOPPER&_sop=16"));
			};
		}

	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<>();
		pr.findAll().forEach(products::add);
		return products;
	}

	public Product getProduct(String id) {
		return pr.findOne(id);
	}

	public void addProduct(Product product) {
		pr.save(product);
	}

	public void updateProduct(String id, Product product) {
		// TODO Auto-generated method stub
		pr.save(product);

	}

	public void deleteProduct(String id) {
		// TODO Auto-generated method stub
		pr.delete(id);
	}
}
