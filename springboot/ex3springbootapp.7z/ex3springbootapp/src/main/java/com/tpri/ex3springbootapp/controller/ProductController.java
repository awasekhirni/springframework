package com.tpri.ex3springbootapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex3springbootapp.model.Product;
import com.tpri.ex3springbootapp.service.ProductService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api")
public class ProductController {
	@Autowired
	private ProductService ps;
	
	@GetMapping("/products")
	@ApiOperation(value="Find all products ", notes="provides a list of products", response=Product.class)
	public List<Product> getAllProducts(){
		return ps.getAllProducts();
	}
	@GetMapping("/products/{id}")
	@ApiOperation(value="Find a single product byId ", notes="find product by Id", response=Product.class)
	public Product getProduct(@PathVariable String id) {
		return ps.getProduct(id);
	}
	@PostMapping(value="/products/add")
	@ApiOperation(value="Add a new product ", notes="add a new product", response=Product.class)
	public void addProduct(@RequestBody Product product) {
		ps.addProduct(product);
	}
	@DeleteMapping(value="product/delete/{id}")
	@ApiOperation(value="Delete a Product ", notes="Delete a product", response=Product.class)
	public void deleteProduct(@PathVariable String id) {
		ps.deleteProduct(id);
		System.out.println("the produc t"+id+" has been deleted");
	}
	
	@PutMapping(value="/products/update/{id}")
	@ApiOperation(value="Update a product", notes="Update a product", response=Product.class)
	public void updateProduct(@RequestBody Product product,@PathVariable String id) {
		ps.updateProduct(id,product);
	}
}

