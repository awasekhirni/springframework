package com.tpri.ex3springbootapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

//https://github.com/awasekhirni/jsondata/blob/master/ebayproducts.json

@Entity
@ApiModel(description="Product Pojo- reflecting the Ebay Product properties")
public class Product {
	@Id
	@ApiModelProperty(notes="Unique identifier for ebay product")
	private String id;
	@Column
	@ApiModelProperty(notes="Full product name")
	private String name;
	@Column
	@ApiModelProperty(notes="Product URL, Currently we only support jpeg format")
	private String image;
	@Column
	@ApiModelProperty(notes="Product description, does not exceed 1000 words")
	private String description;
	@Column
	@ApiModelProperty(notes="Product category information: electronics, electricals, clothing, mens wear, womens wear, children,household items, household hardware, kitchenware, car accessories, automobile parts")
	private String category;
	@Column
	@ApiModelProperty(notes="Support for pricing in USD, INR, CHF, POUND")
	private String price;
	@Column
	@ApiModelProperty(notes="metric quantity")
	private String quantity;
	@Column
	@ApiModelProperty(notes="3 shipping modes supported, regular, expedited, next business day shipping")
	private String shipping;
	@Column
	@ApiModelProperty(notes="refers to the city from which the product is shipped from")
	private String location;
	@Column
	@ApiModelProperty(notes="color code")
	private String color;
	@Column
	@ApiModelProperty(notes="published URL for additional information and T&C")
	private String link;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getShipping() {
		return shipping;
	}
	public void setShipping(String shipping) {
		this.shipping = shipping;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	public Product() {}
	
	public Product(String id, String name, String image, String description, String category, String price,
			String quantity, String shipping, String location, String color, String link) {
		super();
		this.id = id;
		this.name = name;
		this.image = image;
		this.description = description;
		this.category = category;
		this.price = price;
		this.quantity = quantity;
		this.shipping = shipping;
		this.location = location;
		this.color = color;
		this.link = link;
	}
	
	
	
	
	

}
