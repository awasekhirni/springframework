package com.tpri.ex3springbootapp;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.tpri.ex3springbootapp.model.Product;

@SpringBootApplication
public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(AppMain.class, args);
	}

}
