package com.tpri.ex9springbootthyme.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tpri.ex9springbootthyme.model.Product;
import com.tpri.ex9springbootthyme.service.FileUploadServiceImpl;
import com.tpri.ex9springbootthyme.service.ProductServiceImpl;

@Controller
public class ProductController {
	
	@Autowired
	private ProductServiceImpl psi;
	
	@Autowired
	private FileUploadServiceImpl fus;
	
	@RequestMapping(path = "/") // Use 'path'
	public String loadMainWeb() {
	    return "index";
	}
	
	@GetMapping("/products")
	public String productList(Model model) {
		List<Product> products=psi.getAllProducts();
		model.addAttribute("products", products);
		return "products";
	}
	
	
	@GetMapping("/product/{id}")
	public String findProductById(@PathVariable("id")Long id, Model model) {
		Product myproduct = psi.getProduct(id);
		model.addAttribute("myproduct", myproduct);
		return "product/myproduct";
	}
	

}
