package com.tpri.ex9springbootthyme.service;

import java.util.List;

import com.tpri.ex9springbootthyme.model.Product;

public interface IProductService {
	public List<Product> getAllProducts();
	public Product getProduct(Long id);
	public void addProduct(Product product);
	public void updateProduct(Long id, Product product);
	public void deleteProduct(Long id);
}
