package com.tpri.ex9springbootthyme.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex9springbootthyme.model.Product;

@Repository
public interface IProductRepository extends PagingAndSortingRepository<Product,Long> {

}
