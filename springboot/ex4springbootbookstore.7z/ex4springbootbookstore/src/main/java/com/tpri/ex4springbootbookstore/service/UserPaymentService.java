package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.UserPayment;

public interface UserPaymentService {
	UserPayment findById(Long id);

	void removeById(Long id);
}
