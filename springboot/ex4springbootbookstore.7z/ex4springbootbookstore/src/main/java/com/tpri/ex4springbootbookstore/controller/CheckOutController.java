package com.tpri.ex4springbootbookstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/api")
public class CheckOutController {
	
	//@ApiOperation(value="Finds Todos by Id", notes="Provide an id to look up specific todo task from the todos list", response=Todo.class)
	//GetMapping("/")
	// controller action methods

}
