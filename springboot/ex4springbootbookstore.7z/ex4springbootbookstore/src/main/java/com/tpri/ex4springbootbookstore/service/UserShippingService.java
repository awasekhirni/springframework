package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.UserShipping;

public interface UserShippingService {
	UserShipping findById(Long id);
	
	void removeById(Long id);
}
