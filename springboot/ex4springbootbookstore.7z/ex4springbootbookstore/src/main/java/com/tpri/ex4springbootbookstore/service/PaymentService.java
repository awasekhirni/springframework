package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.Payment;
import com.tpri.ex4springbootbookstore.model.UserPayment;

public interface PaymentService {
	Payment setByUserPayment(UserPayment userPayment, Payment payment);
}
