package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.BillingAddress;
import com.tpri.ex4springbootbookstore.model.UserBilling;

public interface BillingAddressService {
	BillingAddress setByUserBilling(UserBilling userBilling, BillingAddress billingAddress);
}
