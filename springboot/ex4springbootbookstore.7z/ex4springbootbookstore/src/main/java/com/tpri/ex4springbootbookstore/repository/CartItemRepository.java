package com.tpri.ex4springbootbookstore.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.tpri.ex4springbootbookstore.model.CartItem;
import com.tpri.ex4springbootbookstore.model.Order;
import com.tpri.ex4springbootbookstore.model.ShoppingCart;

@Transactional
public interface CartItemRepository extends CrudRepository<CartItem, Long> {

	List<CartItem> findByShoppingCart(ShoppingCart shoppingCart);

	List<CartItem> findByOrder(Order order);
}