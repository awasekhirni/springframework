package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.ShoppingCart;

public interface ShoppingCartService {
	ShoppingCart updateShoppingCart(ShoppingCart shoppingCart);

	void clearShoppingCart(ShoppingCart shoppingCart);
}
