package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.BillingAddress;
import com.tpri.ex4springbootbookstore.model.Order;
import com.tpri.ex4springbootbookstore.model.Payment;
import com.tpri.ex4springbootbookstore.model.ShippingAddress;
import com.tpri.ex4springbootbookstore.model.ShoppingCart;
import com.tpri.ex4springbootbookstore.model.User;

public interface OrderService {
	Order createOrder(ShoppingCart shoppingCart,
			ShippingAddress shippingAddress,
			BillingAddress billingAddress,
			Payment payment,
			String shippingMethod,
			User user);
	
	Order findOne(Long id);
}
