package com.tpri.ex4springbootbookstore.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex4springbootbookstore.model.Order;

@Repository
public interface OrderRepository extends CrudRepository<Order,Long> {

}
