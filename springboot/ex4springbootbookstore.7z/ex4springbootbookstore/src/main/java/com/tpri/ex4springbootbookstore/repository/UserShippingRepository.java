package com.tpri.ex4springbootbookstore.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex4springbootbookstore.model.UserShipping;

@Repository
public interface UserShippingRepository extends CrudRepository<UserShipping,Long> {

}
