package com.tpri.ex4springbootbookstore.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex4springbootbookstore.model.BookToCartItem;
import com.tpri.ex4springbootbookstore.model.CartItem;

@Repository
public interface BookToCartItemRepository extends CrudRepository<BookToCartItem,Long> {
	void deleteByCartItem(CartItem cartItem);
}
