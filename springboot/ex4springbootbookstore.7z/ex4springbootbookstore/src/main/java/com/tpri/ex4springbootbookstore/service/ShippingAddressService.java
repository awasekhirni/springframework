package com.tpri.ex4springbootbookstore.service;

import com.tpri.ex4springbootbookstore.model.ShippingAddress;
import com.tpri.ex4springbootbookstore.model.UserShipping;

public interface ShippingAddressService {
	ShippingAddress setByUserShipping(UserShipping userShipping, ShippingAddress shippingAddress);

}
