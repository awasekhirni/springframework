/**
 * 
 */
package com.tpri.ex8springboothotelreservations;

/**
 * @author Awase Khirni Syed
 *
 */
public class EightMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
