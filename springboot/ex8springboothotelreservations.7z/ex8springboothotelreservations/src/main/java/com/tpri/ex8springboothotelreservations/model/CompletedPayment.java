package com.tpri.ex8springboothotelreservations.model;

import java.time.YearMonth;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;

@Entity
@ApiModel(description="")
public class CompletedPayment {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(nullable=false)
	private UUID transactionId=UUID.randomUUID();
	
	@Column(nullable=false)
	@Enumerated(EnumType.STRING)
	private CreditCardType creditCardType;
	
	@Column(nullable=false)
	private String last4CreditCardDigits;
	
	@Column(nullable=false)
	private String cvv;
	
	@Column(nullable=false)
	private YearMonth cardExpiry;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UUID getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(UUID transactionId) {
		this.transactionId = transactionId;
	}

	public CreditCardType getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(CreditCardType creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getLast4CreditCardDigits() {
		return last4CreditCardDigits;
	}

	public void setLast4CreditCardDigits(String last4CreditCardDigits) {
		this.last4CreditCardDigits = last4CreditCardDigits;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public YearMonth getCardExpiry() {
		return cardExpiry;
	}

	public void setCardExpiry(YearMonth cardExpiry) {
		this.cardExpiry = cardExpiry;
	}

	@Override
	public String toString() {
		return "CompletedPayment [id=" + id + ", transactionId=" + transactionId + ", last4CreditCardDigits="
				+ last4CreditCardDigits + ", cvv=" + cvv + ", cardExpiry=" + cardExpiry + "]";
	}
	
	public CompletedPayment() {}

	public CompletedPayment(Long id, UUID transactionId, String last4CreditCardDigits, String cvv,
			YearMonth cardExpiry) {
		super();
		this.id = id;
		this.transactionId = transactionId;
		this.last4CreditCardDigits = last4CreditCardDigits;
		this.cvv = cvv;
		this.cardExpiry = cardExpiry;
	}

	public CompletedPayment(CreditCardType creditCardType, String last4CardDigits, String cvv, YearMonth cardExpiry, String last4CreditCardDigits) {
		// TODO Auto-generated constructor stub
		super();
		this.creditCardType=creditCardType;
		this.last4CreditCardDigits=last4CreditCardDigits;
		this.cvv=cvv;
		this.cardExpiry=cardExpiry;
		this.last4CreditCardDigits=last4CreditCardDigits;
	}
	
	
	
	
}
