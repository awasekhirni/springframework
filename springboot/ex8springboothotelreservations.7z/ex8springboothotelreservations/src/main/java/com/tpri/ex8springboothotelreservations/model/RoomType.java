package com.tpri.ex8springboothotelreservations.model;

public enum RoomType {
	Economy,
	Business,
	Luxury,
	Presidential
	}
