package com.tpri.ex8springboothotelreservations.service;

public interface IHotelService {

}
