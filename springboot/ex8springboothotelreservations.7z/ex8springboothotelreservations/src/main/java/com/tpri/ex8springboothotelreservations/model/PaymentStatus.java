package com.tpri.ex8springboothotelreservations.model;

public enum PaymentStatus {
   Accepted, Declined
}
