package com.tpri.ex8springboothotelreservations.service;

import org.springframework.stereotype.Service;

@Service
public class ExtraServiceImpl implements IExtraService{

}
