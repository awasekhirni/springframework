package com.tpri.ex8springboothotelreservations.model;

public enum DietaryRequirement {
	Vegan("Vegan"),
	Vegetarian("Vegetarian"),
	NonVegetarian("Non-Vegetarian"),
	MuslimDiet("Halal Diet"),
	KocherDiet("Jewish Diet"),
	GlutenIntolerant("Gluten Intolerant"),
	LactoseIntolerant("Lactose Intolerant");
	
	private String description;

	private DietaryRequirement(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
