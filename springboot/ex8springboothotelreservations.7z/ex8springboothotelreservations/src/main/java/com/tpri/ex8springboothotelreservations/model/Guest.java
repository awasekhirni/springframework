package com.tpri.ex8springboothotelreservations.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Guest {

	@Transient
	private UUID tempId=UUID.randomUUID();
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Size(min=2, max=200)
	@NotNull(message="required")
	@Column(nullable=false)
	private String firstName;
	
	@Size(min=2, max=200)
	@NotNull(message="required")
	@Column(nullable=false)
	private String lastName;
	
	private boolean child;

	public UUID getTempId() {
		return tempId;
	}

	public void setTempId(UUID tempId) {
		this.tempId = tempId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public boolean isChild() {
		return child;
	}

	public void setChild(boolean child) {
		this.child = child;
	}

	@Override
	public String toString() {
		return "Guest [tempId=" + tempId + ", id=" + id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", child=" + child + "]";
	}
	
	public Guest() {
		
	}

	public Guest(UUID tempId, Long id, String firstName, String lastName, boolean child) {
		super();
		this.tempId = tempId;
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.child = child;
	}
	
	
	
	
	
	
}
