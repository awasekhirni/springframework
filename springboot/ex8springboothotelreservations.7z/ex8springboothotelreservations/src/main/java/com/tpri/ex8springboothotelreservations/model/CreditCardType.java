package com.tpri.ex8springboothotelreservations.model;

public enum CreditCardType {
	MasterCard("MasterCard"),
	Visa("Visa");
	
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	private CreditCardType(String description) {
		this.description = description;
	}
	
	
	
	
}
