package com.tpri.ex8springboothotelreservations.model;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;

@Entity
@ApiModel(description="")
public class Hotel {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(nullable=false)
	private String name;
	
	@Column(nullable=false)
	private int stars;
	
	@Column(nullable=false)
	private String email;
	
	@OneToMany(mappedBy="hotel",cascade=CascadeType.ALL)
	@JsonIgnore
	private Set<Room> rooms;
	
	@Column(nullable=false)
	private LocalTime earliestCheckInTime;
	
	@Column(nullable=false)
	private LocalTime latestCheckInTime;
	
	@Column(nullable=false)
	private LocalTime standardCheckOutTime;
	
	@Column(nullable=false)
	private LocalTime latestCheckoutTime;
	
	@Column(nullable=false)
	private BigDecimal lateCheckoutFee;
	
	
	public void addRoom(Room room) {
		rooms.add(room);
		room.setHotel(this);
	}
	
	public List<LocalTime> allowableCheckInTimes(){
		long span = ChronoUnit.HOURS.between(earliestCheckInTime, latestCheckInTime) + 1;

        return Stream.iterate(earliestCheckInTime, time -> time.plusHours(1))
                .limit(span)
                .collect(Collectors.toList());
	}

	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", stars=" + stars + ", email=" + email + ", earliestCheckInTime="
				+ earliestCheckInTime + ", latestCheckInTime=" + latestCheckInTime + ", standardCheckOutTime="
				+ standardCheckOutTime + ", latestCheckoutTime=" + latestCheckoutTime + ", lateCheckoutFee="
				+ lateCheckoutFee + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStars() {
		return stars;
	}

	public void setStars(int stars) {
		this.stars = stars;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<Room> getRooms() {
		return rooms;
	}

	public void setRooms(Set<Room> rooms) {
		this.rooms = rooms;
	}

	public LocalTime getEarliestCheckInTime() {
		return earliestCheckInTime;
	}

	public void setEarliestCheckInTime(LocalTime earliestCheckInTime) {
		this.earliestCheckInTime = earliestCheckInTime;
	}

	public LocalTime getLatestCheckInTime() {
		return latestCheckInTime;
	}

	public void setLatestCheckInTime(LocalTime latestCheckInTime) {
		this.latestCheckInTime = latestCheckInTime;
	}

	public LocalTime getStandardCheckOutTime() {
		return standardCheckOutTime;
	}

	public void setStandardCheckOutTime(LocalTime standardCheckOutTime) {
		this.standardCheckOutTime = standardCheckOutTime;
	}

	public LocalTime getLatestCheckoutTime() {
		return latestCheckoutTime;
	}

	public void setLatestCheckoutTime(LocalTime latestCheckoutTime) {
		this.latestCheckoutTime = latestCheckoutTime;
	}

	public BigDecimal getLateCheckoutFee() {
		return lateCheckoutFee;
	}

	public void setLateCheckoutFee(BigDecimal lateCheckoutFee) {
		this.lateCheckoutFee = lateCheckoutFee;
	}

	public Hotel(Long id, String name, int stars, String email, Set<Room> rooms, LocalTime earliestCheckInTime,
			LocalTime latestCheckInTime, LocalTime standardCheckOutTime, LocalTime latestCheckoutTime,
			BigDecimal lateCheckoutFee) {
		super();
		this.id = id;
		this.name = name;
		this.stars = stars;
		this.email = email;
		this.rooms = rooms;
		this.earliestCheckInTime = earliestCheckInTime;
		this.latestCheckInTime = latestCheckInTime;
		this.standardCheckOutTime = standardCheckOutTime;
		this.latestCheckoutTime = latestCheckoutTime;
		this.lateCheckoutFee = lateCheckoutFee;
	}
	
	
	
	
}
