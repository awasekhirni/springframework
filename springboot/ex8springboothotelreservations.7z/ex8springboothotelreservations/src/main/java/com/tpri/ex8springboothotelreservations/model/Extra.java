package com.tpri.ex8springboothotelreservations.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Extra {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(nullable=false)
	private String description;
	
	@Column(nullable=false)
	private BigDecimal perNightPrice;
	
	@Column(nullable=false)
	@Enumerated(EnumType.STRING)
	private Type type;
	
	@Column(nullable=false)
	@Enumerated(EnumType.STRING)
	private Category category;
	
	public enum Type{
		Basic, Silver, Gold, Platnium;
	}
	
	public enum Category{
		General, Food, Mediterranean, Oriental, Arabic
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPerNightPrice() {
		return perNightPrice;
	}

	public void setPerNightPrice(BigDecimal perNightPrice) {
		this.perNightPrice = perNightPrice;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Extra [id=" + id + ", description=" + description + ", perNightPrice=" + perNightPrice + ", type="
				+ type + ", category=" + category + "]";
	}
	
	public Extra() {}

	public Extra(Long id, String description, BigDecimal perNightPrice, Type type, Category category) {
		super();
		this.id = id;
		this.description = description;
		this.perNightPrice = perNightPrice;
		this.type = type;
		this.category = category;
	}
	
	
}
