package com.tpri.ex8springboothotelreservations.model;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import io.swagger.annotations.ApiModel;

@Entity
@ApiModel(description = "")
public class PendingPayment {

	@NotNull(message = "required")
	private CreditCardType creditCardType;

	@Pattern(regexp = "[0-9]{10}", message = "10 digit number expected")
	@NotNull
	private String creditCardNumber;

	@Pattern(regexp = "[0-9]{3}", message = "3 digit number expected")
	@NotNull
	private String cvv;

	@NotEmpty
	private String cardHolderName;

	@NotNull(message = "required")
	private Year cardExpiryYear;

	@NotNull(message = "required")
	private Month cardExpiryMonth;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdTime;
	
	public List<Year> validExpiryYears(){
		Year currentYearNow = Year.of(createdTime.getYear());

        return IntStream.rangeClosed(0, 10)
                .mapToObj(currentYearNow::plusYears)
                .collect(Collectors.toList());
	}
	
	
	public List<Month> validExpiryMonths(){
		Month currentMonthNow = createdTime.getMonth();
        return Arrays.stream(Month.values())
                .filter(month -> month.getValue() >= currentMonthNow.getValue())
                .collect(Collectors.toList());
	}
	
	public String last4CardDigits() {
		return creditCardNumber.substring(creditCardNumber.length() - 4);
	}
	
	public CompletedPayment toCompletedPayment() {
        return new CompletedPayment(creditCardType, last4CardDigits(), cvv, getCardExpiry(), cardHolderName);
    }
	
	private YearMonth getCardExpiry() {
		// TODO Auto-generated method stub
		return YearMonth.of(cardExpiryYear.getValue(), cardExpiryMonth.getValue());
	}


	public PendingPayment() {}

	public PendingPayment(CreditCardType creditCardType, String creditCardNumber, String cvv, String cardHolderName,
			Year cardExpiryYear, Month cardExpiryMonth, LocalDateTime createdTime) {
		super();
		this.creditCardType = creditCardType;
		this.creditCardNumber = creditCardNumber;
		this.cvv = cvv;
		this.cardHolderName = cardHolderName;
		this.cardExpiryYear = cardExpiryYear;
		this.cardExpiryMonth = cardExpiryMonth;
		this.createdTime = createdTime;
	}
	
	

}
