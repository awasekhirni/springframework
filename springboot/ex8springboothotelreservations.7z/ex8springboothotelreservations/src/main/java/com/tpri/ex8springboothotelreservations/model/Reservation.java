package com.tpri.ex8springboothotelreservations.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.Valid;

@Entity
public class Reservation {

	public static final double TAX_AMOUNT=0.18;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private UUID reservationId=UUID.randomUUID();
	
	@OneToOne(mappedBy="reservation")
	private Room room;
	
	
	@ManyToMany(cascade= {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinTable(
            name = "reservation_guests",
            joinColumns = @JoinColumn(name = "reservation_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "guest_id", referencedColumnName = "id")
    )
    private Set<Guest> guests = new HashSet<>();
	
	@Embedded
	@Valid
	private ReservationDates dates = new ReservationDates();


	@ManyToMany
    @JoinTable(
            name = "reservation_general_extras",
            joinColumns = @JoinColumn(name = "reservation_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "general_extra_id", referencedColumnName = "id")
    )
    private Set<Extra> generalExtras = new HashSet<>();

    
    @OneToMany(cascade = CascadeType.ALL)
    private List<MealPlan> mealPlans = new ArrayList<>();

    @OneToOne(cascade = CascadeType.ALL)
    private CompletedPayment completedPayment;

    @Column(nullable = false)
    private LocalDateTime createdTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UUID getReservationId() {
		return reservationId;
	}

	public void setReservationId(UUID reservationId) {
		this.reservationId = reservationId;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Set<Guest> getGuests() {
		return guests;
	}

	public void setGuests(Set<Guest> guests) {
		this.guests = guests;
	}

	public ReservationDates getDates() {
		return dates;
	}

	public void setDates(ReservationDates dates) {
		this.dates = dates;
	}

	public Set<Extra> getGeneralExtras() {
		return generalExtras;
	}

	public void setGeneralExtras(Set<Extra> generalExtras) {
		this.generalExtras = generalExtras;
	}

	public List<MealPlan> getMealPlans() {
		return mealPlans;
	}

	public void setMealPlans(List<MealPlan> mealPlans) {
		this.mealPlans = mealPlans;
	}

	public CompletedPayment getCompletedPayment() {
		return completedPayment;
	}

	public void setCompletedPayment(CompletedPayment completedPayment) {
		this.completedPayment = completedPayment;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public static double getTaxAmount() {
		return TAX_AMOUNT;
	}

	@Override
	public String toString() {
		return "Reservation [id=" + id + ", reservationId=" + reservationId + ", room=" + room + ", createdTime="
				+ createdTime + "]";
	}

	public Reservation(Long id, UUID reservationId, Room room, Set<Guest> guests, ReservationDates dates,
			Set<Extra> generalExtras, List<MealPlan> mealPlans, CompletedPayment completedPayment,
			LocalDateTime createdTime) {
		super();
		this.id = id;
		this.reservationId = reservationId;
		this.room = room;
		this.guests = guests;
		this.dates = dates;
		this.generalExtras = generalExtras;
		this.mealPlans = mealPlans;
		this.completedPayment = completedPayment;
		this.createdTime = createdTime;
	}
    
	
	
    






}
