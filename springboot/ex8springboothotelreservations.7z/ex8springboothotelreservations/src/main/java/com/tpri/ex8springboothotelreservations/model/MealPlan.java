package com.tpri.ex8springboothotelreservations.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import io.swagger.annotations.ApiModel;

@Entity
@ApiModel(description="")
public class MealPlan {

	public static final double CHILD_DISCOUNT_PERCENT=0.75;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private UUID mealPlanId=UUID.randomUUID();
	
	@OneToOne
	private Guest Guest;
	
	@OneToOne
	private Reservation reservation;
	
	@ManyToMany 
	private List<Extra> foodExtras;
	
	@ElementCollection
	private List<DietaryRequirement> dietaryRequirement;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UUID getMealPlanId() {
		return mealPlanId;
	}

	public void setMealPlanId(UUID mealPlanId) {
		this.mealPlanId = mealPlanId;
	}

	public Guest getGuest() {
		return Guest;
	}

	public void setGuest(Guest guest) {
		Guest = guest;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	public List<Extra> getFoodExtras() {
		return foodExtras;
	}

	public void setFoodExtras(List<Extra> foodExtras) {
		this.foodExtras = foodExtras;
	}

	public List<DietaryRequirement> getDietaryRequirement() {
		return dietaryRequirement;
	}

	public void setDietaryRequirement(List<DietaryRequirement> dietaryRequirement) {
		this.dietaryRequirement = dietaryRequirement;
	}

	public static double getChildDiscountPercent() {
		return CHILD_DISCOUNT_PERCENT;
	}

	@Override
	public String toString() {
		return "MealPlan [id=" + id + ", mealPlanId=" + mealPlanId + ", Guest=" + Guest + ", reservation=" + reservation
				+ "]";
	}

	public MealPlan(Long id, UUID mealPlanId, com.tpri.ex8springboothotelreservations.model.Guest guest,
			Reservation reservation, List<Extra> foodExtras, List<DietaryRequirement> dietaryRequirement) {
		super();
		this.id = id;
		this.mealPlanId = mealPlanId;
		Guest = guest;
		this.reservation = reservation;
		this.foodExtras = foodExtras;
		this.dietaryRequirement = dietaryRequirement;
	}
	
	public MealPlan() {}
	
}
