package com.tpri.ex8springboothotelreservations.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/home")
public class HomeController {
	//@ApiOperation(value="",notes="",response=)
}
