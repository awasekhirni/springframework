package com.tpri.ex8springboothotelreservations.model;

public enum CustomerType {
	Regular,
	Corporate,
	Membership;
}
