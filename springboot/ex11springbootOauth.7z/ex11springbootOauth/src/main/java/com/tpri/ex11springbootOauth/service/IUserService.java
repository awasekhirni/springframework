package com.tpri.ex11springbootOauth.service;

import com.tpri.ex11springbootOauth.model.User;

public interface IUserService {
	void save(User user);
	User findByUsername(String username);

}
