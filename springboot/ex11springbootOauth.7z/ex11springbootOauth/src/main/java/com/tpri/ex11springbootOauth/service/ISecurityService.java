package com.tpri.ex11springbootOauth.service;

public interface ISecurityService {
	String findLoggedInUsername();
	void autoLogin(String username,String password);
}
