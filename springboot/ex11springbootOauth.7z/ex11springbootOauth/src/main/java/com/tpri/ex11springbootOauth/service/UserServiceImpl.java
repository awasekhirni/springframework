package com.tpri.ex11springbootOauth.service;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tpri.ex11springbootOauth.model.User;
import com.tpri.ex11springbootOauth.repository.IRoleRepository;
import com.tpri.ex11springbootOauth.repository.IUserRepository;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserRepository userRepository;
	@Autowired
	private IRoleRepository roleRepository;
	@Autowired
	private BCryptPasswordEncoder bcryptpwdEncoder;
	
	
	
	public void save(User user) {
		// TODO Auto-generated method stub
		user.setPassword(bcryptpwdEncoder.encode(user.getPassword()));
		user.setRoles(new HashSet<>(roleRepository.findAll()));
		userRepository.save(user);
	}

	public User findByUsername(String username) {
		// TODO Auto-generated method stub
		return userRepository.findByUsername(username);
	}

}
