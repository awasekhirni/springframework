package com.tpri.exspringboottemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//kickstart your spring boot application
		SpringApplication.run(AppMain.class, args);
	}

}
