package com.tpri.ex13ActuatorCustom.ep;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class MetaContributor implements InfoContributor{
	@Autowired
	private ApplicationContext context;
	
	@Override
	public void contribute(Info.Builder builder) {
        Map<String, Object> details = new HashMap<>();
        details.put("No-of-beans", context.getBeanDefinitionCount());
        details.put("currentstartupdate", context.getStartupDate());

        builder.withDetail("context", details);
    }
}
