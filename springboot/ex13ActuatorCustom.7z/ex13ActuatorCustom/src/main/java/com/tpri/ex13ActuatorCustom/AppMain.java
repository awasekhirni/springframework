/**
 * 
 */
package com.tpri.ex13ActuatorCustom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Awase Khirni Syed
 *
 */
@SpringBootApplication
public class AppMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(AppMain.class, args);
	}

}
