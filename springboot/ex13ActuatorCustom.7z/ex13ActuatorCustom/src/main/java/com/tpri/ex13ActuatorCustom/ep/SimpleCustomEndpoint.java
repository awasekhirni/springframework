package com.tpri.ex13ActuatorCustom.ep;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

@Component
public class SimpleCustomEndpoint implements Endpoint {

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return "custom-endpoint";
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isSensitive() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object invoke() {
		// TODO Auto-generated method stub
		List<String> messages = new ArrayList<String>();
        messages.add("Syed's Custom EndPoint List Demo1");
        messages.add("Syed's Custom EndPoint List Demo2");
        return messages;
	}

}
