package com.tpri.ex13ActuatorCustom.controller;

public class UserController {

}
