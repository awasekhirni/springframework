package com.tpri.ex13ActuatorCustom.repository;

public interface IUserRepository {

}
