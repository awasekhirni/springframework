package com.tpri.ex13ActuatorCustom.ep;
import java.util.List;

import org.springframework.boot.actuate.endpoint.AbstractEndpoint;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

//http://localhost:8080/tprimetrics
@Component
public class CustomListEndPoints extends AbstractEndpoint<List<Endpoint>> {

	private List<Endpoint> tpriendpoints;
	
	public CustomListEndPoints(List<Endpoint> endpoints) {
        super("showendpoints");
        this.tpriendpoints = endpoints;
    }
	
	@Override
	public List<Endpoint> invoke() {
		// TODO Auto-generated method stub
		return this.tpriendpoints;
	}

}
