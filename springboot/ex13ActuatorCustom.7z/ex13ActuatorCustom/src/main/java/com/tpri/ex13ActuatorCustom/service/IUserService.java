package com.tpri.ex13ActuatorCustom.service;

public interface IUserService {

}
