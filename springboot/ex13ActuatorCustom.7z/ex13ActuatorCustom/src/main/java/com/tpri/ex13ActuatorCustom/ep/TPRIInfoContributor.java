package com.tpri.ex13ActuatorCustom.ep;

import java.util.Collections;

import org.springframework.boot.actuate.info.Info.Builder;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;

//localhost:8080/info
@Component
public class TPRIInfoContributor implements InfoContributor{

	@Override
	public void contribute(Builder builder) {
		// TODO Auto-generated method stub
		builder.withDetail("sycliq", Collections.singletonMap("sycliqprime", "IOTplatform with 16 environmental and operation parameters"));
	}
	
}
