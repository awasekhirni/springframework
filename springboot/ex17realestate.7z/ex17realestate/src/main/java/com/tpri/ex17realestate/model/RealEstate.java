package com.tpri.ex17realestate.model;

public class RealEstate {

}
