package com.tpri.ex17realestate.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Property implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2279952320557706510L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private Integer propertyId;
	
	private String propertyDesc;
	
	private BigDecimal propertyPrice;
	
	private String addressInfo;
	
	@Column(nullable=false)
	private String propertyImage;
	
	private Double totalArea;
	
	private Integer bedrooms;
	
	private Integer bathrooms;
	
	private Integer garages;
	
	@ManyToOne
	@JoinColumn(name="propertyTypeId")
	private PropertyType propertyType;
	
	@ManyToOne
	@JoinColumn(name="stateId")
	private State state;

	public Property() {}
	
	public Property(Integer propertyId, String propertyDesc, BigDecimal propertyPrice, String addressInfo,
			String propertyImage, Double totalArea, Integer bedrooms, Integer bathrooms, Integer garages,
			PropertyType propertyType, State state) {
		super();
		this.propertyId = propertyId;
		this.propertyDesc = propertyDesc;
		this.propertyPrice = propertyPrice;
		this.addressInfo = addressInfo;
		this.propertyImage = propertyImage;
		this.totalArea = totalArea;
		this.bedrooms = bedrooms;
		this.bathrooms = bathrooms;
		this.garages = garages;
		this.propertyType = propertyType;
		this.state = state;
	}

	public Integer getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyDesc() {
		return propertyDesc;
	}

	public void setPropertyDesc(String propertyDesc) {
		this.propertyDesc = propertyDesc;
	}

	public BigDecimal getPropertyPrice() {
		return propertyPrice;
	}

	public void setPropertyPrice(BigDecimal propertyPrice) {
		this.propertyPrice = propertyPrice;
	}

	public String getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(String addressInfo) {
		this.addressInfo = addressInfo;
	}

	public String getPropertyImage() {
		return propertyImage;
	}

	public void setPropertyImage(String propertyImage) {
		this.propertyImage = propertyImage;
	}

	public Double getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(Double totalArea) {
		this.totalArea = totalArea;
	}

	public Integer getBedrooms() {
		return bedrooms;
	}

	public void setBedrooms(Integer bedrooms) {
		this.bedrooms = bedrooms;
	}

	public Integer getBathrooms() {
		return bathrooms;
	}

	public void setBathrooms(Integer bathrooms) {
		this.bathrooms = bathrooms;
	}

	public Integer getGarages() {
		return garages;
	}

	public void setGarages(Integer garages) {
		this.garages = garages;
	}

	public PropertyType getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(PropertyType propertyType) {
		this.propertyType = propertyType;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}
	
	
	
	
	
	
}
