package com.tpri.ex17realestate.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Client implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8639255642888572730L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private Integer clientId;
	
	@Column(nullable=false)
	private String clientName;
	@Column(nullable=false)
	private String cpf;
	@Column(nullable=false)
	private String clientEmail;
	@Column(nullable=false)
	private String clientPhone;
	@Column(nullable=false)
	private String clientMobile;
	@Column(nullable=false)
	private BigDecimal clientBudget;
	@Column(nullable=false)
	private String clientAddress;
	
	@Column(nullable=false)
	private String clientCreditScore;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn
	private Agent agent;
	
	public Client() {}

	public Client(Integer clientId, String clientName, String cpf, String clientEmail, String clientPhone,
			String clientMobile, BigDecimal clientBudget, String clientAddress, String clientCreditScore, Agent agent) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
		this.cpf = cpf;
		this.clientEmail = clientEmail;
		this.clientPhone = clientPhone;
		this.clientMobile = clientMobile;
		this.clientBudget = clientBudget;
		this.clientAddress = clientAddress;
		this.clientCreditScore = clientCreditScore;
		this.agent = agent;
	}

	public Integer getClientId() {
		return clientId;
	}

	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getClientEmail() {
		return clientEmail;
	}

	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}

	public String getClientPhone() {
		return clientPhone;
	}

	public void setClientPhone(String clientPhone) {
		this.clientPhone = clientPhone;
	}

	public String getClientMobile() {
		return clientMobile;
	}

	public void setClientMobile(String clientMobile) {
		this.clientMobile = clientMobile;
	}

	public BigDecimal getClientBudget() {
		return clientBudget;
	}

	public void setClientBudget(BigDecimal clientBudget) {
		this.clientBudget = clientBudget;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public String getClientCreditScore() {
		return clientCreditScore;
	}

	public void setClientCreditScore(String clientCreditScore) {
		this.clientCreditScore = clientCreditScore;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}
	
	
}
