package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class PropertyState implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2228352393961654281L;
	@Id
	@Column
	private Integer propertyStateId;
	private String propertyStateName;
	
	public PropertyState() {}
	
	public PropertyState(Integer propertyStateId, String propertyStateName) {
		super();
		this.propertyStateId = propertyStateId;
		this.propertyStateName = propertyStateName;
	}

	public Integer getPropertyStateId() {
		return propertyStateId;
	}

	public void setPropertyStateId(Integer propertyStateId) {
		this.propertyStateId = propertyStateId;
	}

	public String getPropertyStateName() {
		return propertyStateName;
	}

	public void setPropertyStateName(String propertyStateName) {
		this.propertyStateName = propertyStateName;
	}
	
	
	
}
