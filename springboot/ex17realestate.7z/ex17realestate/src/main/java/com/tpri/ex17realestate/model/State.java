package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class State implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8421930228776538021L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private Integer stateId;
	
	@Column(nullable=false)
	private String stateName;
	
	@Column(nullable=false)
	private String stateAbreviation;

	public State(Integer stateId, String stateName, String stateAbreviation) {
		super();
		this.stateId = stateId;
		this.stateName = stateName;
		this.stateAbreviation = stateAbreviation;
	}
	
	public State() {}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getStateAbreviation() {
		return stateAbreviation;
	}

	public void setStateAbreviation(String stateAbreviation) {
		this.stateAbreviation = stateAbreviation;
	}
	
	
	
	
}
