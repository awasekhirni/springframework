package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class City implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4653113532707558718L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="cityId")
	private Integer cityId;
	
	@Column(name="cityName",nullable=false)
	private String cityName;;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="stateId")
	private State state;

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public City(Integer cityId, String cityName, State state) {
		super();
		this.cityId = cityId;
		this.cityName = cityName;
		this.state = state;
	}
	
	public City() {}
	
	
	
	
}
