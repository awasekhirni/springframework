package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

public class PropertyType implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2484116515595774080L;

	@Id
	@Column
	private Integer propertyTypeId;
	
	@Column(nullable=false)
	private String propertyTypeName;
	
	public PropertyType() {}

	public PropertyType(Integer propertyTypeId, String propertyTypeName) {
		super();
		this.propertyTypeId = propertyTypeId;
		this.propertyTypeName = propertyTypeName;
	}

	public Integer getPropertyTypeId() {
		return propertyTypeId;
	}

	public void setPropertyTypeId(Integer propertyTypeId) {
		this.propertyTypeId = propertyTypeId;
	}

	public String getPropertyTypeName() {
		return propertyTypeName;
	}

	public void setPropertyTypeName(String propertyTypeName) {
		this.propertyTypeName = propertyTypeName;
	}
	
	
	
	
	
}
