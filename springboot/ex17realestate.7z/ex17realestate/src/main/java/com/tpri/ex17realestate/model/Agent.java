package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Agent implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6753692657772105061L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer agentId;
	@Column(name="name",nullable=false,length=255)
	private String name;
	@Column(name="email", nullable=false,length=255)
	private String email;
	@Column(name="site",nullable=false)
	private String site;
	
	@Column(name="site",nullable=false)
	private String mobile;
	
	@Column(name="site",nullable=false)
	private String phone;
	
	@Column(name="site",nullable=false)
	private String cpf;
	
	@ManyToOne
	@JoinColumn(name="agentId")
	private RealEstate realEstate;
	
	@ManyToOne
	@JoinColumn(name="stateId")
	private State state;
	
	@ManyToOne
	@JoinColumn(name="cityId")
	private City city;
	
	
	public Agent() {}
	public Agent(Integer agentId, String name, String email, String site, String mobile, String phone, String cpf,
			RealEstate realEstate, State state, City city, Integer creciCode) {
		super();
		this.agentId = agentId;
		this.name = name;
		this.email = email;
		this.site = site;
		this.mobile = mobile;
		this.phone = phone;
		this.cpf = cpf;
		this.realEstate = realEstate;
		this.state = state;
		this.city = city;
		this.creciCode = creciCode;
	}
	public RealEstate getRealEstate() {
		return realEstate;
	}
	public void setRealEstate(RealEstate realEstate) {
		this.realEstate = realEstate;
	}
	public State getState() {
		return state;
	}
	public void setState(State state) {
		this.state = state;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}
	public void setCreciCode(Integer creciCode) {
		this.creciCode = creciCode;
	}
	//CRECI Commercial Real Estate Certification Institute (CRECI)
	@Column(name="site",nullable=false)
	private Integer creciCode;
	
	public Integer getAgentId() {
		return agentId;
	}
	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Integer getCreciCode() {
		return creciCode;
	}
	public void setCreci(Integer creci) {
		this.creciCode = creci;
	}
	
	
	
}
