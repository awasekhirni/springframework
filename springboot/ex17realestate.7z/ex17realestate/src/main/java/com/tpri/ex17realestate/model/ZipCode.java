package com.tpri.ex17realestate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class ZipCode implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1742175124320626115L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private Integer zipcodeId;
	
	@Column(nullable=false)
	private String postalCode;
	
	@Column(nullable=false)
	private String street;
	
	@Column(nullable=false)
	private String region;
	
	@Column(nullable=false)
	private String type;
	
	@ManyToOne
	@JoinColumn(name="cityId")
	private City city;
	
	public ZipCode() {}

	public ZipCode(Integer zipcodeId, String postalCode, String street, String region, String type, City city) {
		super();
		this.zipcodeId = zipcodeId;
		this.postalCode = postalCode;
		this.street = street;
		this.region = region;
		this.type = type;
		this.city = city;
	}
	
	
	
	
}
