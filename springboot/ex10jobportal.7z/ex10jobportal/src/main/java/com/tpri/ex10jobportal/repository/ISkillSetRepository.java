package com.tpri.ex10jobportal.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex10jobportal.model.SkillSet;

@Repository
public interface ISkillSetRepository extends CrudRepository<SkillSet, Integer>{

}
