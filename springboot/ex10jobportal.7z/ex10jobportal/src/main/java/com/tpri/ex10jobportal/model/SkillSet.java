package com.tpri.ex10jobportal.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity()
@Table(name="skillset")
public class SkillSet {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int skillsetId;
	@NotNull
	private String skillSet;
	@NotNull
	private String skillsetRemark;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private SkillSetType skillsetType;
	
	
	
	
	public int getSkillsetId() {
		return skillsetId;
	}

	public void setSkillsetId(int skillsetId) {
		this.skillsetId = skillsetId;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public SkillSetType getSkillsetType() {
		return skillsetType;
	}

	public void setSkillsetType(SkillSetType skillsetType) {
		this.skillsetType = skillsetType;
	}

	public Set<SeekerProfile> getSeekerprofiles() {
		return seekerprofiles;
	}

	public void setSeekerprofiles(Set<SeekerProfile> seekerprofiles) {
		this.seekerprofiles = seekerprofiles;
	}

	public Set<JobPost> getJobposts() {
		return jobposts;
	}

	public void setJobposts(Set<JobPost> jobposts) {
		this.jobposts = jobposts;
	}

	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            },
            mappedBy = "skillsets")
    private Set<SeekerProfile> seekerprofiles = new HashSet<>();
	
	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            },
            mappedBy = "skillsets")
    private Set<JobPost> jobposts = new HashSet<>();

	public String getSkillsetRemark() {
		return skillsetRemark;
	}

	public void setSkillsetRemark(String skillsetRemark) {
		this.skillsetRemark = skillsetRemark;
	}

	public SkillSet() {
	}

	public SkillSet(int skillsetId, String skillSet, String skillsetRemark, SkillSetType skillsetType,
			Set<SeekerProfile> seekerprofiles, Set<JobPost> jobposts) {
		super();
		this.skillsetId = skillsetId;
		this.skillSet = skillSet;
		this.skillsetRemark = skillsetRemark;
		this.skillsetType = skillsetType;
		this.seekerprofiles = seekerprofiles;
		this.jobposts = jobposts;
	}

	
	
	 

}
