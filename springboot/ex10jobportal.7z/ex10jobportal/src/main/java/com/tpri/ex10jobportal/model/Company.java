package com.tpri.ex10jobportal.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity()
@Table(name="company")
public class Company {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int companyId;
	@NotNull
	private String companyName;
	@NotNull
	private String companyProfile;
	@NotNull
	private String companyUrl;
	@NotNull
	private Date companyStartDate;
	@NotNull
	private String companyRegOffice;
	@NotNull
	private String companyRegCity;
	@NotNull
	private String companyRegState;
	@NotNull
	private String companyRegCountry;
	@NotNull
	private String companyPhone;
	@NotNull
	private String companyEmail;
	
	public Domain getDomain() {
		return domain;
	}



	public void setDomain(Domain domain) {
		this.domain = domain;
	}

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "domainId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Domain domain;
	
	public Company() {}
	
	
	
	

	public Company(int companyId, String companyName, String companyProfile, String companyUrl, Date companyStartDate,
			String companyRegOffice, String companyRegCity, String companyRegState, String companyRegCountry,
			String companyPhone, String companyEmail, Domain domain) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyProfile = companyProfile;
		this.companyUrl = companyUrl;
		this.companyStartDate = companyStartDate;
		this.companyRegOffice = companyRegOffice;
		this.companyRegCity = companyRegCity;
		this.companyRegState = companyRegState;
		this.companyRegCountry = companyRegCountry;
		this.companyPhone = companyPhone;
		this.companyEmail = companyEmail;
		this.domain = domain;
	}



	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyProfile() {
		return companyProfile;
	}

	public void setCompanyProfile(String companyProfile) {
		this.companyProfile = companyProfile;
	}

	public String getCompanyUrl() {
		return companyUrl;
	}

	public void setCompanyUrl(String companyUrl) {
		this.companyUrl = companyUrl;
	}

	public Date getCompanyStartDate() {
		return companyStartDate;
	}

	public void setCompanyStartDate(Date companyStartDate) {
		this.companyStartDate = companyStartDate;
	}

	public String getCompanyRegOffice() {
		return companyRegOffice;
	}

	public void setCompanyRegOffice(String companyRegOffice) {
		this.companyRegOffice = companyRegOffice;
	}

	public String getCompanyRegCity() {
		return companyRegCity;
	}

	public void setCompanyRegCity(String companyRegCity) {
		this.companyRegCity = companyRegCity;
	}

	public String getCompanyRegState() {
		return companyRegState;
	}

	public void setCompanyRegState(String companyRegState) {
		this.companyRegState = companyRegState;
	}

	public String getCompanyRegCountry() {
		return companyRegCountry;
	}

	public void setCompanyRegCountry(String companyRegCountry) {
		this.companyRegCountry = companyRegCountry;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	
	
	
	
	
}
