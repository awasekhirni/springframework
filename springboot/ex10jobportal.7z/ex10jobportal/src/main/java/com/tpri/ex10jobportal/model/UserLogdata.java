package com.tpri.ex10jobportal.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity()
@Table(name="userlogdata")
public class UserLogdata {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@NotNull
	private Date lastloginDate;
	@NotNull
	private String lastloginIpaddress;
	@NotNull
	private Date lastloginStarttime;
	@NotNull
	private Date lastloginEndtime;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserType userType;
	
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserAccount userAccount;
	
	
	
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public UserAccount getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(UserAccount userAccount) {
		this.userAccount = userAccount;
	}
	public Date getLastloginDate() {
		return lastloginDate;
	}
	public void setLastloginDate(Date lastloginDate) {
		this.lastloginDate = lastloginDate;
	}
	public String getLastloginIpaddress() {
		return lastloginIpaddress;
	}
	public void setLastloginIpaddress(String lastloginIpaddress) {
		this.lastloginIpaddress = lastloginIpaddress;
	}
	public Date getLastloginStarttime() {
		return lastloginStarttime;
	}
	public void setLastloginStarttime(Date lastloginStarttime) {
		this.lastloginStarttime = lastloginStarttime;
	}
	public Date getLastloginEndtime() {
		return lastloginEndtime;
	}
	public void setLastloginEndtime(Date lastloginEndtime) {
		this.lastloginEndtime = lastloginEndtime;
	}
	
	public UserLogdata() {}
	public UserLogdata(Date lastloginDate, String lastloginIpaddress, Date lastloginStarttime, Date lastloginEndtime,
			UserType userType, UserAccount userAccount) {
		super();
		this.lastloginDate = lastloginDate;
		this.lastloginIpaddress = lastloginIpaddress;
		this.lastloginStarttime = lastloginStarttime;
		this.lastloginEndtime = lastloginEndtime;
		this.userType = userType;
		this.userAccount = userAccount;
	}
	
	
	
	
}
