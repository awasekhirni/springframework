package com.tpri.ex10jobportal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity()
@Table(name="jobtype")
public class JobType {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int jobtypeId;
	@NotNull
	private String jobType;
	
	
	public int getJobtypeId() {
		return jobtypeId;
	}
	public void setJobtypeId(int jobtypeId) {
		this.jobtypeId = jobtypeId;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	
	public JobType() {}
	
	
	public JobType(int jobtypeId, String jobType) {
		super();
		this.jobtypeId = jobtypeId;
		this.jobType = jobType;
	}
	
	
	
	

}
