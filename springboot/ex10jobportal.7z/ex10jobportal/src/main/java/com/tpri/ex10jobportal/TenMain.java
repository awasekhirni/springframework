package com.tpri.ex10jobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(TenMain.class, args);
	}

}
