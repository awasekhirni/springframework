package com.tpri.ex10jobportal.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity()
@Table(name="useraccount")
public class UserAccount {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int useraccountId;
	@NotNull
	private  String useraccountEmail;
	@NotNull
	private String useraccountpwd;
	@NotNull
	private Date dateofbirth;
	@NotNull
	private String gender;
	private boolean isactive;
	@NotNull
	private String phonenumber;
	private boolean issmsactive;
	private boolean isemailactive;
	@NotNull
	private String userimage;
	@NotNull
	private Date registrationDate;
	@NotNull
	private String registerIp;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usertypeId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserType userType;
	
	
	 @ManyToMany(fetch = FetchType.LAZY,
	            cascade = {
	                CascadeType.PERSIST,
	                CascadeType.MERGE
	            })
	  @JoinTable(name = "useraccount_jobpost",
	            joinColumns = { @JoinColumn(name = "useraccountId") },
	            inverseJoinColumns = { @JoinColumn(name = "jobpostId") })
	 private Set<JobPost> jobposts = new HashSet<>();
	 
	 
	
	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public Set<JobPost> getJobposts() {
		return jobposts;
	}

	public void setJobposts(Set<JobPost> jobposts) {
		this.jobposts = jobposts;
	}

	public UserAccount() {}
	
	

	public UserAccount(int useraccountId, String useraccountEmail, String useraccountpwd, Date dateofbirth,
			String gender, boolean isactive, String phonenumber, boolean issmsactive, boolean isemailactive,
			String userimage, Date registrationDate, String registerIp, UserType userType, Set<JobPost> jobposts) {
		super();
		this.useraccountId = useraccountId;
		this.useraccountEmail = useraccountEmail;
		this.useraccountpwd = useraccountpwd;
		this.dateofbirth = dateofbirth;
		this.gender = gender;
		this.isactive = isactive;
		this.phonenumber = phonenumber;
		this.issmsactive = issmsactive;
		this.isemailactive = isemailactive;
		this.userimage = userimage;
		this.registrationDate = registrationDate;
		this.registerIp = registerIp;
		this.userType = userType;
		this.jobposts = jobposts;
	}

	public int getUseraccountId() {
		return useraccountId;
	}

	public void setUseraccountId(int useraccountId) {
		this.useraccountId = useraccountId;
	}

	public String getUseraccountEmail() {
		return useraccountEmail;
	}

	public void setUseraccountEmail(String useraccountEmail) {
		this.useraccountEmail = useraccountEmail;
	}

	public String getUseraccountpwd() {
		return useraccountpwd;
	}

	public void setUseraccountpwd(String useraccountpwd) {
		this.useraccountpwd = useraccountpwd;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean getIsactive() {
		return isactive;
	}

	public void setIsactive(boolean isactive) {
		this.isactive = isactive;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public boolean getIssmsactive() {
		return issmsactive;
	}

	public void setIssmsactive(boolean issmsactive) {
		this.issmsactive = issmsactive;
	}

	public boolean getIsemailactive() {
		return isemailactive;
	}

	public void setIsemailactive(boolean isemailactive) {
		this.isemailactive = isemailactive;
	}

	public String getUserimage() {
		return userimage;
	}

	public void setUserimage(String userimage) {
		this.userimage = userimage;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getRegisterIp() {
		return registerIp;
	}

	public void setRegisterIp(String registerIp) {
		this.registerIp = registerIp;
	}
	
	
}
