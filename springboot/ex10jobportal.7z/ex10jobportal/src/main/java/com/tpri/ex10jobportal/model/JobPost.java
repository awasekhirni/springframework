package com.tpri.ex10jobportal.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;

@Entity()
@Table(name="jobpost")
@ApiModel(description="Job Posting Table")
public class JobPost {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int jobpostId;
	@NotNull
	private Date jobpostDate;
	@NotNull
	private Date hiringDeadline;
	@NotNull
	private String jobLocation;
	@NotNull
	private String jobpostingSalary;
	@NotNull
	private String jobpostingHrname;
	@NotNull
	private String jobpostingHremail;
	@NotNull
	private String jobpostingHrphone;
	private boolean iscompanyHidden;
	
	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            },
            mappedBy = "jobposts")
    private Set<UserAccount> useraccounts = new HashSet<>();
	
	
	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            })
    @JoinTable(name = "jobpost_skillset",
            joinColumns = { @JoinColumn(name = "jobpostId") },
            inverseJoinColumns = { @JoinColumn(name = "skillsetId") })
    private Set<SkillSet> skillsets = new HashSet<>();
	
	public JobPost() {}

	

	
	



	public JobPost(int jobpostId, Date jobpostDate, Date hiringDeadline, String jobLocation, String jobpostingSalary,
			String jobpostingHrname, String jobpostingHremail, String jobpostingHrphone, boolean iscompanyHidden,
			Set<UserAccount> useraccounts, Set<SkillSet> skillsets) {
		super();
		this.jobpostId = jobpostId;
		this.jobpostDate = jobpostDate;
		this.hiringDeadline = hiringDeadline;
		this.jobLocation = jobLocation;
		this.jobpostingSalary = jobpostingSalary;
		this.jobpostingHrname = jobpostingHrname;
		this.jobpostingHremail = jobpostingHremail;
		this.jobpostingHrphone = jobpostingHrphone;
		this.iscompanyHidden = iscompanyHidden;
		this.useraccounts = useraccounts;
		this.skillsets = skillsets;
	}








	public Set<UserAccount> getUseraccounts() {
		return useraccounts;
	}








	public void setUseraccounts(Set<UserAccount> useraccounts) {
		this.useraccounts = useraccounts;
	}








	public Set<SkillSet> getSkillsets() {
		return skillsets;
	}

	public void setSkillsets(Set<SkillSet> skillsets) {
		this.skillsets = skillsets;
	}

	public int getJobpostId() {
		return jobpostId;
	}

	public void setJobpostId(int jobpostId) {
		this.jobpostId = jobpostId;
	}

	public Date getJobpostDate() {
		return jobpostDate;
	}

	public void setJobpostDate(Date jobpostDate) {
		this.jobpostDate = jobpostDate;
	}

	public Date getHiringDeadline() {
		return hiringDeadline;
	}

	public void setHiringDeadline(Date hiringDeadline) {
		this.hiringDeadline = hiringDeadline;
	}

	public String getJobLocation() {
		return jobLocation;
	}

	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}

	public String getJobpostingSalary() {
		return jobpostingSalary;
	}

	public void setJobpostingSalary(String jobpostingSalary) {
		this.jobpostingSalary = jobpostingSalary;
	}

	public String getJobpostingHrname() {
		return jobpostingHrname;
	}

	public void setJobpostingHrname(String jobpostingHrname) {
		this.jobpostingHrname = jobpostingHrname;
	}

	public String getJobpostingHremail() {
		return jobpostingHremail;
	}

	public void setJobpostingHremail(String jobpostingHremail) {
		this.jobpostingHremail = jobpostingHremail;
	}

	public String getJobpostingHrphone() {
		return jobpostingHrphone;
	}

	public void setJobpostingHrphone(String jobpostingHrphone) {
		this.jobpostingHrphone = jobpostingHrphone;
	}

	public boolean isIscompanyHidden() {
		return iscompanyHidden;
	}

	public void setIscompanyHidden(boolean iscompanyHidden) {
		this.iscompanyHidden = iscompanyHidden;
	}
	
	
	
	
	
	
	
	
}
