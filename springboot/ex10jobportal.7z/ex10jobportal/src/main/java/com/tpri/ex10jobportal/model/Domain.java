package com.tpri.ex10jobportal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity()
@Table(name="domain")
public class Domain {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int domainId;
	@NotNull
	private String domainName;

	public int getDomainId() {
		return domainId;
	}

	public void setDomainId(int domainId) {
		this.domainId = domainId;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public Domain() {
	}

	public Domain(int domainId, String domainName) {
		super();
		this.domainId = domainId;
		this.domainName = domainName;
	}

	

}
