package com.tpri.ex10jobportal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity()
@Table(name="skillsettype")
public class SkillSetType {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int skillsettypeId;
	@NotNull
	private String skillsetType;
	
	
    
	
	public int getSkillsettypeId() {
		return skillsettypeId;
	}
	public void setSkillsettypeId(int skillsettypeId) {
		this.skillsettypeId = skillsettypeId;
	}
	public String getSkillsetType() {
		return skillsetType;
	}
	public void setSkillsetType(String skillsetType) {
		this.skillsetType = skillsetType;
	}
	
	public SkillSetType() {}
	public SkillSetType(int skillsettypeId, String skillsetType) {
		super();
		this.skillsettypeId = skillsettypeId;
		this.skillsetType = skillsetType;
	}
	
	
	
	
}
