package com.tpri.ex10jobportal.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity()
@Table(name="educationinfo")
public class EducationInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@NotNull
	private String certificateDegreeName;
	@NotNull
	private String majorStream;
	
	private String minorStream;
	@NotNull
	private String instituteUniversityName;
	@NotNull
	private Date startDate;
	
	public UserAccount getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(UserAccount userAccount) {
		this.userAccount = userAccount;
	}

	private Date endDate;
	@NotNull
	private double percentage;
	@NotNull
	private double cgpa;
	@NotNull
	private String location;
	@NotNull
	private boolean isfulltime;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "useraccountId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserAccount userAccount;
	

	public String getCertificateDegreeName() {
		return certificateDegreeName;
	}

	public void setCertificateDegreeName(String certificateDegreeName) {
		this.certificateDegreeName = certificateDegreeName;
	}

	public String getMajorStream() {
		return majorStream;
	}

	public void setMajorStream(String majorStream) {
		this.majorStream = majorStream;
	}

	public String getMinorStream() {
		return minorStream;
	}

	public void setMinorStream(String minorStream) {
		this.minorStream = minorStream;
	}

	public String getInstituteUniversityName() {
		return instituteUniversityName;
	}

	public void setInstituteUniversityName(String instituteUniversityName) {
		this.instituteUniversityName = instituteUniversityName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public boolean isIsfulltime() {
		return isfulltime;
	}

	public void setIsfulltime(boolean isfulltime) {
		this.isfulltime = isfulltime;
	}

	public EducationInfo() {
	}

	public EducationInfo(String certificateDegreeName, String majorStream, String minorStream,
			String instituteUniversityName, Date startDate, Date endDate, double percentage, double cgpa,
			String location, boolean isfulltime, UserAccount userAccount) {
		super();
		this.certificateDegreeName = certificateDegreeName;
		this.majorStream = majorStream;
		this.minorStream = minorStream;
		this.instituteUniversityName = instituteUniversityName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.percentage = percentage;
		this.cgpa = cgpa;
		this.location = location;
		this.isfulltime = isfulltime;
		this.userAccount = userAccount;
	}

	

}
