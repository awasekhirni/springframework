package com.tpri.ex10jobportal.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity()
@Table(name="experienceinfo")
public class ExperienceInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private boolean iscurrentPosition;
	@NotNull
	private Date expStartDate;
	
	private Date expEndDate;
	@NotNull
	private String expJobTitle;
	@NotNull
	private String expCompany;
	
	public UserAccount getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(UserAccount userAccount) {
		this.userAccount = userAccount;
	}

	@NotNull
	private String expJobCity;
	
	@NotNull
	private String expJobState;
	@NotNull
	private String expJobDuties;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "useraccountId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserAccount userAccount;
	
	public boolean isIscurrentPosition() {
		return iscurrentPosition;
	}
	public void setIscurrentPosition(boolean iscurrentPosition) {
		this.iscurrentPosition = iscurrentPosition;
	}
	public Date getExpStartDate() {
		return expStartDate;
	}
	public void setExpStartDate(Date expStartDate) {
		this.expStartDate = expStartDate;
	}
	public Date getExpEndDate() {
		return expEndDate;
	}
	public void setExpEndDate(Date expEndDate) {
		this.expEndDate = expEndDate;
	}
	public String getExpJobTitle() {
		return expJobTitle;
	}
	public void setExpJobTitle(String expJobTitle) {
		this.expJobTitle = expJobTitle;
	}
	public String getExpCompany() {
		return expCompany;
	}
	public void setExpCompany(String expCompany) {
		this.expCompany = expCompany;
	}
	public String getExpJobCity() {
		return expJobCity;
	}
	public void setExpJobCity(String expJobCity) {
		this.expJobCity = expJobCity;
	}
	public String getExpJobState() {
		return expJobState;
	}
	public void setExpJobState(String expJobState) {
		this.expJobState = expJobState;
	}
	public String getExpJobDuties() {
		return expJobDuties;
	}
	public void setExpJobDuties(String expJobDuties) {
		this.expJobDuties = expJobDuties;
	}
	
	public ExperienceInfo() {}
	public ExperienceInfo(boolean iscurrentPosition, Date expStartDate, Date expEndDate, String expJobTitle,
			String expCompany, String expJobCity, String expJobState, String expJobDuties, UserAccount userAccount) {
		super();
		this.iscurrentPosition = iscurrentPosition;
		this.expStartDate = expStartDate;
		this.expEndDate = expEndDate;
		this.expJobTitle = expJobTitle;
		this.expCompany = expCompany;
		this.expJobCity = expJobCity;
		this.expJobState = expJobState;
		this.expJobDuties = expJobDuties;
		this.userAccount = userAccount;
	}
	
	
	
	
	

}
