package com.tpri.ex10jobportal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity()
@Table(name="usertype")
public class UserType {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int usertypeId;
	@NotNull
	private String usertypeName;
	public int getUsertypeId() {
		return usertypeId;
	}
	public void setUsertypeId(int usertypeId) {
		this.usertypeId = usertypeId;
	}
	public String getUsertypeName() {
		return usertypeName;
	}
	public void setUsertypeName(String usertypeName) {
		this.usertypeName = usertypeName;
	}
	
	
	
	
	
	
	public UserType() {}
	
	public UserType(int usertypeId, String usertypeName) {
		super();
		this.usertypeId = usertypeId;
		this.usertypeName = usertypeName;
	}
	
	
	
	

}
