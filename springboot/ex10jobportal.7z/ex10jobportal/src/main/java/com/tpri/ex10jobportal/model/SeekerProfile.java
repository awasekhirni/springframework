package com.tpri.ex10jobportal.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity()
@Table(name="seekerprofile")
public class SeekerProfile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@NotNull
	private String firstName;
	@NotNull
	private String lastName;
	@NotNull
	private int currentSalary;
	@NotNull
	private boolean isannualMonthly;
	@NotNull
	private boolean isannualBiweekly;
	
	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            })
    @JoinTable(name = "seekerprofile_skillset",
            joinColumns = { @JoinColumn(name = "useraccountId") },
            inverseJoinColumns = { @JoinColumn(name = "skillsetId") })
    private Set<SkillSet> skillsets = new HashSet<>();
	
	
	
	public Set<SkillSet> getSkillsets() {
		return skillsets;
	}
	public void setSkillsets(Set<SkillSet> skillsets) {
		this.skillsets = skillsets;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getCurrentSalary() {
		return currentSalary;
	}
	public void setCurrentSalary(int currentSalary) {
		this.currentSalary = currentSalary;
	}
	public boolean isIsannualMonthly() {
		return isannualMonthly;
	}
	public void setIsannualMonthly(boolean isannualMonthly) {
		this.isannualMonthly = isannualMonthly;
	}
	public boolean isIsannualBiweekly() {
		return isannualBiweekly;
	}
	public void setIsannualBiweekly(boolean isannualBiweekly) {
		this.isannualBiweekly = isannualBiweekly;
	}
	public SeekerProfile() {}
	public SeekerProfile(String firstName, String lastName, int currentSalary, boolean isannualMonthly,
			boolean isannualBiweekly, Set<SkillSet> skillsets) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.currentSalary = currentSalary;
		this.isannualMonthly = isannualMonthly;
		this.isannualBiweekly = isannualBiweekly;
		this.skillsets = skillsets;
	}
	
	
	

}
