# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases V8.1.2                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          jobportal_ex10jobportal_springboot.dez          #
# Project name:                                                          #
# Author:                 Awase Khirni Syed awasekhirni@gmail.com        #
# Script type:           Database creation script                        #
# Created on:            2016-09-12 21:03                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Add tables                                                             #
# ---------------------------------------------------------------------- #

# ---------------------------------------------------------------------- #
# Add table "user_type"                                                  #
# ---------------------------------------------------------------------- #

CREATE TABLE `user_type` (
    `usertype_id` INTEGER NOT NULL,
    `usertype_name` VARCHAR(100) NOT NULL,
    CONSTRAINT `PK_user_type` PRIMARY KEY (`usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "user_account"                                               #
# ---------------------------------------------------------------------- #

CREATE TABLE `user_account` (
    `useraccountid` INTEGER NOT NULL,
    `useraccountemail` VARCHAR(200) NOT NULL,
    `useraccountpwd` VARCHAR(40) NOT NULL,
    `dateofbirth` DATE NOT NULL,
    `gender` VARCHAR(100),
    `isactive` BOOL,
    `phonenumber` VARCHAR(40),
    `issmsactive` BOOL,
    `isemailactive` BOOL,
    `userimage` VARCHAR(400),
    `registrationdate` DATE,
    `registerip` VARCHAR(100),
    `usertype_id` INTEGER NOT NULL,
    CONSTRAINT `PK_user_account` PRIMARY KEY (`useraccountid`, `usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "userlogdata"                                                #
# ---------------------------------------------------------------------- #

CREATE TABLE `userlogdata` (
    `lastlogindate` DATE NOT NULL,
    `lastloginipaddress` VARCHAR(100) NOT NULL,
    `lastloginstartime` DATETIME NOT NULL,
    `lastloginendtime` DATETIME NOT NULL,
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    CONSTRAINT `PK_userlogdata` PRIMARY KEY (`useraccountid`, `usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "seekerprofile"                                              #
# ---------------------------------------------------------------------- #

CREATE TABLE `seekerprofile` (
    `firstname` VARCHAR(150) NOT NULL,
    `lastname` VARCHAR(150),
    `currentsalary` VARCHAR(40),
    `isannualmonthly` BOOL,
    `isannualbiweekly` BOOL,
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    PRIMARY KEY (`useraccountid`, `usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "educationinfo"                                              #
# ---------------------------------------------------------------------- #

CREATE TABLE `educationinfo` (
    `certificate_degreename` VARCHAR(200) NOT NULL,
    `major` VARCHAR(200) NOT NULL,
    `minor` VARCHAR(200),
    `Insitute_University` VARCHAR(300) NOT NULL,
    `startdate` DATE NOT NULL,
    `enddate` DATE,
    `percentage` DOUBLE,
    `cgpa` DOUBLE,
    `location` VARCHAR(100),
    `isfulltime` BOOL,
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    CONSTRAINT `PK_educationinfo` PRIMARY KEY (`useraccountid`, `usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "experienceinfo"                                             #
# ---------------------------------------------------------------------- #

CREATE TABLE `experienceinfo` (
    `iscurrentposition` BOOL,
    `exp_startdate` DATE NOT NULL,
    `exp_endate` DATE,
    `exp_jobtitle` VARCHAR(200) NOT NULL,
    `exp_company` VARCHAR(200) NOT NULL,
    `exp_jobcity` VARCHAR(150) NOT NULL,
    `exp_jobstate` VARCHAR(200) NOT NULL,
    `exp_jobcountry` VARCHAR(200) NOT NULL,
    `exp_jobresponsibility` VARCHAR(5000) NOT NULL,
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    CONSTRAINT `PK_experienceinfo` PRIMARY KEY (`useraccountid`, `usertype_id`)
);

# ---------------------------------------------------------------------- #
# Add table "skillsettype"                                               #
# ---------------------------------------------------------------------- #

CREATE TABLE `skillsettype` (
    `skillsettypeid` INTEGER NOT NULL,
    `skillsettype` VARCHAR(150),
    `skillsetremark` VARCHAR(200),
    CONSTRAINT `PK_skillsettype` PRIMARY KEY (`skillsettypeid`)
);

# ---------------------------------------------------------------------- #
# Add table "skillset"                                                   #
# ---------------------------------------------------------------------- #

CREATE TABLE `skillset` (
    `skillsetid` INTEGER NOT NULL,
    `skillsetname` VARCHAR(200),
    `skillsettypeid` INTEGER NOT NULL,
    CONSTRAINT `PK_skillset` PRIMARY KEY (`skillsetid`, `skillsettypeid`)
);

# ---------------------------------------------------------------------- #
# Add table "seekerprofile_skillset"                                     #
# ---------------------------------------------------------------------- #

CREATE TABLE `seekerprofile_skillset` (
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    `skillsetid` INTEGER NOT NULL,
    `skillsettypeid` INTEGER NOT NULL,
    CONSTRAINT `PK_seekerprofile_skillset` PRIMARY KEY (`useraccountid`, `usertype_id`, `skillsetid`, `skillsettypeid`)
);

# ---------------------------------------------------------------------- #
# Add table "domain"                                                     #
# ---------------------------------------------------------------------- #

CREATE TABLE `domain` (
    `domainid` INTEGER NOT NULL,
    `domainname` VARCHAR(200) NOT NULL,
    CONSTRAINT `PK_domain` PRIMARY KEY (`domainid`)
);

# ---------------------------------------------------------------------- #
# Add table "companyid"                                                  #
# ---------------------------------------------------------------------- #

CREATE TABLE `companyid` (
    `companyid` INTEGER NOT NULL,
    `companyname` VARCHAR(200),
    `companyprofile` VARCHAR(1000),
    `companystartdate` DATE,
    `companyurl` VARCHAR(100),
    `companyregisteredoffice` VARCHAR(500),
    `companyregcity` VARCHAR(100),
    `companyregstate` VARCHAR(200),
    `companyregcountry` VARCHAR(200),
    `companyphone` VARCHAR(40),
    `companyemail` VARCHAR(200),
    `domainid` INTEGER NOT NULL,
    CONSTRAINT `PK_companyid` PRIMARY KEY (`companyid`, `domainid`)
);

# ---------------------------------------------------------------------- #
# Add table "companymedia"                                               #
# ---------------------------------------------------------------------- #

CREATE TABLE `companymedia` (
    `image` VARCHAR(40),
    `companyid` INTEGER NOT NULL,
    `domainid` INTEGER NOT NULL,
    CONSTRAINT `PK_companymedia` PRIMARY KEY (`companyid`, `domainid`)
);

# ---------------------------------------------------------------------- #
# Add table "jobtype"                                                    #
# ---------------------------------------------------------------------- #

CREATE TABLE `jobtype` (
    `jobtypeid` INTEGER NOT NULL,
    `jobtype` VARCHAR(200) NOT NULL,
    CONSTRAINT `PK_jobtype` PRIMARY KEY (`jobtypeid`)
);

# ---------------------------------------------------------------------- #
# Add table "jobpost"                                                    #
# ---------------------------------------------------------------------- #

CREATE TABLE `jobpost` (
    `jobpostid` INTEGER NOT NULL,
    `jobpostdate` DATE NOT NULL,
    `jobhiringdeadline` DATE NOT NULL,
    `joblocation` VARCHAR(200) NOT NULL,
    `jobpostingsalary` VARCHAR(100) NOT NULL,
    `jobpostinghrname` VARCHAR(100) NOT NULL,
    `jobpostinghremail` VARCHAR(100) NOT NULL,
    `jobpostinghrphone` VARCHAR(40) NOT NULL,
    `iscompanyhidden` BOOL,
    `jobtypeid` INTEGER NOT NULL,
    `companyid` INTEGER NOT NULL,
    `domainid` INTEGER NOT NULL,
    CONSTRAINT `PK_jobpost` PRIMARY KEY (`jobpostid`, `jobtypeid`, `companyid`, `domainid`)
);

# ---------------------------------------------------------------------- #
# Add table "skillset_jobpost"                                           #
# ---------------------------------------------------------------------- #

CREATE TABLE `skillset_jobpost` (
    `skillsetid` INTEGER NOT NULL,
    `skillsettypeid` INTEGER NOT NULL,
    `jobpostid` INTEGER NOT NULL,
    `jobtypeid` INTEGER NOT NULL,
    `companyid` INTEGER NOT NULL,
    `domainid` INTEGER NOT NULL,
    CONSTRAINT `PK_skillset_jobpost` PRIMARY KEY (`skillsetid`, `skillsettypeid`, `jobpostid`, `jobtypeid`, `companyid`, `domainid`)
);

# ---------------------------------------------------------------------- #
# Add table "user_account_jobpost"                                       #
# ---------------------------------------------------------------------- #

CREATE TABLE `user_account_jobpost` (
    `useraccountid` INTEGER NOT NULL,
    `usertype_id` INTEGER NOT NULL,
    `jobpostid` INTEGER NOT NULL,
    `jobtypeid` INTEGER NOT NULL,
    `companyid` INTEGER NOT NULL,
    `domainid` INTEGER NOT NULL,
    CONSTRAINT `PK_user_account_jobpost` PRIMARY KEY (`useraccountid`, `usertype_id`, `jobpostid`, `jobtypeid`, `companyid`, `domainid`)
);

# ---------------------------------------------------------------------- #
# Add foreign key constraints                                            #
# ---------------------------------------------------------------------- #

ALTER TABLE `user_account` ADD CONSTRAINT `user_type_user_account` 
    FOREIGN KEY (`usertype_id`) REFERENCES `user_type` (`usertype_id`);

ALTER TABLE `userlogdata` ADD CONSTRAINT `user_account_userlogdata` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `user_account` (`useraccountid`,`usertype_id`);

ALTER TABLE `seekerprofile` ADD CONSTRAINT `user_account_seekerprofile` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `user_account` (`useraccountid`,`usertype_id`);

ALTER TABLE `educationinfo` ADD CONSTRAINT `seekerprofile_educationinfo` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `seekerprofile` (`useraccountid`,`usertype_id`);

ALTER TABLE `experienceinfo` ADD CONSTRAINT `seekerprofile_experienceinfo` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `seekerprofile` (`useraccountid`,`usertype_id`);

ALTER TABLE `skillset` ADD CONSTRAINT `skillsettype_skillset` 
    FOREIGN KEY (`skillsettypeid`) REFERENCES `skillsettype` (`skillsettypeid`);

ALTER TABLE `seekerprofile_skillset` ADD CONSTRAINT `seekerprofile_seekerprofile_skillset` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `seekerprofile` (`useraccountid`,`usertype_id`);

ALTER TABLE `seekerprofile_skillset` ADD CONSTRAINT `skillset_seekerprofile_skillset` 
    FOREIGN KEY (`skillsetid`, `skillsettypeid`) REFERENCES `skillset` (`skillsetid`,`skillsettypeid`);

ALTER TABLE `companyid` ADD CONSTRAINT `domain_companyid` 
    FOREIGN KEY (`domainid`) REFERENCES `domain` (`domainid`);

ALTER TABLE `companymedia` ADD CONSTRAINT `companyid_companymedia` 
    FOREIGN KEY (`companyid`, `domainid`) REFERENCES `companyid` (`companyid`,`domainid`);

ALTER TABLE `jobpost` ADD CONSTRAINT `jobtype_jobpost` 
    FOREIGN KEY (`jobtypeid`) REFERENCES `jobtype` (`jobtypeid`);

ALTER TABLE `jobpost` ADD CONSTRAINT `companyid_jobpost` 
    FOREIGN KEY (`companyid`, `domainid`) REFERENCES `companyid` (`companyid`,`domainid`);

ALTER TABLE `skillset_jobpost` ADD CONSTRAINT `skillset_skillset_jobpost` 
    FOREIGN KEY (`skillsetid`, `skillsettypeid`) REFERENCES `skillset` (`skillsetid`,`skillsettypeid`);

ALTER TABLE `skillset_jobpost` ADD CONSTRAINT `jobpost_skillset_jobpost` 
    FOREIGN KEY (`jobpostid`, `jobtypeid`, `companyid`, `domainid`) REFERENCES `jobpost` (`jobpostid`,`jobtypeid`,`companyid`,`domainid`);

ALTER TABLE `user_account_jobpost` ADD CONSTRAINT `user_account_user_account_jobpost` 
    FOREIGN KEY (`useraccountid`, `usertype_id`) REFERENCES `user_account` (`useraccountid`,`usertype_id`);

ALTER TABLE `user_account_jobpost` ADD CONSTRAINT `jobpost_user_account_jobpost` 
    FOREIGN KEY (`jobpostid`, `jobtypeid`, `companyid`, `domainid`) REFERENCES `jobpost` (`jobpostid`,`jobtypeid`,`companyid`,`domainid`);
