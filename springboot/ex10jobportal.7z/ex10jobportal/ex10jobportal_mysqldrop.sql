# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases V8.1.2                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          jobportal_ex10jobportal_springboot.dez          #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database drop script                            #
# Created on:            2019-12-29 21:03                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Drop foreign key constraints                                           #
# ---------------------------------------------------------------------- #

ALTER TABLE `user_account` DROP FOREIGN KEY `user_type_user_account`;

ALTER TABLE `userlogdata` DROP FOREIGN KEY `user_account_userlogdata`;

ALTER TABLE `seekerprofile` DROP FOREIGN KEY `user_account_seekerprofile`;

ALTER TABLE `educationinfo` DROP FOREIGN KEY `seekerprofile_educationinfo`;

ALTER TABLE `experienceinfo` DROP FOREIGN KEY `seekerprofile_experienceinfo`;

ALTER TABLE `skillset` DROP FOREIGN KEY `skillsettype_skillset`;

ALTER TABLE `seekerprofile_skillset` DROP FOREIGN KEY `seekerprofile_seekerprofile_skillset`;

ALTER TABLE `seekerprofile_skillset` DROP FOREIGN KEY `skillset_seekerprofile_skillset`;

ALTER TABLE `companyid` DROP FOREIGN KEY `domain_companyid`;

ALTER TABLE `companymedia` DROP FOREIGN KEY `companyid_companymedia`;

ALTER TABLE `jobpost` DROP FOREIGN KEY `jobtype_jobpost`;

ALTER TABLE `jobpost` DROP FOREIGN KEY `companyid_jobpost`;

ALTER TABLE `skillset_jobpost` DROP FOREIGN KEY `skillset_skillset_jobpost`;

ALTER TABLE `skillset_jobpost` DROP FOREIGN KEY `jobpost_skillset_jobpost`;

ALTER TABLE `user_account_jobpost` DROP FOREIGN KEY `user_account_user_account_jobpost`;

ALTER TABLE `user_account_jobpost` DROP FOREIGN KEY `jobpost_user_account_jobpost`;

# ---------------------------------------------------------------------- #
# Drop table "user_account_jobpost"                                      #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `user_account_jobpost` DROP PRIMARY KEY;

DROP TABLE `user_account_jobpost`;

# ---------------------------------------------------------------------- #
# Drop table "skillset_jobpost"                                          #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `skillset_jobpost` DROP PRIMARY KEY;

DROP TABLE `skillset_jobpost`;

# ---------------------------------------------------------------------- #
# Drop table "jobpost"                                                   #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `jobpost` DROP PRIMARY KEY;

DROP TABLE `jobpost`;

# ---------------------------------------------------------------------- #
# Drop table "jobtype"                                                   #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `jobtype` DROP PRIMARY KEY;

DROP TABLE `jobtype`;

# ---------------------------------------------------------------------- #
# Drop table "companymedia"                                              #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `companymedia` DROP PRIMARY KEY;

DROP TABLE `companymedia`;

# ---------------------------------------------------------------------- #
# Drop table "companyid"                                                 #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `companyid` DROP PRIMARY KEY;

DROP TABLE `companyid`;

# ---------------------------------------------------------------------- #
# Drop table "domain"                                                    #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `domain` DROP PRIMARY KEY;

DROP TABLE `domain`;

# ---------------------------------------------------------------------- #
# Drop table "seekerprofile_skillset"                                    #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `seekerprofile_skillset` DROP PRIMARY KEY;

DROP TABLE `seekerprofile_skillset`;

# ---------------------------------------------------------------------- #
# Drop table "skillset"                                                  #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `skillset` DROP PRIMARY KEY;

DROP TABLE `skillset`;

# ---------------------------------------------------------------------- #
# Drop table "skillsettype"                                              #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `skillsettype` DROP PRIMARY KEY;

DROP TABLE `skillsettype`;

# ---------------------------------------------------------------------- #
# Drop table "experienceinfo"                                            #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `experienceinfo` DROP PRIMARY KEY;

DROP TABLE `experienceinfo`;

# ---------------------------------------------------------------------- #
# Drop table "educationinfo"                                             #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `educationinfo` DROP PRIMARY KEY;

DROP TABLE `educationinfo`;

# ---------------------------------------------------------------------- #
# Drop table "seekerprofile"                                             #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `seekerprofile` DROP PRIMARY KEY;

DROP TABLE `seekerprofile`;

# ---------------------------------------------------------------------- #
# Drop table "userlogdata"                                               #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `userlogdata` DROP PRIMARY KEY;

DROP TABLE `userlogdata`;

# ---------------------------------------------------------------------- #
# Drop table "user_account"                                              #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `user_account` DROP PRIMARY KEY;

DROP TABLE `user_account`;

# ---------------------------------------------------------------------- #
# Drop table "user_type"                                                 #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `user_type` DROP PRIMARY KEY;

DROP TABLE `user_type`;
