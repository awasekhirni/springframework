package com.tpri.ex15movierating.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tpri.ex15movierating.model.Movie;
import com.tpri.ex15movierating.model.User;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class RatingNotFoundException extends RuntimeException {

	public RatingNotFoundException(Long ratingId) {
		super("Could not find movierating!");
	}
	
	public RatingNotFoundException(User user) {
		super("this user has not submitted any ratings!");
	}
	
	public RatingNotFoundException(Movie movie) {
		super("there is no rating for the movie");
	}
	
	public RatingNotFoundException(User user, Long ratingId) {
		super("There is no rating submitted by the user yet!");
	}
}
