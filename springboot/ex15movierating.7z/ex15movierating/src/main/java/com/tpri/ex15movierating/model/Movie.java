package com.tpri.ex15movierating.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Movie implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -579820045191788077L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String title;
	private String description;
	private String movieImage;
	private String movieTrailer;
	private Date releaseDate;
	public Movie(Long id, String title, String description, String movieImage, String movieTrailer, Date releaseDate) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.movieImage = movieImage;
		this.movieTrailer = movieTrailer;
		this.releaseDate = releaseDate;
	}
	
	public Movie() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMovieImage() {
		return movieImage;
	}

	public void setMovieImage(String movieImage) {
		this.movieImage = movieImage;
	}

	public String getMovieTrailer() {
		return movieTrailer;
	}

	public void setMovieTrailer(String movieTrailer) {
		this.movieTrailer = movieTrailer;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	
	
	
	
	

}
