package com.tpri.ex15movierating.controller;

import java.net.URI;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.tpri.ex15movierating.model.User;
import com.tpri.ex15movierating.repository.UserRepository;

@RestController
@RequestMapping("/users")
public class UserController {

		@Autowired
		private UserRepository userRepository;
		
		UserController(UserRepository userRepository){
			this.userRepository=userRepository;
		}
		
		@GetMapping
		Collection<User> getAllUsers(){
			return this.userRepository.findAll();
		}
		
		@GetMapping("/{userId}")
		User getUser(@PathVariable Long userId) {
			return this.userRepository.findOne(userId);
					
		}
		
		@PostMapping
	    ResponseEntity<User> createUser(@RequestBody User input) {
	        User user = this.userRepository
	            .save(new User(input.getId(), input.getName(), input.getPassword(), null));

	        URI location = ServletUriComponentsBuilder
	            .fromCurrentRequest().path("/{userId}")
	            .buildAndExpand(user.getId()).toUri();

	        return ResponseEntity.created(location).build();
	    }
	
}
