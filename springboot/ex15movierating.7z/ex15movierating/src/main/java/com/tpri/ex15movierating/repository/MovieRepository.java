package com.tpri.ex15movierating.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tpri.ex15movierating.model.Movie;

public interface MovieRepository extends JpaRepository<Movie,Long> {

}
