package com.tpri.ex15movierating.controller;

import java.net.URI;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.tpri.ex15movierating.model.Movie;
import com.tpri.ex15movierating.repository.MovieRepository;

@RestController
@RequestMapping("/movies")
public class MovieController {

	@Autowired
	private MovieRepository movieRepository;
	
	
	MovieController(MovieRepository movieRepository){
		this.movieRepository=movieRepository;
	}
	
	
	 @GetMapping("/{movieId}")
	 public Movie getMovie(@PathVariable Long movieId) {
	        return (this.movieRepository.findOne(movieId));
	                
	    }
	 
	 @GetMapping
	 public Collection<Movie> getMovies() {
	        return this.movieRepository.findAll();
	    }

	 @PostMapping
	    ResponseEntity<?> createMovie(@RequestBody Movie input) {
	        Movie movie = this.movieRepository
	                .save(new Movie(input.getId(), input.getTitle(), input.getDescription(), input.getMovieImage(), input.getMovieTrailer(),input.getReleaseDate()));

	        URI location = ServletUriComponentsBuilder
	                .fromCurrentRequest().path("/{movieId}")
	                .buildAndExpand(movie.getId()).toUri();

	        return ResponseEntity.created(location).build();
	    }


}
