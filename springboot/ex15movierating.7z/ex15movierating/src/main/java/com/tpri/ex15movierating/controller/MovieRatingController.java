package com.tpri.ex15movierating.controller;

import java.net.URI;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.tpri.ex15movierating.exception.RatingNotFoundException;
import com.tpri.ex15movierating.model.Movie;
import com.tpri.ex15movierating.model.MovieRating;
import com.tpri.ex15movierating.model.User;
import com.tpri.ex15movierating.repository.MovieRatingRepository;
import com.tpri.ex15movierating.repository.MovieRepository;
import com.tpri.ex15movierating.repository.UserRepository;

@RestController
@RequestMapping("/movieratings")
public class MovieRatingController {
	
	@Autowired
	private MovieRatingRepository mrr;
	@Autowired 
	private UserRepository userRepository;
	@Autowired
	private MovieRepository movieRepository;
	
	@GetMapping
	Collection<MovieRating> getRatings(){
		return this.mrr.findAll();
	}
	
	@PostMapping("/{userId}/{movieId}/{stars}")
    ResponseEntity<?> createRating(@PathVariable Long userId, @PathVariable Long movieId, @PathVariable Integer stars) {
        User user = userRepository.findOne(userId);
        Movie movie = movieRepository.findOne(movieId);
        MovieRating rating = this.mrr
                .save(new MovieRating(movieId, user, movie, stars));

        URI location = ServletUriComponentsBuilder
                .fromCurrentContextPath().path("/ratings/{userId}/{ratingId}")
                .buildAndExpand(rating.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

    @GetMapping("/{userId}")
    Collection<MovieRating> getUserRatings(@PathVariable Long userId) {
        User user =userRepository.findOne(userId);
        Collection<MovieRating> ratings = this.mrr.findByUser(user);
        if (ratings.isEmpty()) {
            throw new RatingNotFoundException(user);
        }
        return ratings;
    }

    @GetMapping("/movie/{movieId}")
    Collection<MovieRating> getMovieRatings(@PathVariable Long movieId) {
        Movie movie = movieRepository.findOne(movieId);
        Collection<MovieRating> ratings = this.mrr.findByMovie(movie);
        if (ratings.isEmpty()) {
            throw new RatingNotFoundException(movie);
        }
        return ratings;
    }

    @GetMapping("/{userId}/{ratingId}")
    MovieRating getRating(@PathVariable Long userId, @PathVariable Long ratingId) {
        User user =userRepository.findOne(userId);
        return this.mrr.findByUserAndId(user, ratingId)
                .orElseThrow(() -> new RatingNotFoundException(user, ratingId));
    }

  

}
