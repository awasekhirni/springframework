package com.tpri.ex15movierating.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class User {

	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	
	@JsonIgnore
	private String password;
	
	@OneToMany(mappedBy="user")
	private Set<MovieRating> ratings = new HashSet<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<MovieRating> getRatings() {
		return ratings;
	}

	public void setRatings(Set<MovieRating> ratings) {
		this.ratings = ratings;
	}
	
	public User() {}

	public User(Long id, String name, String password, Set<MovieRating> ratings) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.ratings = ratings;
	}

	
	
	
	
}
