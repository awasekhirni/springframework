package com.tpri.ex15movierating.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tpri.ex15movierating.model.Movie;
import com.tpri.ex15movierating.model.MovieRating;
import com.tpri.ex15movierating.model.User;

public interface MovieRatingRepository extends JpaRepository<MovieRating,Long> {

	List<MovieRating> findByUser(User user);
	
	List<MovieRating> findByMovie(Movie movie);
	
	Optional<MovieRating> findByUserAndId(User user,Long ratingId);
}
