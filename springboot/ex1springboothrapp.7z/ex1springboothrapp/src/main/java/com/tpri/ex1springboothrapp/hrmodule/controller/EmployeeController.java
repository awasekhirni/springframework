package com.tpri.ex1springboothrapp.hrmodule.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex1springboothrapp.hrmodule.model.Employee;

@RestController
@RequestMapping("/hrmodule")
public class EmployeeController {

	@RequestMapping("/employees")
	public List<Employee> getAllEmployees(){
		
		
		return Arrays.asList(
				new Employee(1, "Awase Khirni Syed", "2018/06/06", "Senior Architect", "12378"),
				new Employee(2, "Ameese Sadath", "2018/06/06", "Sr Engineering Manager", "1238"),
				new Employee(3, "Azeez Al Asaad Syed", "2018/06/06", "Jr Architect", "123781"),
				new Employee(4, "Rayyan Awais Syed", "2018/06/06", "Product Designer", "12378")
				
				);
				
				
	}

}
