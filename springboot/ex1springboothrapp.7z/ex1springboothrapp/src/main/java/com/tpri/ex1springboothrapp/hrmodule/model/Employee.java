package com.tpri.ex1springboothrapp.hrmodule.model;

public class Employee {
	private int empId;
	private String empName;
	private String empJoinDate;
	private String empRole;
	private String empSalary;

	//no arg constructor 
	public Employee() {}

	public Employee(int empId, String empName, String empJoinDate, String empRole, 
			String empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empJoinDate = empJoinDate;
		this.empRole = empRole;
		this.empSalary = empSalary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpJoinDate() {
		return empJoinDate;
	}

	public void setEmpJoinDate(String empJoinDate) {
		this.empJoinDate = empJoinDate;
	}

	public String getEmpRole() {
		return empRole;
	}

	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}

	public String getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}
	
	
	
	

}
