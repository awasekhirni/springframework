package com.tpri.exSpringBootSTSPrjTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExSpringBootStsPrjTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExSpringBootStsPrjTemplateApplication.class, args);
	}

}
