package com.tpri.exSpringBootSTSPrjTemplate.model;

public class Product {

}
