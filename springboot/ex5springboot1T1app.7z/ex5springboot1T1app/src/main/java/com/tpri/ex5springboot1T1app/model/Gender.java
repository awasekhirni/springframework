package com.tpri.ex5springboot1T1app.model;

public enum Gender {
	MALE,
	FEMALE

}
