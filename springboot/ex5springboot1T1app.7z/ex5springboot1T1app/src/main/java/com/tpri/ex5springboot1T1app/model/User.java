package com.tpri.ex5springboot1T1app.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name="users")
@ApiModel(description="")
public class User implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="")
    private Long id;
	
	@NotNull
	@Size(max=100)
	@Column(name="first_name")
	@ApiModelProperty(notes="")
	private String firstName;
	
	@Size(max=100)
	@Column(name="last_name")
	@ApiModelProperty(notes="")
	private String lastName;
	
	@NotNull
	@Email
	@Size(max=200)
	@Column(unique=true)
	@ApiModelProperty(notes="")
	private String email;
	
	@NotNull
	@Size(max=128)
	@ApiModelProperty(notes="")
	private String password;
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy="user")
	@ApiModelProperty(notes="")
	private UserProfile userProfile;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public User() {}
	
	public User(Long id, String firstName, String lastName, String email, String password, UserProfile userProfile) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.userProfile = userProfile;
	}
	
	

	
	
	
}
