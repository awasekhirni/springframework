package com.tpri.ex5springboot1T1app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tpri.ex5springboot1T1app.model.UserProfile;
import com.tpri.ex5springboot1T1app.repository.UserProfileRepository;

@Service
public class UserProfileServiceImpl implements IUserProfileService {

	@Autowired
	private UserProfileRepository upr;

	@Override
	public Iterable<UserProfile> getAllUserProfiles() {
		// TODO Auto-generated method stub

		return upr.findAll();
	}

	@Override
	public UserProfile getUserProfile(Long id) {
		// TODO Auto-generated method stub
		return upr.findOne(id);

	}

	@Override
	public UserProfile addUserProfile(UserProfile userProfile) {
		// TODO Auto-generated method stub
		return upr.save(userProfile);
	}

	@Override
	public UserProfile updateUserProfile(Long id, UserProfile userProfile) {
		// TODO Auto-generated method stub
		UserProfile myuserProfile = upr.findOne(id);

		upr.save(myuserProfile);
		return myuserProfile;
	}

	@Override
	public void deleteUserProfile(Long id) {
		// TODO Auto-generated method stub
		upr.delete(id);
	}

}
