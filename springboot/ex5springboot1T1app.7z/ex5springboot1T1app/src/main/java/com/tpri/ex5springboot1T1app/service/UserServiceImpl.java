package com.tpri.ex5springboot1T1app.service;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;


import com.tpri.ex5springboot1T1app.model.User;
import com.tpri.ex5springboot1T1app.repository.UserRepository;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository ur;
	
	
	
	@Override
	public Iterable<User> getAllUsers() {
		// TODO Auto-generated method stub
		return ur.findAll();
	}

	@Override
	public User getUser(Long id) {
		// TODO Auto-generated method stub
		return ur.findOne(id);
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return ur.save(user);
	}

	@Override
	public User updateUser(Long id, User user) {
		// TODO Auto-generated method stub
		User myuser = ur.findOne(id);
		ur.save(myuser);
		return myuser;
	}

	@Override
	public void deleteUser(Long id) {
		// TODO Auto-generated method stub
		ur.delete(id);
	}

	
}
