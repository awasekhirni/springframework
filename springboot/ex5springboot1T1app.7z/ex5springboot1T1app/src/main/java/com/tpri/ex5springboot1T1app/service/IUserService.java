package com.tpri.ex5springboot1T1app.service;

import com.tpri.ex5springboot1T1app.model.User;

public interface IUserService {
	
	public Iterable<User> getAllUsers();
	public User getUser(Long id);
	public User addUser(User user);
	public User updateUser(Long id, User user);
	public void deleteUser(Long id);

}
