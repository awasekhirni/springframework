package com.tpri.ex5springboot1T1app.service;

import com.tpri.ex5springboot1T1app.model.UserProfile;

public interface IUserProfileService {

	public Iterable<UserProfile> getAllUserProfiles();
	public UserProfile getUserProfile(Long id);
	public UserProfile addUserProfile(UserProfile userProfile);
	public UserProfile updateUserProfile(Long id, UserProfile userProfile);
	public void deleteUserProfile(Long id);
}
