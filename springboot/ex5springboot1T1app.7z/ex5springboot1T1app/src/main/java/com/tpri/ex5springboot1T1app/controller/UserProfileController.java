package com.tpri.ex5springboot1T1app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.tpri.ex5springboot1T1app.model.UserProfile;
import com.tpri.ex5springboot1T1app.service.UserProfileServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/userprofiles")
public class UserProfileController {
	
	
	@Autowired
	private UserProfileServiceImpl upsl;
	
	@PostMapping(value="/create")
	@ApiOperation(value="Add new userprofile", notes="Add new userprofile", response=UserProfile.class)
	public UserProfile createUserProfile(@RequestBody UserProfile userprofile) {
		return upsl.addUserProfile(userprofile);
	}
	
	
	@GetMapping(value="/userprofile/{id}")
	@ApiOperation(value="fetch userprofile by id", notes="fetch userprofile by id", response=UserProfile.class)
	public UserProfile getUserProfileById(@PathVariable("id") Long id) {
		return upsl.getUserProfile(id);
	}
	
	
	
	@GetMapping(value="/all")
	@ApiOperation(value="fetch all userprofiles ", notes="fetch all userprofiles ", response=UserProfile.class)
	public Iterable<UserProfile> fetchAllUserProfiles(){
		return upsl.getAllUserProfiles();
	}
	
	
	@DeleteMapping(value="/userprofile/{id}")
	@ApiOperation(value="delete userprofile by id", notes="delete userprofile by id", response=UserProfile.class)
	public void deleteUserProfile(@PathVariable("id")Long id) {
		upsl.deleteUserProfile(id);
	}

	
	@PutMapping(value="/userprofile/{id}")
	@ApiOperation(value="update userprofile by id", notes="update userprofile by id", response=UserProfile.class)
	public UserProfile updateUserProfile(@PathVariable("id")Long id, @RequestBody UserProfile userProfile) {
		UserProfile myuserprofile = upsl.getUserProfile(id);
		upsl.updateUserProfile(id, myuserprofile);
		return myuserprofile ;
		
	}

}
