package com.tpri.ex5springboot1T1app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex5springboot1T1app.model.User;
import com.tpri.ex5springboot1T1app.service.UserServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserServiceImpl usi;
	
	@PostMapping(value="/create")
	@ApiOperation(value="Add new users", notes="Add new users", response=User.class)
	public User createUser(@RequestBody User user) {
		return usi.addUser(user);
	}
	
	@GetMapping(value="/user/{id}")
	@ApiOperation(value="get User by Id", notes="Get user by Id, takes Long", response=User.class)
	public User getUserById(@PathVariable("id") Long id) {
		return usi.getUser(id);
	}
	
	@GetMapping(value="/all")
	@ApiOperation(value="fetch all users", notes="fetch all users", response=User.class)
	public Iterable<User> getAllUsers(){
		return usi.getAllUsers();
	}
	
	
	@DeleteMapping(value="/user/{id}")
	@ApiOperation(value="delete user by id", notes="delete user by id", response=User.class)
	public void deleteUser(@PathVariable("id") Long id) {
		usi.deleteUser(id);
	}

	
	
	@PutMapping(value="/user/{id}")
	@ApiOperation(value="Update user", notes="update user", response=User.class)
	public User updateUser(@PathVariable("id") Long id,@RequestBody User user) {
		User myuser = usi.getUser(id);
		usi.updateUser(id, myuser);
		return myuser;
		
		
	}
	
	
	
	
}
