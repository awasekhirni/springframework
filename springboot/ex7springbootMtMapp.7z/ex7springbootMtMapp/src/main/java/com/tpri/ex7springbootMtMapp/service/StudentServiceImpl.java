package com.tpri.ex7springbootMtMapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tpri.ex7springbootMtMapp.model.Student;
import com.tpri.ex7springbootMtMapp.repository.StudentRepository;

@Service
public class StudentServiceImpl implements IStudentService{
	
	@Autowired
	StudentRepository studentrepo;

	public Iterable<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return null;
	}

	public Student getStudent(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	public Student updateStudent(Long id, Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteStudent(Long id) {
		// TODO Auto-generated method stub
		
	}

}
