package com.tpri.ex7springbootMtMapp.service;

import com.tpri.ex7springbootMtMapp.model.Student;

public interface IStudentService {
	public Iterable<Student> getAllStudents();
	public Student getStudent(Long id);
	public Student addStudent(Student student);
	public Student updateStudent(Long id, Student student);
	public void deleteStudent(Long id);

}
