package com.tpri.ex7springbootMtMapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tpri.ex7springbootMtMapp.model.Student;
@Repository
public interface StudentRepository  extends JpaRepository<Student, Long>{

}
