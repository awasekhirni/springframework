package com.tpri.ex7springbootMtMapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tpri.ex7springbootMtMapp.model.Subject;
import com.tpri.ex7springbootMtMapp.repository.SubjectRepository;

@Service
public class SubjectServiceImpl implements ISubjectService{

	@Autowired
	SubjectRepository subjectrepo;
	
	public Iterable<Subject> getAllSubjects() {
		// TODO Auto-generated method stub
		return null;
	}

	public Subject getSubject(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Subject addSubject(Subject Subject) {
		// TODO Auto-generated method stub
		return null;
	}

	public Subject updateSubject(Long id, Subject Subject) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteSubject(Long id) {
		// TODO Auto-generated method stub
		
	}

}
