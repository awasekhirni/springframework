package com.tpri.ex7springbootMtMapp.service;

import com.tpri.ex7springbootMtMapp.model.Subject;

public interface ISubjectService {
	public Iterable<Subject> getAllSubjects();
	public Subject getSubject(Long id);
	public Subject addSubject(Subject Subject);
	public Subject updateSubject(Long id, Subject Subject);
	public void deleteSubject(Long id);
}
