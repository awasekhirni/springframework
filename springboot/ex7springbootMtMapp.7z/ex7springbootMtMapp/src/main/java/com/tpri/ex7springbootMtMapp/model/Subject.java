package com.tpri.ex7springbootMtMapp.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@ApiModel(description="Subject Model Object")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Subject {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@ApiModelProperty(notes="Auto generated Id")
	private Long id;
	
	@Column
	@ApiModelProperty(notes="Subject Name")
	private String subjectName;
	
	
	@ApiModelProperty(notes="Students Set Reference")
	@ManyToMany(mappedBy = "subjects",cascade=CascadeType.ALL)
	private Set<Student> students;
	
}
