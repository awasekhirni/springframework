package com.tpri.ex7springbootMtMapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tpri.ex7springbootMtMapp.model.Subject;
import com.tpri.ex7springbootMtMapp.service.SubjectServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/subjects")
public class SubjectController {
	
	@Autowired
	SubjectServiceImpl subjectservice;
	
	@PostMapping(value="/create")
	@ApiOperation(value="Add new Subject", notes="Add new Subject", response=Subject.class)
	public Subject createSubject(@RequestBody Subject Subject) {
		return subjectservice.addSubject(Subject);
	}
	
	
	
	@GetMapping(value="/Subject/{id}")
	@ApiOperation(value="get Subject by Id", notes="Get Subject by Id, takes Long", response=Subject.class)
	public Subject getSubjectById(@PathVariable("id") Long id) {
		return subjectservice.getSubject(id);
	}
	
	@GetMapping(value="/all")
	@ApiOperation(value="get all Subjects ", notes="Get all Subject  takes Long", response=Subject.class)
	public Iterable<Subject> getAllSubjects(){
		return subjectservice.getAllSubjects();
	}
	
	
	@DeleteMapping(value="/Subject/{id}")
	@ApiOperation(value="delete Subject by Id", notes="delete Subject by Id, takes Long", response=Subject.class)
	public void deleteSubject(@PathVariable("id") Long id) {
		subjectservice.deleteSubject(id);
	}

	
	
	@PutMapping(value="/Subject/{id}")
	@ApiOperation(value="update Subject by Id", notes="update Subject by Id, takes Long", response=Subject.class)
	public Subject updateUser(@PathVariable("id") Long id,@RequestBody Subject Subject) {
		Subject mySubject = subjectservice.getSubject(id);
		subjectservice.updateSubject(id, mySubject);
		return mySubject;
		
		
	}

}
