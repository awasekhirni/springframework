package com.tpri.ex7springbootMtMapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class Swagger2Configurator {
	@Bean 
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(PathSelectors.ant("/api**/**"))
				.apis(RequestHandlerSelectors.basePackage("com.tpri.ex7springbootMtMapp"))
				.build()
				.apiInfo(apiEndPointsInfo());
								
	}
	
	
	
	private ApiInfo apiEndPointsInfo() {
		return new ApiInfoBuilder()
				.title("Spring Boot REST API with SWAGGER Configurator (Many to many mapping demo)- SYED AWASE KHIRNI")
				.description("Many to Many Mapping REST API - credits to SYED AWASE KHIRNI")
				.contact(new Contact("Dr. Awase Khirni Syed", "www.territorialprescience.com","awasekhirni@gmail.com"))
				.license("Free to use, if tweeted or shared at LinkedIn, the use of the application and acknowledge the contribution Else terms and conditions will be applicable copyright www.territorialprescience.com")
				.licenseUrl("www.territorialprescience.com")
				.version("1.0.0")
				.build();
	}

}
