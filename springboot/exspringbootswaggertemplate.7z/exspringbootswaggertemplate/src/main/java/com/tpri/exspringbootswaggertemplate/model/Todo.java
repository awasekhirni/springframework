package com.tpri.exspringbootswaggertemplate.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Todo POJO has unique identification, todotask and status")
public class Todo {
	@ApiModelProperty(notes="The unique identifier for the todo task")
	private String todoId;
	@ApiModelProperty(notes="Todo task descriptive notes of the task, 500 characters length")
	private String todoTask;
	@ApiModelProperty(notes="todo task status: only 3 states possible 1. incomplete 2. completed 3.inprogress")
	private String todoStatus;
	
	public Todo() {}

	public Todo(String todoId, String todoTask, String todoStatus) {
		super();
		this.todoId = todoId;
		this.todoTask = todoTask;
		this.todoStatus = todoStatus;
	}
	public String getTodoId() {
		return todoId;
	}
	public void setTodoId(String todoId) {
		this.todoId = todoId;
	}
	public String getTodoTask() {
		return todoTask;
	}
	public void setTodoTask(String todoTask) {
		this.todoTask = todoTask;
	}
	public String getTodoStatus() {
		return todoStatus;
	}

	public void setTodoStatus(String todoStatus) {
		this.todoStatus = todoStatus;
	}
	
	
	
	
	

}
